
import React, { useState } from 'react';
import { User, CurrencyConfig } from '../types';
import { useLanguage } from '../i18n';
import { useTheme } from './ThemeContext';
import { 
  User as UserIcon, Camera, Copy, Check, Mail, Phone, 
  ShieldCheck, Calendar, Wallet, Edit2, Save, X, Globe, MapPin, Palette,
  Sun, Moon, Monitor, Swords, Trophy, Star, Activity, Crown, Zap, Lock
} from 'lucide-react';

interface UserProfileProps {
  user: User;
  currencies: CurrencyConfig[];
  onUpdateUser: (updatedData: Partial<User>) => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ user, currencies, onUpdateUser }) => {
  const { t, dir, language } = useLanguage();
  const { accent, setAccent, mode, setMode } = useTheme();
  
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone || '',
  });
  
  const [avatarPreview, setAvatarPreview] = useState<string | null>(user.avatar || null);
  const [copied, setCopied] = useState(false);

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setAvatarPreview(result);
        onUpdateUser({ avatar: result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(user.userCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    onUpdateUser(formData);
    setIsEditing(false);
  };

  const formatCurrency = (val: number, currencyCode: string) => {
    const config = currencies.find(c => c.code === currencyCode);
    const symbol = config?.symbol || currencyCode;
    const formatted = val.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    return { formatted, symbol };
  };

  const totalAssetsUSD = user.wallets.reduce((acc, wallet) => {
    const currency = currencies.find(c => c.code === wallet.currency);
    if (currency) {
        return acc + (wallet.balance * currency.rateToUSD);
    }
    return acc;
  }, 0);

  const colors: Array<{id: any, color: string, name: string}> = [
    { id: 'emerald', color: '#10b981', name: 'Emerald' },
    { id: 'blue', color: '#3b82f6', name: 'Blue' },
    { id: 'rose', color: '#f43f5e', name: 'Rose' },
    { id: 'violet', color: '#8b5cf6', name: 'Violet' },
    { id: 'amber', color: '#f59e0b', name: 'Amber' },
    { id: 'cyan', color: '#06b6d4', name: 'Cyan' },
  ];

  // Level Calculations
  const xpCurrent = user.xp % 1000;
  const xpRequired = 1000;
  const xpProgress = (xpCurrent / xpRequired) * 100;
  const nextLevel = user.level + 1;

  // Level Benefits Logic (Visual Only)
  const getLevelBenefits = (lvl: number) => {
      if (lvl >= 10) return "VIP Gold Status, Priority Support, 0% Transfer Fees";
      if (lvl >= 5) return "Silver Status, 50% Reduced Fees";
      return "Standard Member Access";
  };

  const getNextUnlock = (lvl: number) => {
      if (lvl < 5) return "Level 5: Silver Badge & Fee Discounts";
      if (lvl < 10) return "Level 10: Gold VIP Status";
      return "Max Level Reached";
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      
      <div className="relative mb-12">
        <div className="h-64 bg-gradient-to-r from-[var(--bg-card-solid)] to-[var(--bg-main)] rounded-[3rem] overflow-hidden shadow-2xl relative border border-white/5">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
            
            <div className="absolute top-8 left-8 bg-black/20 backdrop-blur-xl px-4 py-2 rounded-2xl border border-white/10 flex items-center gap-2 shadow-lg">
                <span className={`w-2.5 h-2.5 rounded-full ${user.status === 'active' ? 'bg-emerald-500 animate-pulse shadow-[0_0_10px_#10b981]' : 'bg-red-500'}`}></span>
                <span className="text-white text-xs font-black uppercase tracking-widest">{user.status}</span>
            </div>
        </div>

        <div className="absolute -bottom-20 right-12 md:right-20 flex items-end gap-8">
            <div className="relative group">
                <div className="w-36 h-36 md:w-48 md:h-48 rounded-[2.5rem] border-4 border-[var(--bg-main)] shadow-2xl bg-[var(--bg-card-solid)] flex items-center justify-center overflow-hidden relative z-10 transition-transform duration-500 group-hover:scale-105">
                    {avatarPreview ? (
                        <img src={avatarPreview} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                        <UserIcon className="w-20 h-20 text-slate-700" />
                    )}
                </div>
                <label className="absolute bottom-4 right-4 z-20 bg-emerald-600 p-3 rounded-2xl text-white cursor-pointer shadow-xl hover:bg-emerald-500 transition-all border-4 border-[var(--bg-main)] hover:scale-110 active:scale-90">
                    <Camera className="w-5 h-5" />
                    <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
                </label>
            </div>
            
            <div className="mb-6 hidden md:block">
                <h1 className="text-4xl font-black drop-shadow-lg flex items-center gap-3 mb-2">
                    {user.name}
                    {user.role === 'super_admin' && <ShieldCheck className="w-8 h-8 text-yellow-500 drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]" />}
                </h1>
                <div className="flex items-center gap-3">
                  <p className="text-[var(--text-secondary)] text-xs font-mono font-bold bg-[var(--bg-card-solid)] backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/5 uppercase tracking-widest shadow-lg">
                      {user.role}
                  </p>
                  <p className="text-[var(--text-secondary)] text-xs font-bold flex items-center gap-1 opacity-60">
                      <Calendar className="w-3 h-3" /> Joined {new Date(user.joinDate).getFullYear()}
                  </p>
                </div>
            </div>
        </div>
      </div>

      <div className="mt-28 grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="space-y-8">
              
              {/* Level & XP Card */}
              <div className="glass-card rounded-[2.5rem] p-8 border border-amber-500/20 bg-gradient-to-b from-amber-500/5 to-transparent relative overflow-hidden group">
                  <div className="flex items-center gap-4 mb-6">
                      <div className="p-3 bg-amber-500 rounded-xl text-white shadow-lg shadow-amber-900/40">
                          <Crown className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-black text-lg">مستوى الحساب</h3>
                        <p className="text-[10px] text-[var(--text-secondary)] font-bold uppercase tracking-widest">Level Progression</p>
                      </div>
                  </div>
                  
                  <div className="space-y-6">
                      <div className="flex justify-between items-end">
                          <div>
                              <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest mb-1">Current Level</p>
                              <p className="text-4xl font-black text-white">{user.level}</p>
                          </div>
                          <div className="text-left">
                              <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest mb-1">Total XP</p>
                              <span className="text-amber-400 font-black text-sm">{user.xp.toLocaleString()} XP</span>
                          </div>
                      </div>

                      <div className="space-y-2">
                          <div className="flex justify-between px-1">
                              <span className="text-[10px] font-black text-slate-500 uppercase">Next Level Progress</span>
                              <span className="text-[10px] font-black text-amber-400">{xpCurrent} / {xpRequired}</span>
                          </div>
                          <div className="h-4 w-full bg-slate-900 rounded-full border border-white/5 overflow-hidden shadow-inner relative">
                              <div className="h-full bg-gradient-to-r from-amber-600 to-yellow-400 rounded-full transition-all duration-1000" style={{ width: `${xpProgress}%` }}></div>
                              {/* Shine effect */}
                              <div className="absolute top-0 bottom-0 left-0 w-full bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer"></div>
                          </div>
                      </div>

                      <div className="bg-black/30 p-4 rounded-2xl border border-white/5">
                          <div className="flex items-start gap-3">
                              <Zap size={16} className="text-amber-500 shrink-0 mt-0.5" />
                              <div>
                                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">Current Benefits</p>
                                  <p className="text-xs font-bold text-white">{getLevelBenefits(user.level)}</p>
                              </div>
                          </div>
                          <div className="h-[1px] bg-white/5 my-3"></div>
                          <div className="flex items-start gap-3">
                              <Lock size={16} className="text-slate-500 shrink-0 mt-0.5" />
                              <div>
                                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">Next Unlock</p>
                                  <p className="text-xs font-bold text-slate-300">{getNextUnlock(user.level)}</p>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>

              {/* Theme Customization */}
              <div className="glass-card rounded-[2.5rem] p-8 border border-white/5">
                  <div className="flex items-center gap-4 mb-8">
                      <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
                          <Palette className="w-6 h-6 text-emerald-500" />
                      </div>
                      <div>
                        <h3 className="font-black text-lg">تخصيص المظهر</h3>
                        <p className="text-[10px] text-[var(--text-secondary)] font-bold uppercase tracking-widest">Theme & Accent</p>
                      </div>
                  </div>

                  <div className="space-y-3 mb-8">
                      <label className="text-[10px] text-[var(--text-secondary)] font-black uppercase tracking-widest px-1">نمط الألوان</label>
                      <div className="bg-black/10 rounded-2xl p-1 flex gap-1 border border-white/5">
                          <button 
                            onClick={() => setMode('dark')}
                            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black transition-all ${mode === 'dark' ? 'bg-slate-800 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                          >
                              <Moon className="w-4 h-4" /> داكن
                          </button>
                          <button 
                            onClick={() => setMode('light')}
                            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black transition-all ${mode === 'light' ? 'bg-white text-slate-900 shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                          >
                              <Sun className="w-4 h-4" /> فاتح
                          </button>
                      </div>
                  </div>
                  
                  <div className="space-y-3">
                      <label className="text-[10px] text-[var(--text-secondary)] font-black uppercase tracking-widest px-1">اللون الأساسي</label>
                      <div className="grid grid-cols-6 gap-2">
                          {colors.map(c => (
                              <button
                                key={c.id}
                                onClick={() => setAccent(c.id)}
                                className={`w-full aspect-square rounded-xl transition-all relative group flex items-center justify-center ${accent === c.id ? 'ring-2 ring-emerald-500 scale-110' : 'hover:scale-105 opacity-80 hover:opacity-100'}`}
                                style={{ backgroundColor: c.color }}
                                title={c.name}
                              >
                                  {accent === c.id && <Check className="w-4 h-4 text-white drop-shadow-md" />}
                              </button>
                          ))}
                      </div>
                  </div>
              </div>

              {/* Identity Card */}
              <div className="glass-card rounded-[2.5rem] p-8 relative overflow-hidden group hover:border-emerald-500/30 transition-all duration-500">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-[50px] group-hover:bg-emerald-500/20 transition-all duration-500"></div>
                  
                  <div className="flex justify-between items-start mb-8 relative z-10">
                      <div>
                          <h3 className="text-emerald-500 font-black text-xs tracking-[0.2em] uppercase mb-1">{t('profile_identity')}</h3>
                          <p className="text-[10px] text-[var(--text-secondary)] font-bold uppercase">Personal Secure ID</p>
                      </div>
                      <div className="bg-white p-2 rounded-xl shadow-lg transform rotate-3 group-hover:rotate-0 transition-transform duration-500">
                          <img 
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${user.userCode}`} 
                            alt="QR Code" 
                            className="w-14 h-14 mix-blend-multiply opacity-90"
                          />
                      </div>
                  </div>

                  <div className="bg-black/20 rounded-2xl p-5 border border-white/5 flex justify-between items-center relative z-10 group-hover:bg-black/30 transition-colors">
                      <div>
                          <p className="text-[9px] text-[var(--text-secondary)] font-black uppercase tracking-widest mb-1">User Code</p>
                          <p className="text-xl font-mono font-black tracking-widest">{user.userCode}</p>
                      </div>
                      <button 
                        onClick={handleCopyCode}
                        className="p-3 bg-white/5 hover:bg-white/10 rounded-xl text-slate-400 hover:text-[var(--text-primary)] transition-all active:scale-90"
                      >
                          {copied ? <Check className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
                      </button>
                  </div>
              </div>
          </div>

          {/* Main Profile Info */}
          <div className="lg:col-span-2 space-y-8">
              <div className="glass-card rounded-[2.5rem] p-8 md:p-10 border border-white/5 relative h-fit overflow-hidden">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
                  
                  <div className="relative z-10">
                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 pb-8 border-b border-white/5 gap-4">
                          <div>
                              <h2 className="text-2xl font-black flex items-center gap-3 mb-1">
                                  <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
                                    <UserIcon className="w-6 h-6 text-emerald-500" />
                                  </div>
                                  {t('profile_personal_info')}
                              </h2>
                              <p className="text-[var(--text-secondary)] text-xs font-bold uppercase tracking-widest ml-1">Manage your secure personal data</p>
                          </div>
                          
                          {!isEditing ? (
                              <button 
                                onClick={() => setIsEditing(true)}
                                className="bg-white/5 hover:bg-white/10 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all border border-white/5 hover:border-white/10 flex items-center gap-2 active:scale-95"
                              >
                                  <Edit2 className="w-4 h-4" />
                                  {t('edit')}
                              </button>
                          ) : (
                              <div className="flex gap-3 w-full md:w-auto">
                                  <button 
                                    onClick={() => { setIsEditing(false); setFormData({ name: user.name, email: user.email, phone: user.phone || '' }); }}
                                    className="flex-1 md:flex-none py-3 px-6 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl font-black text-xs uppercase tracking-widest transition-all"
                                  >
                                      {t('cancel')}
                                  </button>
                                  <button 
                                    onClick={handleSave}
                                    className="flex-1 md:flex-none py-3 px-8 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg shadow-emerald-900/20 flex items-center justify-center gap-2"
                                  >
                                      <Save className="w-4 h-4" />
                                      {t('save')}
                                  </button>
                              </div>
                          )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="space-y-3 group">
                              <label className="text-[10px] font-black text-[var(--text-secondary)] uppercase tracking-widest px-2 group-focus-within:text-emerald-500 transition-colors">{t('full_name')}</label>
                              <div className="relative">
                                  <input 
                                      type="text" 
                                      value={formData.name}
                                      onChange={e => setFormData({...formData, name: e.target.value})}
                                      disabled={!isEditing}
                                      className={`w-full bg-black/10 border ${isEditing ? 'border-emerald-500/50 focus:border-emerald-500' : 'border-white/5'} rounded-2xl py-4 px-12 font-bold outline-none transition-all placeholder:text-slate-700 disabled:opacity-50 disabled:cursor-not-allowed`}
                                  />
                                  <UserIcon className="absolute top-1/2 left-4 -translate-y-1/2 text-slate-600 w-5 h-5 group-focus-within:text-emerald-500 transition-colors" />
                              </div>
                          </div>

                          <div className="space-y-3 group">
                              <label className="text-[10px] font-black text-[var(--text-secondary)] uppercase tracking-widest px-2 group-focus-within:text-emerald-500 transition-colors">{t('email')}</label>
                              <div className="relative">
                                  <input 
                                      type="email" 
                                      value={formData.email}
                                      onChange={e => setFormData({...formData, email: e.target.value})}
                                      disabled={!isEditing}
                                      className={`w-full bg-black/10 border ${isEditing ? 'border-emerald-500/50 focus:border-emerald-500' : 'border-white/5'} rounded-2xl py-4 px-12 font-bold outline-none transition-all placeholder:text-slate-700 disabled:opacity-50 disabled:cursor-not-allowed`}
                                  />
                                  <Mail className="absolute top-1/2 left-4 -translate-y-1/2 text-slate-600 w-5 h-5 group-focus-within:text-emerald-500 transition-colors" />
                              </div>
                          </div>

                          <div className="space-y-3 group">
                              <label className="text-[10px] font-black text-[var(--text-secondary)] uppercase tracking-widest px-2 group-focus-within:text-emerald-500 transition-colors">{t('phone')}</label>
                              <div className="relative">
                                  <input 
                                      type="text" 
                                      value={formData.phone}
                                      onChange={e => setFormData({...formData, phone: e.target.value})}
                                      disabled={!isEditing}
                                      placeholder="+966..."
                                      dir="ltr"
                                      className={`w-full bg-black/10 border ${isEditing ? 'border-emerald-500/50 focus:border-emerald-500' : 'border-white/5'} rounded-2xl py-4 px-12 font-bold outline-none transition-all text-right placeholder:text-slate-700 disabled:opacity-50 disabled:cursor-not-allowed`}
                                  />
                                  <Phone className="absolute top-1/2 left-4 -translate-y-1/2 text-slate-600 w-5 h-5 group-focus-within:text-emerald-500 transition-colors" />
                              </div>
                          </div>

                          <div className="space-y-3 group opacity-70">
                              <label className="text-[10px] font-black text-[var(--text-secondary)] uppercase tracking-widest px-2">{t('join_date')}</label>
                              <div className="relative">
                                  <input 
                                      type="text" 
                                      value={new Date(user.joinDate).toLocaleDateString('en-US')}
                                      disabled
                                      className="w-full bg-black/10 border border-white/5 rounded-2xl py-4 px-12 text-[var(--text-secondary)] font-bold cursor-not-allowed"
                                  />
                                  <Calendar className="absolute top-1/2 left-4 -translate-y-1/2 text-slate-600 w-5 h-5" />
                              </div>
                          </div>
                      </div>
                      
                      <div className="mt-10 p-6 bg-black/10 rounded-2xl border border-white/5 flex items-start gap-4">
                          <div className="p-2 bg-blue-500/10 rounded-xl border border-blue-500/20">
                              <ShieldCheck className="w-5 h-5 text-blue-400" />
                          </div>
                          <div>
                              <h4 className="font-black text-xs uppercase tracking-widest mb-1">تشفير آمن للبيانات</h4>
                              <p className="text-[10px] text-[var(--text-secondary)] leading-relaxed font-bold">
                                  يتم تشفير بياناتك الشخصية وتخزينها بأمان وفقاً للمعايير العالمية. أي تغييرات في البيانات الحساسة قد تتطلب خطوات تحقق إضافية عبر البريد أو الرسائل النصية.
                              </p>
                          </div>
                      </div>
                  </div>
              </div>

              {/* Wallet Summary */}
              <div className="glass-card rounded-[2.5rem] p-8 relative overflow-hidden">
                  <div className="flex items-center gap-4 mb-6">
                      <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                          <Wallet className="w-6 h-6 text-indigo-500" />
                      </div>
                      <div>
                        <h3 className="font-black text-lg">{t('nav_wallet')}</h3>
                        <p className="text-[10px] text-[var(--text-secondary)] font-bold uppercase tracking-widest">Asset Overview</p>
                      </div>
                  </div>
                  <div className="space-y-6">
                      <div className="bg-gradient-to-br from-[var(--bg-card-solid)] to-black/20 rounded-[2rem] p-6 border border-white/5 shadow-inner">
                          <p className="text-[var(--text-secondary)] text-[10px] font-black uppercase tracking-widest mb-2">Estimated Net Worth (USD)</p>
                          <h2 className="text-4xl font-black dir-ltr tracking-tighter">
                              $ {totalAssetsUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </h2>
                      </div>
                      
                      <div className="space-y-3">
                          <p className="text-[var(--text-secondary)] text-[10px] font-black uppercase tracking-widest px-2">Wallet Breakdown</p>
                          <div className="grid grid-cols-1 gap-3 max-h-64 overflow-y-auto scrollbar-hide pr-2">
                              {user.wallets.map(w => {
                                  const { formatted, symbol } = formatCurrency(w.balance, w.currency);
                                  return (
                                    <div key={w.currency} className="bg-black/10 p-4 rounded-2xl border border-white/5 flex justify-between items-center group hover:bg-black/20 transition-colors">
                                        <div className="flex items-center gap-3">
                                            <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                                            <div className="text-[10px] text-[var(--text-secondary)] font-black uppercase tracking-widest">{w.currency}</div>
                                        </div>
                                        <div className="font-mono font-black text-sm flex items-center gap-1.5">
                                            <span>{formatted}</span>
                                            <span className="text-[10px] text-[var(--text-secondary)] font-bold">{symbol}</span>
                                        </div>
                                    </div>
                                  );
                              })}
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};

export default UserProfile;
