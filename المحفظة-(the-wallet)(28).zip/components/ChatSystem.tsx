
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { User, ChatMessage, ChatRoom, UserRole } from '../types';
import { 
  MessageCircle, Mic, MicOff, Send, Users, User as UserIcon, 
  Hash, Headphones, LogOut, Volume2, Search, MoreVertical,
  Phone, Video, Activity, Circle, Clock, Trash2, ShieldAlert,
  UserX, VolumeX, Plus, X, ShieldCheck, Settings, Lock
} from 'lucide-react';
import { useLanguage } from '../i18n';

interface ChatSystemProps {
  currentUser: User;
  allUsers: User[];
}

const INITIAL_ROOMS: ChatRoom[] = [
  { id: 'room_1', name: 'الديوانية العامة', type: 'VOICE', participants: ['user_1', 'admin_1'], activeSpeakers: ['user_1'], icon: Hash },
  { id: 'room_2', name: 'سوق العملات الرقمية', type: 'VOICE', participants: [], icon: Hash },
  { id: 'room_3', name: 'دعم العملاء المباشر', type: 'VOICE', participants: ['mod_1'], activeSpeakers: [], icon: Headphones },
  { id: 'room_4', name: 'غرفة كبار الشخصيات VIP', type: 'VOICE', participants: [], icon: Lock },
];

const ChatSystem: React.FC<ChatSystemProps> = ({ currentUser, allUsers }) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'MESSAGES' | 'ROOMS'>('ROOMS');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [activeRoom, setActiveRoom] = useState<ChatRoom | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [rooms, setRooms] = useState<ChatRoom[]>(INITIAL_ROOMS);
  const [showRoomCreator, setShowRoomCreator] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isAdmin = ['super_admin', 'admin', 'moderator'].includes(currentUser.role);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedUser]);

  // Simulation: Voice Activity
  useEffect(() => {
    if (!activeRoom) return;
    const interval = setInterval(() => {
        setRooms(prev => prev.map(r => {
            if (r.id === activeRoom.id) {
                const speakers = r.participants.filter(() => Math.random() > 0.85);
                return { ...r, activeSpeakers: speakers };
            }
            return r;
        }));
    }, 2500);
    return () => clearInterval(interval);
  }, [activeRoom]);

  const handleSendMessage = () => {
    if (!inputMessage.trim() || !selectedUser) return;
    const newMessage: ChatMessage = {
        id: `msg_${Date.now()}`,
        senderId: currentUser.id,
        receiverId: selectedUser.id,
        content: inputMessage,
        timestamp: new Date().toISOString(),
        isRead: false
    };
    setMessages(prev => [...prev, newMessage]);
    setInputMessage('');
  };

  const handleJoinRoom = (room: ChatRoom) => {
      if (activeRoom?.id === room.id) return;
      handleLeaveRoom();
      setActiveRoom(room);
      setRooms(prev => prev.map(r => r.id === room.id ? { ...r, participants: [...r.participants, currentUser.id] } : r));
  };

  const handleLeaveRoom = () => {
      if (!activeRoom) return;
      setRooms(prev => prev.map(r => r.id === activeRoom.id ? { ...r, participants: r.participants.filter(p => p !== currentUser.id) } : r));
      setActiveRoom(null);
  };

  const handleCreateRoom = () => {
      if (!newRoomName.trim()) return;
      const nRoom: ChatRoom = {
          id: `room_${Date.now()}`,
          name: newRoomName,
          type: 'VOICE',
          participants: [],
          icon: Hash
      };
      setRooms(prev => [nRoom, ...prev]);
      setNewRoomName('');
      setShowRoomCreator(false);
  };

  const handleDeleteRoom = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if (!isAdmin) return;
      if (confirm('هل أنت متأكد من حذف هذه الغرفة نهائياً؟')) {
          setRooms(prev => prev.filter(r => r.id !== id));
          if (activeRoom?.id === id) setActiveRoom(null);
      }
  };

  const handleKickUser = (userId: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if (!isAdmin || !activeRoom) return;
      setRooms(prev => prev.map(r => r.id === activeRoom.id ? { ...r, participants: r.participants.filter(p => p !== userId) } : r));
      alert(`تم طرد المستخدم بنجاح من الغرفة.`);
  };

  const getUserDetails = (id: string) => allUsers.find(u => u.id === id) || { name: 'Unknown', avatar: null, status: 'inactive' };

  return (
    <div className="max-w-7xl mx-auto h-[calc(100vh-160px)] animate-in fade-in slide-in-from-bottom-6 duration-700 flex gap-6" dir="rtl">
      
      {/* Sidebar - Contacts & Rooms */}
      <div className="w-80 glass-card rounded-[2.5rem] border border-white/5 flex flex-col overflow-hidden bg-[#020617]/50 backdrop-blur-xl shadow-2xl">
          <div className="p-6">
              <div className="bg-slate-900/80 p-1.5 rounded-2xl flex border border-white/5 mb-6">
                  <button onClick={() => setActiveTab('ROOMS')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all flex items-center justify-center gap-2 ${activeTab === 'ROOMS' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/40' : 'text-slate-500 hover:text-white'}`}>
                      <Headphones size={14} /> غرف المجتمع
                  </button>
                  <button onClick={() => setActiveTab('MESSAGES')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all flex items-center justify-center gap-2 ${activeTab === 'MESSAGES' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/40' : 'text-slate-500 hover:text-white'}`}>
                      <MessageCircle size={14} /> الرسائل
                  </button>
              </div>
              <div className="relative group">
                  <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600 w-4 h-4 group-focus-within:text-emerald-500 transition-colors" />
                  <input type="text" placeholder="البحث في المجتمع..." className="w-full bg-[#030712] border border-white/5 rounded-2xl py-3 pr-12 pl-4 text-xs font-bold text-white outline-none focus:border-emerald-500/50 transition-all" />
              </div>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 p-4 pt-0 scrollbar-hide">
              {activeTab === 'ROOMS' ? (
                  <>
                    <div className="flex justify-between items-center px-2 mb-2">
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">الغرف النشطة</span>
                        {isAdmin && <button onClick={() => setShowRoomCreator(true)} className="p-1.5 bg-emerald-500/10 text-emerald-500 rounded-lg hover:bg-emerald-500 hover:text-white transition-all"><Plus size={14}/></button>}
                    </div>
                    {rooms.map(room => (
                        <div key={room.id} onClick={() => handleJoinRoom(room)} className={`p-4 rounded-2xl border transition-all cursor-pointer group relative overflow-hidden ${activeRoom?.id === room.id ? 'bg-emerald-500/10 border-emerald-500/40' : 'bg-slate-900/40 border-white/5 hover:border-white/10'}`}>
                            <div className="flex justify-between items-start">
                                <div className="flex items-center gap-4">
                                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${activeRoom?.id === room.id ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-500'}`}>
                                        {room.icon ? <room.icon size={20} /> : <Hash size={20}/>}
                                    </div>
                                    <div>
                                        <h4 className={`font-black text-sm ${activeRoom?.id === room.id ? 'text-white' : 'text-slate-300'}`}>{room.name}</h4>
                                        <span className="text-[9px] text-slate-500 font-bold">{room.participants.length} عضو متواجد</span>
                                    </div>
                                </div>
                                {isAdmin && (
                                    <button onClick={(e) => handleDeleteRoom(room.id, e)} className="opacity-0 group-hover:opacity-100 p-2 text-rose-500 hover:bg-rose-500/10 rounded-lg transition-all"><Trash2 size={12}/></button>
                                )}
                            </div>
                        </div>
                    ))}
                  </>
              ) : (
                  allUsers.filter(u => u.id !== currentUser.id).map(u => (
                      <div key={u.id} onClick={() => setSelectedUser(u)} className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center gap-4 group ${selectedUser?.id === u.id ? 'bg-emerald-500/10 border-emerald-500/40' : 'bg-slate-900/40 border-white/5 hover:border-white/10'}`}>
                          <div className="relative">
                              <div className="w-11 h-11 rounded-xl bg-slate-800 overflow-hidden border border-white/5">
                                  {u.avatar ? <img src={u.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-white font-black">{u.name[0]}</div>}
                              </div>
                              <div className={`absolute -bottom-1 -right-1 w-3 h-3 border-2 border-[#020617] rounded-full ${u.status === 'active' ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`}></div>
                          </div>
                          <div className="flex-1 min-w-0">
                              <h4 className="font-black text-sm text-white truncate">{u.name}</h4>
                              <p className="text-[10px] text-slate-500 truncate">ابدأ الدردشة الآن...</p>
                          </div>
                      </div>
                  ))
              )}
          </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 glass-card rounded-[3rem] border border-white/5 flex flex-col overflow-hidden relative shadow-2xl bg-[#030712]/40 backdrop-blur-xl">
          
          {activeTab === 'ROOMS' && activeRoom ? (
              <div className="flex-1 flex flex-col animate-in fade-in duration-300">
                  <div className="p-8 border-b border-white/5 flex justify-between items-center bg-emerald-900/5">
                      <div className="flex items-center gap-5">
                          <div className="p-4 bg-emerald-600 rounded-2xl text-white shadow-xl shadow-emerald-900/30 transform -rotate-3">
                              {activeRoom.icon ? <activeRoom.icon size={28} /> : <Hash size={28}/>}
                          </div>
                          <div>
                              <h2 className="text-2xl font-black text-white">{activeRoom.name}</h2>
                              <div className="flex items-center gap-2 mt-1">
                                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_#10b981]"></span>
                                  <span className="text-xs font-bold text-emerald-400">اتصال صوتي نشط</span>
                              </div>
                          </div>
                      </div>
                      <div className="flex gap-4">
                          <button onClick={() => setIsMuted(!isMuted)} className={`p-4 rounded-2xl transition-all shadow-xl ${isMuted ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
                              {isMuted ? <MicOff size={22} /> : <Mic size={22} />}
                          </button>
                          <button onClick={handleLeaveRoom} className="p-4 rounded-2xl bg-slate-800 text-rose-500 hover:bg-rose-600 hover:text-white transition-all shadow-xl group">
                              <LogOut size={22} className="group-hover:translate-x-1 transition-transform" />
                          </button>
                      </div>
                  </div>

                  <div className="flex-1 p-10 overflow-y-auto scrollbar-hide">
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-10">
                          {activeRoom.participants.map(pid => {
                              const u = getUserDetails(pid);
                              const isSpeaking = activeRoom.activeSpeakers?.includes(pid);
                              const isMe = pid === currentUser.id;
                              
                              return (
                                  <div key={pid} className="flex flex-col items-center gap-5 group relative">
                                      <div className={`relative w-36 h-36 rounded-[2.8rem] p-1 transition-all duration-700 ${isSpeaking ? 'bg-gradient-to-tr from-emerald-500 to-emerald-400 shadow-[0_0_50px_rgba(16,185,129,0.3)] scale-110' : 'bg-slate-800/40 hover:bg-slate-800'}`}>
                                          <div className="w-full h-full rounded-[2.5rem] overflow-hidden bg-slate-900 relative">
                                              {(u as any).avatar ? <img src={(u as any).avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-4xl font-black text-white">{(u as any).name[0]}</div>}
                                              
                                              {/* Overlays */}
                                              <div className={`absolute top-4 left-4 w-3.5 h-3.5 rounded-full border-2 border-slate-900 ${(u as any).status === 'active' ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-slate-600'}`}></div>
                                              
                                              {isAdmin && !isMe && (
                                                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                                                    <button onClick={(e) => handleKickUser(pid, e)} className="p-3 bg-rose-600 text-white rounded-xl hover:scale-110 transition-transform shadow-lg" title="طرد من الغرفة"><UserX size={20}/></button>
                                                    <button className="p-3 bg-amber-600 text-white rounded-xl hover:scale-110 transition-transform shadow-lg" title="كتم الصوت"><VolumeX size={20}/></button>
                                                </div>
                                              )}
                                              
                                              <div className={`absolute bottom-4 right-4 p-2.5 backdrop-blur-md rounded-xl text-white transition-all ${isSpeaking ? 'bg-emerald-500' : 'bg-black/40'}`}>
                                                  {isSpeaking ? <Volume2 size={16} className="animate-pulse" /> : <MicOff size={16} className="text-slate-500" />}
                                              </div>
                                          </div>
                                      </div>
                                      <div className="text-center">
                                          <p className="font-black text-white text-sm flex items-center justify-center gap-2">
                                              {(u as any).name} 
                                              {['admin', 'super_admin'].includes((u as any).role) && <ShieldCheck size={14} className="text-emerald-500"/>}
                                          </p>
                                          <span className="text-[9px] text-slate-500 font-black uppercase tracking-widest mt-1 block">
                                              {isMe ? 'أنت' : (u as any).role}
                                          </span>
                                      </div>
                                  </div>
                              );
                          })}
                      </div>
                  </div>
              </div>
          ) : activeTab === 'MESSAGES' && selectedUser ? (
            <div className="flex-1 flex flex-col animate-in fade-in duration-300">
                <div className="p-6 border-b border-white/5 flex justify-between items-center bg-slate-900/30">
                    <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-2xl bg-slate-800 overflow-hidden relative shadow-lg">
                            {selectedUser.avatar ? <img src={selectedUser.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-xl font-black text-white">{selectedUser.name[0]}</div>}
                        </div>
                        <div>
                            <h2 className="text-xl font-black text-white flex items-center gap-2">{selectedUser.name} <ShieldCheck size={16} className="text-blue-500"/></h2>
                            <p className="text-[10px] text-emerald-500 font-black uppercase tracking-widest mt-0.5">{selectedUser.status === 'active' ? 'متصل الآن' : 'غير متصل'}</p>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <button className="p-3 bg-white/5 hover:bg-emerald-500/10 rounded-xl text-slate-400 hover:text-emerald-500 transition-all"><Phone size={20}/></button>
                        {isAdmin && <button className="p-3 bg-rose-500/10 rounded-xl text-rose-500 hover:bg-rose-500 hover:text-white transition-all"><UserX size={20}/></button>}
                    </div>
                </div>

                <div className="flex-1 p-8 overflow-y-auto scrollbar-hide space-y-6">
                    {messages.filter(m => (m.senderId === currentUser.id && m.receiverId === selectedUser.id) || (m.senderId === selectedUser.id && m.receiverId === currentUser.id)).map(msg => {
                        const isMe = msg.senderId === currentUser.id;
                        return (
                            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} group animate-in slide-in-from-bottom-2`}>
                                <div className={`max-w-[75%] p-5 rounded-[2rem] text-sm font-bold shadow-xl relative ${isMe ? 'bg-emerald-600 text-white rounded-br-none' : 'bg-slate-800 text-slate-200 rounded-bl-none border border-white/5'}`}>
                                    {msg.content}
                                    <div className={`text-[8px] mt-2 opacity-40 font-black uppercase flex items-center gap-2 ${isMe ? 'justify-end' : ''}`}>
                                        <Clock size={8}/> {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                    </div>
                                    {isAdmin && (
                                        <button onClick={() => setMessages(prev => prev.filter(m => m.id !== msg.id))} className="absolute -top-2 -left-2 p-1.5 bg-rose-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg scale-75"><Trash2 size={12}/></button>
                                    )}
                                </div>
                            </div>
                        )
                    })}
                    <div ref={messagesEndRef} />
                </div>

                <div className="p-8 bg-slate-900/60 border-t border-white/5">
                    <div className="flex items-center gap-4 bg-black/40 p-3 rounded-[2.5rem] border border-white/10 shadow-inner group focus-within:border-emerald-500/50 transition-all">
                        <input type="text" value={inputMessage} onChange={e => setInputMessage(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendMessage()} placeholder="اكتب رسالتك للمستفيد..." className="flex-1 bg-transparent px-6 text-white font-bold text-sm outline-none placeholder:text-slate-700" />
                        <button onClick={handleSendMessage} disabled={!inputMessage.trim()} className="p-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-[1.5rem] shadow-xl active:scale-95 disabled:opacity-30 transition-all"><Send size={20} className="rtl:rotate-180"/></button>
                    </div>
                </div>
            </div>
          ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-10 opacity-30 group">
                  <div className="w-40 h-40 bg-slate-900 rounded-[3.5rem] flex items-center justify-center mb-10 transform group-hover:scale-110 group-hover:rotate-3 transition-transform duration-700">
                      <MessageCircle size={72} className="text-emerald-600" />
                  </div>
                  <h3 className="text-3xl font-black text-white mb-4">مجتمع أفق الرقمي</h3>
                  <p className="text-slate-400 font-bold max-w-sm">اختر غرفة صوتية للنقاش أو تواصل مع العملاء بشكل مباشر وآمن.</p>
              </div>
          )}
      </div>

      {/* Room Creator Modal */}
      {showRoomCreator && (
          <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
              <div className="glass-card w-full max-w-md rounded-[3rem] p-10 border border-white/10 shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl"></div>
                  <div className="flex justify-between items-center mb-10">
                      <h3 className="text-2xl font-black text-white">إنشاء غرفة جديدة</h3>
                      <button onClick={() => setShowRoomCreator(false)} className="p-2 bg-white/5 rounded-full hover:bg-rose-500 transition-colors"><X/></button>
                  </div>
                  <div className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">اسم الغرفة</label>
                        <input type="text" value={newRoomName} onChange={e => setNewRoomName(e.target.value)} placeholder="مثلاً: نقاشات التداول" className="w-full bg-[#030712] border border-white/10 rounded-2xl p-4 text-white font-bold outline-none focus:border-emerald-500 transition-all" />
                      </div>
                      <button onClick={handleCreateRoom} className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-emerald-900/30 active:scale-95 transition-all">تفعيل الغرفة الآن</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default ChatSystem;
