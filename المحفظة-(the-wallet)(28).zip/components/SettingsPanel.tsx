
import React, { useState } from 'react';
import { StoreSettings, ExternalStore } from '../types';
import { 
  Save, Globe, Mail, Shield, AlertTriangle, 
  DollarSign, Percent, Server, ToggleLeft, ToggleRight,
  CreditCard, Lock, Activity, Image as ImageIcon, Link as LinkIcon, ShoppingBag, Plus, Trash2, Edit3, X, Zap, Upload
} from 'lucide-react';

interface SettingsPanelProps {
  settings: StoreSettings;
  onUpdateSettings: (settings: StoreSettings) => void;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onUpdateSettings }) => {
  const [formData, setFormData] = useState<StoreSettings>({ ...settings });
  const [isDirty, setIsDirty] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [editingStore, setEditingStore] = useState<ExternalStore | null>(null);

  const handleChange = (field: keyof StoreSettings, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setIsDirty(true);
    setShowSuccess(false);
  };

  const handleSave = () => {
    onUpdateSettings(formData);
    setIsDirty(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        handleChange('logoUrl', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addExternalStore = () => {
    const newStore: ExternalStore = {
      id: `ext_${Date.now()}`,
      name: 'متجر جديد',
      platform: 'Shopify',
      apiUrl: '',
      apiKey: '',
      isActive: true
    };
    setEditingStore(newStore);
  };

  const saveExternalStore = () => {
    if (!editingStore) return;
    const exists = formData.externalStores.some(s => s.id === editingStore.id);
    const updatedStores = exists 
      ? formData.externalStores.map(s => s.id === editingStore.id ? editingStore : s)
      : [...formData.externalStores, editingStore];
    
    handleChange('externalStores', updatedStores);
    setEditingStore(null);
  };

  const removeExternalStore = (id: string) => {
    if (confirm('هل أنت متأكد من رغبتك في حذف ربط هذا المتجر؟')) {
      handleChange('externalStores', formData.externalStores.filter(s => s.id !== id));
    }
  };

  const SectionHeader = ({ icon: Icon, title, desc }: { icon: any, title: string, desc: string }) => (
    <div className="flex items-start gap-4 mb-6 border-b border-white/5 pb-4">
      <div className="p-3 bg-slate-800 rounded-xl border border-white/10">
        <Icon className="w-6 h-6 text-emerald-500" />
      </div>
      <div>
        <h3 className="text-lg font-black text-white">{title}</h3>
        <p className="text-xs text-slate-500 font-bold">{desc}</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      
      {/* Header */}
      <div className="glass-card p-8 rounded-[2.5rem] border border-white/5 flex justify-between items-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500"></div>
        <div>
          <h2 className="text-3xl font-black text-white flex items-center gap-3">
            <Server className="w-8 h-8 text-emerald-500" />
            إعدادات النظام
          </h2>
          <p className="text-slate-400 font-bold mt-2">
            التحكم الكامل في خصائص المنصة، الرسوم، وحدود الأمان.
          </p>
        </div>
        
        {/* Floating Save Action */}
        <div className="flex items-center gap-4">
            {showSuccess && (
                <span className="text-emerald-500 text-sm font-black animate-pulse flex items-center gap-2">
                    <Shield className="w-4 h-4" /> تم الحفظ بنجاح
                </span>
            )}
            <button 
                onClick={handleSave}
                disabled={!isDirty}
                className={`flex items-center gap-2 px-8 py-4 rounded-2xl font-black text-sm transition-all shadow-lg active:scale-95 ${
                    isDirty 
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/20' 
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5'
                }`}
            >
                <Save className="w-5 h-5" />
                حفظ التغييرات
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* General Settings */}
        <div className="glass-card p-8 rounded-[2.5rem] border border-white/5">
            <SectionHeader icon={Globe} title="الإعدادات العامة" desc="معلومات الهوية الأساسية للمنصة" />
            <div className="space-y-5">
                <div>
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2 px-2">اسم المنصة (Site Name)</label>
                    <input 
                        type="text" 
                        value={formData.siteName}
                        onChange={(e) => handleChange('siteName', e.target.value)}
                        placeholder="Horizon Digital Wallet"
                        className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 text-white font-bold focus:border-emerald-500 outline-none transition-colors"
                    />
                </div>
                <div>
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2 px-2">وصف الموقع</label>
                    <textarea 
                        value={formData.siteDescription || ''}
                        onChange={(e) => handleChange('siteDescription', e.target.value)}
                        className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 text-white font-bold focus:border-emerald-500 outline-none transition-colors h-24 resize-none"
                    />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2 px-2">بريد الدعم</label>
                        <div className="relative">
                            <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                            <input 
                                type="email" 
                                value={formData.supportEmail}
                                onChange={(e) => handleChange('supportEmail', e.target.value)}
                                className="w-full bg-slate-900/50 border border-white/10 rounded-xl py-4 pr-10 pl-4 text-white font-bold focus:border-emerald-500 outline-none"
                            />
                        </div>
                    </div>
                    <div>
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2 px-2">شعار المنصة (Logo)</label>
                        <div className="flex items-center gap-4">
                            <div className="w-14 h-14 rounded-xl bg-slate-900 border border-white/10 flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                                {formData.logoUrl ? (
                                    <img src={formData.logoUrl} className="w-full h-full object-contain p-2" alt="Logo" />
                                ) : (
                                    <ImageIcon className="text-slate-700 w-6 h-6" />
                                )}
                            </div>
                            <label className="flex-1 cursor-pointer">
                                <div className="bg-slate-900/50 border border-white/10 rounded-xl p-3 text-slate-400 font-bold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 border-dashed">
                                    <Upload size={16} />
                                    <span className="text-[10px] font-black uppercase tracking-widest">رفع شعار من الجهاز</span>
                                </div>
                                <input 
                                    type="file" 
                                    accept="image/*"
                                    className="hidden"
                                    onChange={handleLogoUpload}
                                />
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {/* External Stores Integration */}
        <div className="glass-card p-8 rounded-[2.5rem] border border-white/5 bg-[#030712]/50 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl"></div>
            <div className="flex justify-between items-center mb-6">
                <SectionHeader icon={LinkIcon} title="الربط البرمجي (API)" desc="مزامنة المخزون مع منصات خارجية" />
                <button 
                  onClick={addExternalStore}
                  className="bg-emerald-600/10 hover:bg-emerald-600 text-emerald-500 hover:text-white p-2 rounded-xl transition-all active:scale-90 border border-emerald-500/20"
                >
                  <Plus className="w-5 h-5" />
                </button>
            </div>
            
            <div className="space-y-4 max-h-[400px] overflow-y-auto scrollbar-hide pr-2">
                {formData.externalStores.length === 0 ? (
                    <div className="text-center py-10 opacity-30">
                        <ShoppingBag className="w-12 h-12 mx-auto mb-2" />
                        <p className="text-xs font-bold">لا توجد متاجر خارجية مرتبطة حالياً</p>
                    </div>
                ) : (
                    formData.externalStores.map(store => (
                        <div key={store.id} className="bg-slate-900/80 border border-white/5 rounded-[1.8rem] p-5 flex items-center justify-between group hover:border-indigo-500/30 transition-all">
                            <div className="flex items-center gap-4">
                                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg ${store.platform === 'Shopify' ? 'bg-[#95bf47]' : store.platform === 'WooCommerce' ? 'bg-[#96588a]' : 'bg-slate-700'}`}>
                                    <ShoppingBag className="w-6 h-6" />
                                </div>
                                <div>
                                    <h4 className="text-white font-black text-sm">{store.name}</h4>
                                    <div className="flex items-center gap-2 mt-1">
                                        <span className="text-[9px] bg-white/5 text-slate-400 px-2 py-0.5 rounded uppercase font-bold">{store.platform}</span>
                                        <span className={`text-[8px] font-black ${store.isActive ? 'text-emerald-500' : 'text-slate-500'}`}>{store.isActive ? 'نشط' : 'معطل'}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => setEditingStore(store)} className="p-2 bg-white/5 rounded-xl hover:bg-indigo-600 text-slate-400 hover:text-white transition-all"><Edit3 size={16}/></button>
                                <button onClick={() => removeExternalStore(store.id)} className="p-2 bg-white/5 rounded-xl hover:bg-rose-600 text-slate-400 hover:text-white transition-all"><Trash2 size={16}/></button>
                            </div>
                        </div>
                    ))
                )}
            </div>

            {/* Editing/Adding Store Modal Overlay */}
            {editingStore && (
                <div className="absolute inset-0 z-50 bg-[#020617]/95 backdrop-blur-xl p-8 flex flex-col animate-in fade-in duration-300">
                    <div className="flex justify-between items-center mb-8 border-b border-white/5 pb-4">
                        <h4 className="text-white font-black flex items-center gap-3">
                            <Zap className="text-amber-500" /> إعدادات ربط المتجر
                        </h4>
                        <button onClick={() => setEditingStore(null)} className="text-slate-500 hover:text-white"><X/></button>
                    </div>
                    <div className="space-y-5 flex-1">
                        <div>
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2 px-2">اسم المتجر (داخلي)</label>
                            <input type="text" value={editingStore.name} onChange={e => setEditingStore({...editingStore, name: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white font-bold outline-none focus:border-indigo-500" />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2 px-2">المنصة</label>
                                <select value={editingStore.platform} onChange={e => setEditingStore({...editingStore, platform: e.target.value as any})} className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white font-bold outline-none cursor-pointer">
                                    <option value="Shopify">Shopify</option>
                                    <option value="WooCommerce">WooCommerce</option>
                                    <option value="Magento">Magento</option>
                                    <option value="Custom">Custom API</option>
                                </select>
                            </div>
                            <div className="flex items-end pb-1">
                                <button onClick={() => setEditingStore({...editingStore, isActive: !editingStore.isActive})} className={`w-full py-4 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${editingStore.isActive ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-slate-800 text-slate-500 border border-white/5'}`}>
                                    {editingStore.isActive ? 'الاتصال نشط' : 'الاتصال معطل'}
                                </button>
                            </div>
                        </div>
                        <div>
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2 px-2">رابط الـ API (Endpoint)</label>
                            <input type="text" value={editingStore.apiUrl} onChange={e => setEditingStore({...editingStore, apiUrl: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-indigo-400 font-mono text-xs outline-none focus:border-indigo-500" placeholder="https://..." />
                        </div>
                        <div>
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2 px-2">مفتاح الوصول (API Key / Access Token)</label>
                            <input type="password" value={editingStore.apiKey} onChange={e => setEditingStore({...editingStore, apiKey: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white font-mono text-xs outline-none focus:border-indigo-500" placeholder="••••••••••••••••" />
                        </div>
                    </div>
                    <div className="flex gap-4 mt-8 pt-4 border-t border-white/5">
                        <button onClick={saveExternalStore} className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white py-4 rounded-xl font-black text-sm transition-all shadow-xl active:scale-95">حفظ بيانات الربط</button>
                        <button onClick={() => setEditingStore(null)} className="flex-1 bg-white/5 text-white py-4 rounded-xl font-black text-sm transition-all">إلغاء</button>
                    </div>
                </div>
            )}
        </div>

        {/* System Control */}
        <div className="glass-card p-8 rounded-[2.5rem] border border-white/5">
            <SectionHeader icon={Shield} title="التحكم بالنظام" desc="إدارة الوصول وحالة الموقع" />
            <div className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-slate-900/50 rounded-2xl border border-white/5">
                    <div>
                        <h4 className="text-white font-bold text-sm">وضع الصيانة</h4>
                        <p className="text-[10px] text-slate-500 mt-1">إيقاف الموقع مؤقتاً لجميع المستخدمين</p>
                    </div>
                    <button 
                        onClick={() => handleChange('maintenanceMode', !formData.maintenanceMode)}
                        className={`text-2xl transition-colors ${formData.maintenanceMode ? 'text-rose-500' : 'text-slate-600'}`}
                    >
                        {formData.maintenanceMode ? <ToggleRight className="w-10 h-10" /> : <ToggleLeft className="w-10 h-10" />}
                    </button>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-900/50 rounded-2xl border border-white/5">
                    <div>
                        <h4 className="text-white font-bold text-sm">التسجيل الجديد</h4>
                        <p className="text-[10px] text-slate-500 mt-1">السماح للمستخدمين الجدد بإنشاء حسابات</p>
                    </div>
                    <button 
                        onClick={() => handleChange('allowRegistrations', !formData.allowRegistrations)}
                        className={`text-2xl transition-colors ${formData.allowRegistrations ? 'text-emerald-500' : 'text-slate-600'}`}
                    >
                        {formData.allowRegistrations ? <ToggleRight className="w-10 h-10" /> : <ToggleLeft className="w-10 h-10" />}
                    </button>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-900/50 rounded-2xl border border-white/5">
                    <div>
                        <h4 className="text-white font-bold text-sm">تحديث أسعار تلقائي</h4>
                        <p className="text-[10px] text-slate-500 mt-1">جلب أسعار العملات من API خارجي</p>
                    </div>
                    <button 
                        onClick={() => handleChange('autoUpdateRates', !formData.autoUpdateRates)}
                        className={`text-2xl transition-colors ${formData.autoUpdateRates ? 'text-blue-500' : 'text-slate-600'}`}
                    >
                        {formData.autoUpdateRates ? <ToggleRight className="w-10 h-10" /> : <ToggleLeft className="w-10 h-10" />}
                    </button>
                </div>
            </div>
        </div>

        {/* Financial Settings */}
        <div className="glass-card p-8 rounded-[2.5rem] border border-white/5">
            <SectionHeader icon={DollarSign} title="السياسة المالية" desc="الرسوم والحدود المالية الافتراضية" />
            <div className="grid grid-cols-2 gap-6">
                <div>
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2">نسبة رسوم التحويل (%)</label>
                    <div className="relative">
                        <Percent className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <input 
                            type="number" 
                            value={formData.transferFeePercentage}
                            onChange={(e) => handleChange('transferFeePercentage', parseFloat(e.target.value))}
                            className="w-full bg-slate-900/50 border border-white/10 rounded-xl py-4 pr-10 pl-4 text-white font-bold focus:border-emerald-500 outline-none"
                        />
                    </div>
                </div>
                <div>
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2">رسوم الشحن اليدوي (%)</label>
                    <div className="relative">
                        <Percent className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <input 
                            type="number" 
                            value={formData.manualTopUpFeePercentage}
                            onChange={(e) => handleChange('manualTopUpFeePercentage', parseFloat(e.target.value))}
                            className="w-full bg-slate-900/50 border border-white/10 rounded-xl py-4 pr-10 pl-4 text-white font-bold focus:border-emerald-500 outline-none"
                        />
                    </div>
                </div>
                <div>
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2">حد الرصيد المنخفض</label>
                    <div className="relative">
                        <AlertTriangle className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-500" />
                        <input 
                            type="number" 
                            value={formData.lowBalanceThreshold}
                            onChange={(e) => handleChange('lowBalanceThreshold', parseFloat(e.target.value))}
                            className="w-full bg-slate-900/50 border border-white/10 rounded-xl py-4 pr-10 pl-4 text-white font-bold focus:border-emerald-500 outline-none"
                        />
                    </div>
                </div>
                <div>
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2">الحد الأقصى للعملية</label>
                    <div className="relative">
                        <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <input 
                            type="number" 
                            value={formData.maxTransactionLimit || 0}
                            onChange={(e) => handleChange('maxTransactionLimit', parseFloat(e.target.value))}
                            className="w-full bg-slate-900/50 border border-white/10 rounded-xl py-4 pr-10 pl-4 text-white font-bold focus:border-emerald-500 outline-none"
                        />
                    </div>
                </div>
            </div>
        </div>

        {/* API Integrations */}
        <div className="glass-card p-8 rounded-[2.5rem] border border-white/5">
            <SectionHeader icon={Activity} title="التكامل البرمجي" desc="مفاتيح الربط والخدمات الخارجية" />
            <div className="space-y-5">
                <div>
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest block mb-2">Exchange Rate API Key</label>
                    <div className="relative">
                        <input 
                            type="password" 
                            value={formData.exchangeRateApiKey || ''}
                            onChange={(e) => handleChange('exchangeRateApiKey', e.target.value)}
                            className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 text-white font-mono text-xs focus:border-emerald-500 outline-none transition-colors"
                            placeholder="sk_live_..."
                        />
                    </div>
                    <p className="text-[10px] text-slate-600 mt-2">يستخدم لجلب أسعار العملات العالمية لحظياً.</p>
                </div>
                
                <div className="bg-blue-500/5 p-4 rounded-xl border border-blue-500/10 flex items-start gap-3">
                    <CreditCard className="w-5 h-5 text-blue-400 mt-1" />
                    <div>
                        <h4 className="text-white font-bold text-xs">بوابات الدفع</h4>
                        <p className="text-[10px] text-slate-500 mt-1">يتم إدارة بوابات الدفع اليدوية والإلكترونية من خلال قسم "المالية" في القائمة الجانبية.</p>
                    </div>
                </div>
            </div>
        </div>

      </div>
    </div>
  );
};

export default SettingsPanel;
