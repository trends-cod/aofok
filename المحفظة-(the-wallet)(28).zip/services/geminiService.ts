
import { GoogleGenAI } from "@google/genai";
import { User, Transaction } from "../types";

// Initialize the API client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface ChatHistoryMessage {
  role: 'user' | 'model';
  parts: [{ text: string }];
}

export const getFinancialAdvice = async (
  query: string,
  userContext: User,
  transactions: Transaction[],
  history: ChatHistoryMessage[] = []
): Promise<string> => {
  try {
    const modelName = 'gemini-3-pro-preview';
    
    const systemInstruction = `
      أنت "أفق AI"، المستشار المالي الأول والخبير في إدارة الأصول الرقمية داخل تطبيق "محفظة أفق".
      صفتك: ذكي جداً، دقيق في الأرقام، تتحدث العربية الفصحى المهنية بأسلوب ودي.
      
      سياق المستخدم الحالي:
      - الاسم: ${userContext.name}
      - كود المستخدم: ${userContext.userCode}
      - الأرصدة الحالية: ${userContext.wallets.map(w => `${w.balance} ${w.currency}`).join(' | ')}
      - إجمالي الثروة المقدر بالدولار: ${userContext.wallets.reduce((acc, w) => acc + (w.balance * 1), 0)} (ملاحظة: السيرفر يحسب القيم الحقيقية).
      
      تاريخ العمليات (آخر 20 عملية):
      ${JSON.stringify(transactions.slice(0, 20))}

      مهامك الأساسية:
      1. تحليل أنماط الإنفاق: إذا كانت العمليات كثيرة في "شراء الألعاب"، نبه المستخدم للادخار.
      2. نصائح الصرف: اقترح أفضل وقت لتحويل العملات بناءً على رصيد المستخدم.
      3. الإجابة عن الأسئلة التقنية: اشرح كيفية استخدام "بوابات الدفع" أو "نظام التحويل" داخل التطبيق.
      4. كن استباقياً: إذا كان الرصيد في محفظة USD منخفضاً (أقل من 10)، اقترح عليه الشحن عبر "Top-Up".
      
      قواعد الإجابة:
      - استخدم جداول Markdown عند مقارنة الأسعار أو العملات.
      - لا تقدم وعوداً مالية كاذبة، كن واقعياً.
      - إذا سألك المستخدم عن شيء خارج الشؤون المالية، وجهه بلطف للعودة لموضوع المحفظة.
    `;

    // Format the contents to include history + current query
    const contents = [
      ...history,
      { role: 'user', parts: [{ text: query }] }
    ];

    const response = await ai.models.generateContent({
      model: modelName,
      contents: contents as any,
      config: {
        systemInstruction: systemInstruction,
        thinkingConfig: { thinkingBudget: 32768 },
        temperature: 0.7,
      }
    });

    return response.text || "عذراً، لم أتمكن من استخلاص تحليل مالي دقيق حالياً.";
  } catch (error) {
    console.error("Gemini Advisor Error:", error);
    return "حدث خطأ تقني أثناء محاولة تحليل بياناتك المالية. يرجى التأكد من استقرار الاتصال والمحاولة مرة أخرى.";
  }
};
