
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  Wallet, 
  Bot, 
  Menu, 
  X,
  Bell,
  ArrowRightLeft, 
  RefreshCcw,
  LogOut,
  CreditCard,
  AlertTriangle,
  Check,
  Shield,
  LayoutDashboard,
  User as UserIcon,
  CheckCircle,
  XCircle,
  Info,
  ArrowUpRight,
  Users,
  Coins,
  Gem,
  Store,
  ArrowLeft,
  Gamepad2,
  Code,
  MessageCircle,
  Settings2,
  ChevronUp,
  ChevronDown,
  GripVertical,
  History,
  ArrowDownLeft,
  ShoppingCart,
  Send,
  Clock,
  Activity,
  ExternalLink,
  UserCircle
} from 'lucide-react';
import { View, User, CustomPage, Transaction, TransactionType, TransactionStatus, StoreSettings } from '../types';
import { useLanguage } from '../i18n';
import { APP_VERSION } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  activeView: View;
  onNavigate: (view: View, params?: any) => void;
  onBack: () => void;
  canGoBack: boolean;
  user: User;
  onLogout: () => void;
  onMarkNotificationsRead: () => void;
  pages?: CustomPage[];
  transactions: Transaction[];
  settings: StoreSettings;
}

const DEFAULT_NAV_ORDER: View[] = [
  View.DASHBOARD,
  View.WALLET,
  View.TOPUP,
  View.TRANSFER,
  View.EXCHANGE,
  View.WITHDRAWAL,
  View.GAMES,
  View.COMMUNITY,
  View.PROFILE,
  View.AI_ADVISOR,
  View.DEVELOPER,
];

const Layout: React.FC<LayoutProps> = ({ children, activeView, onNavigate, onBack, canGoBack, user, onLogout, onMarkNotificationsRead, pages = [], transactions, settings }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isEditingNav, setIsEditingNav] = useState(false);
  const [orderedNavIds, setOrderedNavIds] = useState<View[]>(() => {
    // We prioritize the hardcoded default to ensure new features appear, 
    // effectively resetting user pref if it misses keys, or we can just use default for now.
    // To respect user changes but ensure new keys:
    const saved = localStorage.getItem('horizon_nav_order');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Merge parsed with DEFAULT to ensure nothing is missing
        const unique = Array.from(new Set([...parsed, ...DEFAULT_NAV_ORDER]));
        return unique.filter((id: View) => DEFAULT_NAV_ORDER.includes(id));
      } catch (e) {
        return DEFAULT_NAV_ORDER;
      }
    }
    return DEFAULT_NAV_ORDER;
  });

  const { t, dir } = useLanguage();
  const notificationRef = useRef<HTMLDivElement>(null);

  const isAdmin = ['super_admin', 'admin', 'moderator'].includes(user.role);
  const unreadCount = user.notifications.filter(n => !n.isRead).length;

  const userTransactions = useMemo(() => {
    return transactions
      .filter(tx => tx.userId === user.id)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 15);
  }, [transactions, user.id]);

  useEffect(() => {
    localStorage.setItem('horizon_nav_order', JSON.stringify(orderedNavIds));
  }, [orderedNavIds]);

  const allNavItems = useMemo(() => ({
    [View.DASHBOARD]: { label: t('nav_dashboard'), icon: LayoutDashboard },
    [View.WALLET]: { label: t('nav_wallet'), icon: Wallet }, 
    [View.PROFILE]: { label: 'حسابي', icon: UserCircle },
    [View.GAMES]: { label: t('nav_games'), icon: Gamepad2, badge: 'HOT', badgeColor: 'bg-amber-500' },
    [View.COMMUNITY]: { label: t('nav_community'), icon: MessageCircle, badge: 'LIVE', badgeColor: 'bg-purple-500' },
    [View.TOPUP]: { label: t('nav_topup'), icon: CreditCard },
    [View.WITHDRAWAL]: { label: t('nav_withdrawal'), icon: ArrowUpRight },
    [View.TRANSFER]: { label: t('nav_transfer'), icon: ArrowRightLeft },
    [View.EXCHANGE]: { label: t('nav_exchange'), icon: RefreshCcw },
    [View.AI_ADVISOR]: { label: t('nav_ai'), icon: Bot },
    [View.DEVELOPER]: { label: t('nav_developer'), icon: Code },
  }), [t]);

  const moveItem = (index: number, direction: 'up' | 'down') => {
    const newOrder = [...orderedNavIds];
    const swapIndex = direction === 'up' ? index - 1 : index + 1;
    if (swapIndex >= 0 && swapIndex < newOrder.length) {
      [newOrder[index], newOrder[swapIndex]] = [newOrder[swapIndex], newOrder[index]];
      setOrderedNavIds(newOrder);
    }
  };

  const handleLogoutClick = () => {
    setShowLogoutConfirm(true);
    setIsMobileMenuOpen(false);
  };

  const toggleNotifications = () => {
    setIsNotificationsOpen(prev => {
        if (!prev) { 
            onMarkNotificationsRead();
        }
        return !prev;
    });
  };
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const getNotificationIcon = (type: 'success' | 'error' | 'info') => {
    switch (type) {
      case 'success': return <CheckCircle className="w-4 h-4 text-emerald-500" />;
      case 'error': return <XCircle className="w-4 h-4 text-rose-500" />;
      case 'info':
      default: return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getTxIcon = (type: TransactionType) => {
    switch(type) {
        case TransactionType.DEPOSIT: return <ArrowDownLeft className="text-emerald-500" size={16} />;
        case TransactionType.WITHDRAWAL: return <ArrowUpRight className="text-rose-500" size={16} />;
        case TransactionType.TRANSFER: return <Send className="text-indigo-500" size={16} />;
        case TransactionType.PURCHASE: return <ShoppingCart className="text-amber-500" size={16} />;
        case TransactionType.EXCHANGE: return <RefreshCcw className="text-blue-500" size={16} />;
        default: return <History className="text-slate-500" size={16} />;
    }
  };

  return (
    <div className="min-h-screen bg-transparent flex font-sans selection:bg-emerald-500 selection:text-white" dir={dir}>
      <aside className={`
          lg:flex fixed top-0 bottom-0 right-0 z-50 w-72 p-4 transition-all duration-300
          ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
      `}>
        <div className="w-full h-full glass-card rounded-[2.5rem] border border-white/5 flex flex-col shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-transparent"></div>
            
            {/* Emerald Glass Profile Card */}
            <div className="relative m-4 p-6 rounded-[2.5rem] bg-gradient-to-b from-white/5 to-transparent border border-white/5 shadow-2xl overflow-hidden group">
                <div className="absolute inset-0 bg-emerald-500/10 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                
                <div className="relative z-10 flex flex-col items-center">
                    <div 
                      onClick={() => onNavigate(View.PROFILE)}
                      className="w-24 h-24 rounded-[2rem] p-1 bg-gradient-to-br from-emerald-500 to-emerald-700 shadow-2xl cursor-pointer hover:scale-105 transition-transform duration-500"
                    >
                        <div className="w-full h-full rounded-[1.8rem] overflow-hidden bg-[#020617] relative">
                            {user.avatar ? (
                                <img src={user.avatar} className="w-full h-full object-cover" />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center bg-slate-900 text-white font-black text-3xl uppercase">
                                    {user.name[0]}
                                </div>
                            )}
                        </div>
                    </div>
                    
                    <h3 className="text-white font-black text-lg mt-4 text-center">{user.name}</h3>
                    <p className="text-emerald-400 text-[10px] font-bold uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full mt-2 border border-emerald-500/20">{user.role}</p>
                    
                    <div className="flex gap-3 w-full mt-6">
                        <button 
                            onClick={handleLogoutClick}
                            className="flex-1 py-4 bg-rose-500/10 hover:bg-rose-500 text-rose-500 hover:text-white rounded-2xl border border-rose-500/20 transition-all active:scale-95 flex items-center justify-center"
                        >
                            <LogOut size={18} />
                        </button>
                        <button 
                            onClick={() => setIsEditingNav(!isEditingNav)}
                            className={`flex-1 py-4 rounded-2xl border transition-all active:scale-95 flex items-center justify-center ${isEditingNav ? 'bg-emerald-500 text-white border-emerald-500' : 'bg-white/5 text-slate-400 hover:text-white border-white/10 hover:bg-white/10'}`}
                        >
                            <Settings2 size={18} />
                        </button>
                    </div>
                </div>
            </div>

            <div className="h-[1px] mx-8 my-2 bg-white/5"></div>

            <nav className="flex-1 overflow-y-auto py-2 px-4 space-y-2 scrollbar-hide relative z-10">
                {orderedNavIds.map((id, index) => {
                    const item = (allNavItems as any)[id];
                    if (!item) return null;
                    const Icon = item.icon;
                    const isActive = activeView === id;

                    return (
                      <div key={id} className="relative group/nav">
                        <button
                            onClick={() => !isEditingNav && onNavigate(id)}
                            disabled={isEditingNav}
                            className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 group relative overflow-hidden ${
                                isActive && !isEditingNav
                                ? 'bg-emerald-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)] translate-x-[-5px] border border-emerald-400/20' 
                                : isEditingNav ? 'bg-white/5 text-slate-300 border border-white/5 cursor-default' : 'text-slate-400 hover:text-white hover:bg-white/5'
                            }`}
                        >
                            <Icon className={`w-5 h-5 transition-colors ${isActive ? 'text-white' : 'text-slate-500 group-hover:text-white'}`} />
                            <span className="font-bold text-xs uppercase tracking-widest">{item.label}</span>
                        </button>
                      </div>
                    );
                })}

                {/* Custom Pages Added by Admin */}
                {pages.filter(p => p.isActive && p.showInSidebar).map(p => (
                   <button
                    key={p.id}
                    onClick={() => onNavigate(View.CUSTOM_PAGE, { pageId: p.id })}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl text-slate-400 hover:text-white hover:bg-white/5 transition-all"
                  >
                    <span className="text-lg w-5 text-center">{p.icon || '📄'}</span>
                    <span className="font-bold text-xs uppercase tracking-widest">{p.title}</span>
                  </button>
                ))}

                {isAdmin && (
                    <>
                        <div className="my-2 h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
                        <button
                            onClick={() => onNavigate(View.ADMIN)}
                            className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all group border ${
                                activeView === View.ADMIN 
                                ? 'bg-rose-600 text-white border-rose-500 shadow-[0_0_20px_rgba(225,29,72,0.4)]' 
                                : 'bg-rose-500/5 text-rose-500 border-rose-500/20 hover:bg-rose-500 hover:text-white'
                            }`}
                        >
                            <Shield className="w-5 h-5" />
                            <span className="font-bold text-xs uppercase tracking-widest">لوحة الإدارة</span>
                        </button>
                    </>
                )}
            </nav>
            <div className="p-4 text-center border-t border-white/5 relative z-10 bg-black/20">
                <p className="text-[9px] text-slate-600 font-black uppercase tracking-widest">Horizon Wallet Ver {APP_VERSION}</p>
            </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col lg:mr-72 min-h-screen transition-all duration-300 relative">
          <header className="sticky top-0 z-40 px-6 py-4">
              <div className="glass-card container mx-auto rounded-[2rem] h-20 px-8 flex justify-between items-center border border-white/5 shadow-2xl">
                <div className="flex items-center gap-6">
                    <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden text-white bg-white/5 p-2 rounded-xl active:scale-95 transition-all">
                      {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                    </button>
                    <div className="flex items-center gap-4">
                        {canGoBack && (
                            <button onClick={onBack} className="p-2.5 bg-emerald-500/10 hover:bg-emerald-500 text-emerald-500 hover:text-white rounded-xl border border-emerald-500/20 transition-all active:scale-90 flex items-center justify-center">
                                <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
                            </button>
                        )}
                        <div className="hidden lg:flex flex-col">
                            <span className="text-[10px] text-emerald-500 font-black uppercase tracking-[0.2em] leading-none mb-1">
                                {t('welcome')}, {user.name.split(' ')[0]}!
                            </span>
                            <h2 className="flex items-center gap-3 text-lg font-black text-white/80 uppercase tracking-widest">
                                {settings.siteName || 'أفق'}
                            </h2>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-3" ref={notificationRef}>
                    <button onClick={toggleNotifications} className={`relative p-3 rounded-xl transition-all active:scale-90 border ${isNotificationsOpen ? 'bg-emerald-600 text-white border-emerald-500 shadow-lg' : 'bg-white/5 text-slate-400 hover:text-white border-white/5'}`}>
                        <Bell className="w-5 h-5" />
                        {unreadCount > 0 && <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[9px] font-black rounded-full border-2 border-[#030712] flex items-center justify-center animate-bounce">{unreadCount}</span>}
                    </button>
                    {isNotificationsOpen && (
                        <div className="absolute top-24 left-0 w-[600px] max-h-[500px] glass-card rounded-[2.5rem] border border-white/10 shadow-[0_30px_60px_rgba(0,0,0,0.6)] flex overflow-hidden animate-in fade-in zoom-in-95 duration-200 z-[100]" dir="rtl">
                           <div className="flex-1 flex flex-col border-l border-white/5 bg-black/20">
                               <div className="p-6 border-b border-white/5 flex justify-between items-center bg-slate-900/50">
                                   <h3 className="font-black text-white text-xs uppercase tracking-widest flex items-center gap-2"><Bell className="w-4 h-4 text-emerald-500" /> الإشعارات</h3>
                               </div>
                               <div className="flex-1 overflow-y-auto scrollbar-hide">
                                   {user.notifications.length > 0 ? (
                                       user.notifications.slice(0, 10).map(n => (
                                           <div key={n.id} className="p-5 flex gap-4 border-b border-white/5 hover:bg-white/5 transition-all">
                                               <div className="shrink-0 mt-1">{getNotificationIcon(n.type)}</div>
                                               <div className="flex-1">
                                                   <p className={`font-black text-xs mb-1 ${!n.isRead ? 'text-white' : 'text-slate-300'}`}>{n.title}</p>
                                                   <p className="text-slate-500 text-[10px] leading-relaxed line-clamp-2">{n.message}</p>
                                               </div>
                                           </div>
                                       ))
                                   ) : (
                                       <div className="p-10 text-center opacity-20 h-full flex flex-col items-center justify-center"><Bell className="w-12 h-12 mb-3" /><p className="text-xs font-bold">لا يوجد تنبيهات</p></div>
                                   )}
                               </div>
                           </div>
                           <div className="flex-1 flex flex-col bg-[#030712]/40">
                               <div className="p-6 border-b border-white/5 flex justify-between items-center bg-slate-900/50">
                                   <h3 className="font-black text-white text-xs uppercase tracking-widest flex items-center gap-2"><Activity className="w-4 h-4 text-blue-500" /> العمليات الأخيرة</h3>
                               </div>
                               <div className="flex-1 overflow-y-auto scrollbar-hide">
                                   {userTransactions.length > 0 ? (
                                       userTransactions.map(tx => (
                                           <div key={tx.id} className="p-5 flex items-center gap-4 border-b border-white/5 hover:bg-white/[0.02] transition-all">
                                               <div className="w-10 h-10 rounded-xl bg-slate-800/50 border border-white/5 flex items-center justify-center shrink-0">{getTxIcon(tx.type)}</div>
                                               <div className="flex-1 min-w-0">
                                                   <div className="flex justify-between items-start mb-0.5">
                                                        <p className="text-white font-black text-[11px] truncate">{tx.description.split('|')[0]}</p>
                                                        <span className={`text-[10px] font-mono font-black ${tx.type === TransactionType.DEPOSIT ? 'text-emerald-500' : 'text-slate-300'}`}>{tx.amount}</span>
                                                   </div>
                                                   <span className="text-slate-600 text-[8px] font-mono">{new Date(tx.date).toLocaleDateString('ar-EG')}</span>
                                               </div>
                                           </div>
                                       ))
                                   ) : (
                                       <div className="p-10 text-center opacity-20 h-full flex flex-col items-center justify-center"><History className="w-12 h-12 mb-3" /><p className="text-xs font-bold">لا يوجد عمليات</p></div>
                                   )}
                               </div>
                           </div>
                        </div>
                    )}
                    <button 
                      onClick={() => onNavigate(View.PROFILE)}
                      className="p-3 bg-white/5 text-slate-400 hover:text-emerald-500 rounded-xl transition-all active:scale-90 border border-white/5"
                    >
                        <UserCircle className="w-5 h-5" />
                    </button>
                </div>
              </div>
          </header>
          <main className="container mx-auto max-w-7xl pt-4 px-6 flex-1 relative">{children}</main>
          <footer className="py-8 px-6 relative z-10 text-center">
              <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-white/10 to-transparent mb-8"></div>
              <p className="text-slate-600 text-xs font-black uppercase tracking-[0.5em]">{settings.siteName} &copy; 2025</p>
          </footer>
      </div>

      {showLogoutConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-2xl animate-in fade-in duration-300">
           <div className="glass-card w-full max-w-md rounded-[3rem] border border-white/10 overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.8)] animate-in zoom-in-95 duration-500">
              <div className="p-10 text-center flex flex-col items-center">
                  <div className="w-20 h-20 bg-rose-500/20 rounded-full flex items-center justify-center mb-8 border border-rose-500/20 shadow-[0_0_40px_rgba(244,63,94,0.1)]">
                      <AlertTriangle className="w-10 h-10 text-rose-500" />
                  </div>
                  <h3 className="text-2xl font-black text-white mb-2">{t('logout_confirmation')}</h3>
                  <p className="text-slate-400 text-sm font-medium leading-relaxed px-4">{t('logout_message')}</p>
              </div>
              <div className="p-10 pt-0 flex gap-4">
                  <button onClick={() => setShowLogoutConfirm(false)} className="flex-1 bg-white/5 hover:bg-white/10 text-white py-5 rounded-2xl font-black text-xs uppercase transition-all">تراجع</button>
                  <button onClick={() => { onLogout(); setShowLogoutConfirm(false); }} className="flex-[2] bg-rose-600 hover:bg-rose-500 text-white py-5 rounded-2xl font-black text-xs uppercase transition-all shadow-xl flex items-center justify-center gap-2 glossy-shine">
                    <Check className="w-4 h-4" /> خروج آمن
                  </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Layout;
