
import React, { useState, useMemo } from 'react';
import { User, ApiKey, WebHook, DevEvent } from '../types';
import { 
  Terminal, Key, Plus, Trash2, Copy, Check, Eye, Code, 
  Globe, ShieldAlert, X, Settings2, BellRing, Activity, 
  ToggleLeft, ToggleRight, Edit3, Lock, ShieldCheck, Zap,
  Link as LinkIcon, Info, Play, Clock, Filter, Search, ChevronRight, AlertTriangle
} from 'lucide-react';

interface DeveloperToolsProps {
  user: User;
  onCreateApiKey: (name: string, permissions: string[]) => Promise<string>;
  onRevokeApiKey: (id: string) => void;
  onUpdateApiKeyPermissions: (id: string, permissions: string[]) => void;
  onAddWebhook: (webhook: Omit<WebHook, 'id' | 'createdAt' | 'secret'>) => void;
  onToggleWebhook: (id: string) => void;
  onDeleteWebhook: (id: string) => void;
  onTestWebhook?: (id: string) => void;
}

const AVAILABLE_PERMISSIONS = [
  { id: 'read_balance', label: 'قراءة الأرصدة', desc: 'الوصول إلى أرصدة المحافظ الرقمية', category: 'Security' },
  { id: 'execute_transfer', label: 'إرسال حوالات', desc: 'إجراء عمليات تحويل مالي مباشر', category: 'Financial' },
  { id: 'read_history', label: 'سجل العمليات', desc: 'عرض تاريخ الحركات المالية بالتفصيل', category: 'Data' },
  { id: 'manage_keys', label: 'إدارة المفاتيح', desc: 'إنشاء وحذف مفاتيح API فرعية', category: 'Admin' },
  { id: 'webhook_config', label: 'تكوين الـ Webhooks', desc: 'تعديل روابط استقبال الإشعارات', category: 'Admin' },
];

const AVAILABLE_WEBHOOK_EVENTS = [
  { id: 'transaction.completed', label: 'اكتمال العملية', desc: 'عند نجاح أي معاملة مالية' },
  { id: 'transaction.failed', label: 'فشل العملية', desc: 'عند رفض أو فشل معاملة' },
  { id: 'deposit.received', label: 'إيداع جديد', desc: 'عند استلام دفعة في الرصيد' },
  { id: 'transfer.sent', label: 'حوالة صادرة', desc: 'عند إرسال أموال لمستلم' },
];

const DeveloperTools: React.FC<DeveloperToolsProps> = ({ 
  user, onCreateApiKey, onRevokeApiKey, onUpdateApiKeyPermissions,
  onAddWebhook, onToggleWebhook, onDeleteWebhook, onTestWebhook
}) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'KEYS' | 'WEBHOOKS' | 'LOGS'>('OVERVIEW');
  const [isCreating, setIsCreating] = useState(false);
  const [isCreatingWebhook, setIsCreatingWebhook] = useState(false);
  const [editingKeyPermissions, setEditingKeyPermissions] = useState<ApiKey | null>(null);

  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyPermissions, setNewKeyPermissions] = useState<string[]>(['read_balance']);
  
  const [newWhUrl, setNewWhUrl] = useState('');
  const [newWhEvents, setNewWhEvents] = useState<string[]>(['transaction.completed']);

  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [whSecretVisible, setWhSecretVisible] = useState<string | null>(null);

  const [logSearch, setLogSearch] = useState('');

  const filteredLogs = useMemo(() => {
    return (user.devEvents || []).filter(log => 
      log.target.toLowerCase().includes(logSearch.toLowerCase()) || 
      log.details.toLowerCase().includes(logSearch.toLowerCase())
    );
  }, [user.devEvents, logSearch]);

  const handleCreateKey = async () => {
    if (!newKeyName.trim()) return;
    const key = await onCreateApiKey(newKeyName, newKeyPermissions);
    setGeneratedKey(key);
    setIsCreating(false);
    setNewKeyName('');
    setNewKeyPermissions(['read_balance']);
  };

  const handleCreateWebhook = () => {
    if (!newWhUrl.trim()) return;
    onAddWebhook({
      url: newWhUrl,
      events: newWhEvents,
      isActive: true
    });
    setIsCreatingWebhook(false);
    setNewWhUrl('');
    setNewWhEvents(['transaction.completed']);
  };

  const togglePermission = (id: string) => {
    setNewKeyPermissions(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]);
  };

  const toggleWhEvent = (id: string) => {
    setNewWhEvents(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);
  };

  const handleUpdatePermissions = () => {
    if (editingKeyPermissions) {
      onUpdateApiKeyPermissions(editingKeyPermissions.id, editingKeyPermissions.permissions);
      setEditingKeyPermissions(null);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20" dir="rtl">
      
      {/* Dynamic Dev Header */}
      <div className="bg-[#020617] rounded-[3.5rem] p-10 md:p-14 border border-white/5 shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-emerald-500/5 blur-[120px] pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="text-right">
            <h1 className="text-4xl font-black text-white flex items-center gap-6">
              <div className="p-5 bg-emerald-600 rounded-[2rem] shadow-2xl shadow-emerald-900/40 transform -rotate-3 group-hover:rotate-0 transition-transform">
                <Terminal className="w-10 h-10 text-white" />
              </div>
              مركز المطورين <span className="text-emerald-500 text-xl font-mono">v3.2</span>
            </h1>
            <p className="text-slate-500 font-bold mt-5 text-lg max-w-2xl leading-relaxed">
              تحكم برمجياً في مواردك المالية عبر واجهة API موحدة. قم بإدارة مفاتيح الوصول، تخصيص الصلاحيات، ومراقبة الأحداث لحظياً.
            </p>
          </div>
          
          <div className="bg-slate-900/50 p-2 rounded-3xl border border-white/5 flex gap-2 w-full md:w-auto">
            {[
              { id: 'OVERVIEW', label: 'نظرة عامة', icon: Activity },
              { id: 'KEYS', label: 'المفاتيح', icon: Key },
              { id: 'WEBHOOKS', label: 'Webhooks', icon: BellRing },
              { id: 'LOGS', label: 'السجلات', icon: Clock }
            ].map(tab => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 md:px-8 py-4 rounded-2xl text-xs font-black transition-all flex items-center justify-center gap-2 ${activeTab === tab.id ? 'bg-emerald-600 text-white shadow-xl' : 'text-slate-500 hover:text-white'}`}
              >
                <tab.icon size={14} />
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Main Interface Content */}
        <div className="lg:col-span-8 space-y-8">
          
          {activeTab === 'OVERVIEW' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in">
              <div className="glass-card p-10 rounded-[3rem] border border-white/5 group hover:border-emerald-500/30 transition-all">
                <div className="flex justify-between items-start mb-6">
                  <div className="p-4 bg-emerald-500/10 rounded-2xl text-emerald-500"><Key size={32}/></div>
                  <button onClick={() => setActiveTab('KEYS')} className="text-slate-500 hover:text-white"><ChevronRight size={24} className="rtl:rotate-180"/></button>
                </div>
                <h3 className="text-2xl font-black text-white mb-2">مفاتيح الـ API</h3>
                <p className="text-slate-500 text-sm font-bold mb-8">لديك {user.apiKeys.length} مفاتيح نشطة حالياً تستخدم للوصول البرمجي.</p>
                <button onClick={() => setIsCreating(true)} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-900/20 active:scale-95 transition-all">توليد مفتاح جديد</button>
              </div>

              <div className="glass-card p-10 rounded-[3rem] border border-white/5 group hover:border-indigo-500/30 transition-all">
                <div className="flex justify-between items-start mb-6">
                  <div className="p-4 bg-indigo-500/10 rounded-2xl text-indigo-500"><BellRing size={32}/></div>
                  <button onClick={() => setActiveTab('WEBHOOKS')} className="text-slate-500 hover:text-white"><ChevronRight size={24} className="rtl:rotate-180"/></button>
                </div>
                <h3 className="text-2xl font-black text-white mb-2">الـ Webhooks</h3>
                <p className="text-slate-500 text-sm font-bold mb-8">تستقبل {user.webhooks.length} روابط إشعارات فورية عند حدوث عمليات مالية.</p>
                <button onClick={() => setIsCreatingWebhook(true)} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-indigo-900/20 active:scale-95 transition-all">إضافة رابط استقبال</button>
              </div>

              <div className="lg:col-span-2 glass-card p-10 rounded-[3rem] border border-white/5">
                <div className="flex items-center gap-4 mb-8">
                  <div className="p-3 bg-white/5 rounded-xl text-slate-400"><Clock size={20}/></div>
                  <h3 className="text-xl font-black text-white">آخر النشاطات البرمجية</h3>
                </div>
                <div className="space-y-4">
                  {user.devEvents.slice(0, 3).map(ev => (
                    <div key={ev.id} className="flex items-center justify-between p-5 bg-black/20 rounded-[1.8rem] border border-white/5">
                      <div className="flex items-center gap-4">
                        <div className={`w-2 h-2 rounded-full ${ev.status === 'success' ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
                        <div>
                          <p className="text-white font-black text-xs">{ev.details}</p>
                          <p className="text-slate-500 text-[10px] font-mono mt-1">{ev.target}</p>
                        </div>
                      </div>
                      <span className="text-[9px] text-slate-600 font-bold">{new Date(ev.timestamp).toLocaleTimeString('ar-EG')}</span>
                    </div>
                  ))}
                  {(!user.devEvents || user.devEvents.length === 0) && <p className="text-center text-slate-700 py-10 italic">لا توجد سجلات بعد...</p>}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'KEYS' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
               <div className="flex justify-between items-center px-4">
                  <h3 className="text-2xl font-black text-white flex items-center gap-3"><Key className="text-emerald-500"/> إدارة المفاتيح</h3>
                  <button onClick={() => setIsCreating(true)} className="p-3 bg-emerald-600 text-white rounded-xl shadow-lg active:scale-90 transition-all"><Plus/></button>
               </div>
               <div className="space-y-4">
                  {user.apiKeys.length === 0 ? (
                    <div className="p-20 text-center glass-card rounded-[3rem] border-dashed border-white/5 opacity-50"><Key size={48} className="mx-auto mb-4 text-slate-700"/><p className="text-sm font-bold">لم تقم بإنشاء أي مفاتيح API بعد.</p></div>
                  ) : user.apiKeys.map(key => (
                    <div key={key.id} className={`glass-card p-8 rounded-[2.5rem] border transition-all ${key.status === 'active' ? 'border-white/5 hover:border-emerald-500/30' : 'opacity-60 grayscale'}`}>
                       <div className="flex flex-col md:flex-row justify-between gap-6">
                          <div className="space-y-4">
                             <div className="flex items-center gap-3">
                                <span className="text-xl font-black text-white">{key.name}</span>
                                <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase ${key.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>{key.status}</span>
                             </div>
                             <code className="bg-[#030712] px-4 py-2 rounded-xl text-indigo-400 font-mono text-sm border border-white/5">{key.prefix}********************</code>
                             <div className="flex flex-wrap gap-2 pt-2">
                                {key.permissions.map(p => (
                                  <span key={p} className="bg-white/5 text-slate-500 px-2 py-1 rounded text-[8px] font-black uppercase tracking-tighter border border-white/5">
                                    {AVAILABLE_PERMISSIONS.find(ap => ap.id === p)?.label || p}
                                  </span>
                                ))}
                             </div>
                          </div>
                          <div className="flex gap-2 self-start">
                             {key.status === 'active' && (
                               <>
                                 <button onClick={() => setEditingKeyPermissions(key)} className="p-4 bg-white/5 text-slate-400 hover:text-indigo-400 rounded-2xl transition-all border border-white/5"><Settings2 size={20}/></button>
                                 <button onClick={() => onRevokeApiKey(key.id)} className="p-4 bg-white/5 text-slate-400 hover:text-rose-500 rounded-2xl transition-all border border-white/5"><Trash2 size={20}/></button>
                               </>
                             )}
                          </div>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
          )}

          {activeTab === 'WEBHOOKS' && (
             <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
                <div className="flex justify-between items-center px-4">
                  <h3 className="text-2xl font-black text-white flex items-center gap-3"><BellRing className="text-indigo-500"/> روابط الـ Webhooks</h3>
                  <button onClick={() => setIsCreatingWebhook(true)} className="p-3 bg-indigo-600 text-white rounded-xl shadow-lg active:scale-90 transition-all"><Plus/></button>
               </div>
               <div className="space-y-4">
                  {user.webhooks.length === 0 ? (
                    <div className="p-20 text-center glass-card rounded-[3rem] border-dashed border-white/5 opacity-50"><BellRing size={48} className="mx-auto mb-4 text-slate-700"/><p className="text-sm font-bold">لا توجد روابط Webhook مفعلة حالياً.</p></div>
                  ) : user.webhooks.map(wh => (
                    <div key={wh.id} className={`glass-card p-8 rounded-[2.5rem] border transition-all ${wh.isActive ? 'border-white/5 hover:border-indigo-500/30' : 'opacity-60 grayscale'}`}>
                       <div className="flex flex-col md:flex-row justify-between gap-6">
                          <div className="space-y-4 flex-1">
                             <div className="flex items-center gap-3">
                                <div className={`w-3 h-3 rounded-full ${wh.isActive ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-slate-700'}`}></div>
                                <span className="text-sm font-mono font-bold text-slate-300 truncate max-w-md">{wh.url}</span>
                             </div>
                             <div className="flex flex-wrap gap-2 pt-2">
                                {wh.events.map(ev => <span key={ev} className="bg-indigo-500/10 text-indigo-400 px-2 py-1 rounded text-[8px] font-black uppercase tracking-tighter border border-indigo-500/20">{ev}</span>)}
                             </div>
                             <div className="flex items-center gap-3 pt-2">
                                <div className="bg-[#030712] px-3 py-2 rounded-xl border border-white/5 text-[10px] font-mono text-slate-500 flex items-center gap-4">
                                  {whSecretVisible === wh.id ? wh.secret : 'whsec_••••••••••••••••'}
                                  <button onClick={() => setWhSecretVisible(whSecretVisible === wh.id ? null : wh.id)} className="text-slate-600 hover:text-white transition-colors">{whSecretVisible === wh.id ? <X size={14}/> : <Eye size={14} />}</button>
                                </div>
                                {whSecretVisible === wh.id && <button onClick={() => handleCopy(wh.secret)} className="p-2 bg-white/5 rounded-lg text-slate-500 hover:text-emerald-500"><Copy size={14}/></button>}
                             </div>
                          </div>
                          <div className="flex gap-2 self-start">
                             <button onClick={() => onTestWebhook?.(wh.id)} className="p-4 bg-emerald-600/10 text-emerald-500 hover:bg-emerald-600 hover:text-white rounded-2xl transition-all border border-emerald-500/20" title="اختبار الإرسال (Test)"><Play size={20}/></button>
                             <button onClick={() => onToggleWebhook(wh.id)} className={`p-4 rounded-2xl transition-all border ${wh.isActive ? 'bg-slate-800 text-slate-400' : 'bg-indigo-600 text-white'}`}>{wh.isActive ? <ToggleRight size={22}/> : <ToggleLeft size={22}/>}</button>
                             <button onClick={() => onDeleteWebhook(wh.id)} className="p-4 bg-white/5 text-slate-400 hover:text-rose-500 rounded-2xl transition-all border border-white/5"><Trash2 size={20}/></button>
                          </div>
                       </div>
                    </div>
                  ))}
               </div>
             </div>
          )}

          {activeTab === 'LOGS' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
               <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 px-4">
                  <h3 className="text-2xl font-black text-white flex items-center gap-3"><Clock className="text-blue-500"/> سجل العمليات البرمجية</h3>
                  <div className="relative w-full md:w-64">
                    <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600 w-4 h-4"/>
                    <input type="text" placeholder="بحث في السجلات..." value={logSearch} onChange={e => setLogSearch(e.target.value)} className="w-full bg-[#030712] border border-white/10 rounded-2xl py-3 pr-10 pl-4 text-xs font-bold text-white outline-none focus:border-blue-500/50" />
                  </div>
               </div>
               
               <div className="glass-card rounded-[3rem] border border-white/5 overflow-hidden shadow-2xl">
                  <div className="overflow-x-auto scrollbar-hide">
                    <table className="w-full text-right text-sm">
                       <thead className="bg-[#030712] text-slate-500 text-[10px] font-black uppercase tracking-widest border-b border-white/5">
                          <tr>
                             <th className="p-6">النوع</th>
                             <th className="p-6">الهدف (Endpoint/Key)</th>
                             <th className="p-6">التفاصيل</th>
                             <th className="p-6">الحالة</th>
                             <th className="p-6">التوقيت</th>
                          </tr>
                       </thead>
                       <tbody className="divide-y divide-white/5">
                          {filteredLogs.length === 0 ? (
                            <tr><td colSpan={5} className="p-20 text-center text-slate-600 font-bold italic">لا توجد سجلات تطابق بحثك...</td></tr>
                          ) : filteredLogs.map(log => (
                            <tr key={log.id} className="hover:bg-white/[0.02] transition-all group">
                               <td className="p-6">
                                  <span className={`px-2 py-1 rounded text-[8px] font-black uppercase tracking-tighter ${log.type === 'API_CALL' ? 'bg-blue-500/10 text-blue-400' : log.type === 'WEBHOOK_SENT' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>{log.type}</span>
                               </td>
                               <td className="p-6 font-mono text-[10px] text-slate-300 truncate max-w-[150px]">{log.target}</td>
                               <td className="p-6 text-xs text-white font-bold">{log.details}</td>
                               <td className="p-6">
                                  <div className={`flex items-center gap-2 font-black text-[9px] uppercase ${log.status === 'success' ? 'text-emerald-500' : log.status === 'failure' ? 'text-rose-500' : 'text-amber-500'}`}>
                                    {log.status === 'success' ? <Check size={10}/> : log.status === 'failure' ? <X size={10}/> : <AlertTriangle size={10}/>}
                                    {log.status}
                                  </div>
                               </td>
                               <td className="p-6 text-[10px] text-slate-600 font-mono">{new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})}</td>
                            </tr>
                          ))}
                       </tbody>
                    </table>
                  </div>
               </div>
            </div>
          )}

        </div>

        {/* Developer Console / Help Sidebar */}
        <div className="lg:col-span-4 space-y-8">
           
           <div className="glass-card p-10 rounded-[3rem] border border-white/5 bg-[#030712]/50 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl"></div>
              <h4 className="text-white font-black text-sm flex items-center gap-3 mb-6"><Code className="text-blue-400"/> وحدة التحكم المباشرة</h4>
              <div className="bg-[#010409] rounded-2xl p-6 border border-white/10 font-mono text-[11px] h-64 overflow-y-auto scrollbar-hide space-y-3 shadow-inner">
                  <p className="text-slate-600">-- Horizon Terminal Connected --</p>
                  <p className="text-emerald-500/80"># checking_system_status...</p>
                  <p className="text-slate-300">&gt; API V3 Cluster 01: <span className="text-emerald-500">READY</span></p>
                  <p className="text-slate-300">&gt; Webhook Dispatcher: <span className="text-emerald-500">LISTENING</span></p>
                  <div className="h-[1px] bg-white/5 my-2"></div>
                  {user.devEvents.slice(0, 5).map(e => (
                    <p key={e.id} className="text-indigo-400/70 animate-in fade-in">
                       [{new Date(e.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}] <span className="text-white">{e.type}</span> -&gt; {e.status}
                    </p>
                  ))}
                  <p className="text-slate-500 animate-pulse">_</p>
              </div>
           </div>

           <div className="glass-card p-10 rounded-[3rem] border border-white/5 space-y-8">
              <h4 className="text-white font-black text-sm flex items-center gap-3"><ShieldAlert className="text-amber-500"/> تنبيهات أمنية</h4>
              <div className="space-y-4">
                 <div className="bg-amber-500/5 p-5 rounded-2xl border border-amber-500/20 flex items-start gap-4">
                    <AlertTriangle className="w-5 h-5 text-amber-500 mt-1 shrink-0"/>
                    <p className="text-[10px] text-slate-400 leading-relaxed font-bold">يجب عدم مشاركة مفاتيح الـ API أو الـ Secret الخاص بـ Webhook مع أي طرف غير موثوق. سيقوم النظام آلياً بحظر أي مفتاح يظهر في سجلات عامة.</p>
                 </div>
                 <div className="bg-blue-500/5 p-5 rounded-2xl border border-blue-500/20 flex items-start gap-4">
                    <ShieldCheck className="w-5 h-5 text-blue-400 mt-1 shrink-0"/>
                    <p className="text-[10px] text-slate-400 leading-relaxed font-bold">استخدم صلاحية <span className="text-blue-300">read_balance</span> فقط إذا لم تكن بحاجة لإجراء تحويلات، لتقليل المخاطر الأمنية.</p>
                 </div>
              </div>
           </div>

           <div className="glass-card p-10 rounded-[3rem] border border-white/5 space-y-6">
              <h4 className="text-white font-black text-sm flex items-center gap-3"><LinkIcon className="text-emerald-500"/> روابط مفيدة</h4>
              <div className="space-y-3">
                 {[
                   { label: 'توثيق الـ REST API', url: '#' },
                   { label: 'نماذج طلبات Postman', url: '#' },
                   { label: 'سجل التغييرات (Changelog)', url: '#' },
                   { label: 'الإبلاغ عن ثغرة أمنية', url: '#' }
                 ].map((link, i) => (
                   <button key={i} className="w-full p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 transition-all text-right group">
                      <div className="flex justify-between items-center">
                         <span className="text-[11px] font-black text-slate-400 group-hover:text-white transition-colors">{link.label}</span>
                         <Plus size={12} className="text-slate-600 group-hover:text-emerald-500"/>
                      </div>
                   </button>
                 ))}
              </div>
           </div>

        </div>
      </div>

      {/* NEW API KEY MODAL */}
      {isCreating && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in duration-300">
           <div className="glass-card w-full max-w-xl rounded-[4rem] p-12 border border-white/10 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl"></div>
              <button onClick={() => setIsCreating(false)} className="absolute top-10 left-10 p-3 bg-white/5 hover:bg-rose-500 text-slate-500 hover:text-white rounded-full transition-all active:scale-90"><X/></button>
              
              <div className="text-right mb-12">
                 <h3 className="text-3xl font-black text-white">إنشاء مفتاح وصول جديد</h3>
                 <p className="text-slate-500 text-xs mt-2 font-bold uppercase tracking-widest">Generate Secure Access Credentials</p>
              </div>

              <div className="space-y-10">
                 <div className="space-y-3">
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-4">اسم المفتاح (للتعريف الداخلي)</label>
                    <input 
                        type="text" 
                        value={newKeyName}
                        onChange={e => setNewKeyName(e.target.value)}
                        placeholder="مثلاً: تطبيق المتجر - الجوال"
                        className="w-full bg-[#030712] border border-white/10 rounded-[1.8rem] p-6 text-white font-bold text-lg outline-none focus:border-emerald-500 transition-all shadow-inner"
                    />
                 </div>

                 <div className="space-y-6">
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-4">تحديد الصلاحيات والمجالات (Scopes)</label>
                    <div className="grid grid-cols-1 gap-4 max-h-64 overflow-y-auto scrollbar-hide pr-2">
                       {AVAILABLE_PERMISSIONS.map(perm => (
                         <div 
                            key={perm.id} 
                            onClick={() => togglePermission(perm.id)}
                            className={`p-6 rounded-[2rem] border cursor-pointer transition-all flex items-center gap-5 group ${newKeyPermissions.includes(perm.id) ? 'bg-emerald-500/10 border-emerald-500/50' : 'bg-slate-900/40 border-white/5 hover:border-white/10'}`}
                         >
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${newKeyPermissions.includes(perm.id) ? 'bg-emerald-600 text-white shadow-lg' : 'bg-slate-800 text-slate-600 group-hover:text-slate-400'}`}>
                               {newKeyPermissions.includes(perm.id) ? <Check size={18}/> : <Plus size={18}/>}
                            </div>
                            <div className="text-right flex-1">
                               <div className="flex items-center gap-2">
                                  <p className={`text-sm font-black ${newKeyPermissions.includes(perm.id) ? 'text-white' : 'text-slate-400'}`}>{perm.label}</p>
                                  <span className="text-[8px] px-1.5 py-0.5 rounded bg-black/40 text-slate-600 font-black uppercase">{perm.category}</span>
                               </div>
                               <p className="text-[10px] text-slate-600 font-bold mt-1">{perm.desc}</p>
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>

                 <button 
                    onClick={handleCreateKey}
                    disabled={!newKeyName.trim() || newKeyPermissions.length === 0}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-6 rounded-[2rem] font-black text-xl transition-all shadow-2xl active:scale-95 disabled:opacity-50 disabled:grayscale glossy-shine"
                 >
                    توليد وتشفير المفتاح الآن
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* WEBHOOK CREATION MODAL */}
      {isCreatingWebhook && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in duration-300">
           <div className="glass-card w-full max-w-xl rounded-[4rem] p-12 border border-white/10 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl"></div>
              <button onClick={() => setIsCreatingWebhook(false)} className="absolute top-10 left-10 p-3 bg-white/5 hover:bg-rose-500 text-slate-500 hover:text-white rounded-full transition-all active:scale-90"><X/></button>
              
              <div className="text-right mb-12">
                 <h3 className="text-3xl font-black text-white">إعداد Webhook جديد</h3>
                 <p className="text-slate-500 text-xs mt-2 font-bold uppercase tracking-widest">Add Real-time Event Hook Notification</p>
              </div>

              <div className="space-y-10">
                 <div className="space-y-3">
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-4">رابط الاستلام (Destination URL)</label>
                    <input 
                        type="url" 
                        value={newWhUrl}
                        onChange={e => setNewWhUrl(e.target.value)}
                        placeholder="https://api.yourdomain.com/webhooks/horizon"
                        className="w-full bg-[#030712] border border-white/10 rounded-[1.8rem] p-6 text-indigo-400 font-mono text-sm outline-none focus:border-indigo-500 transition-all dir-ltr"
                    />
                 </div>

                 <div className="space-y-6">
                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-4">الأحداث المفعّلة (Subscribed Events)</label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       {AVAILABLE_WEBHOOK_EVENTS.map(ev => (
                         <div 
                            key={ev.id} 
                            onClick={() => toggleWhEvent(ev.id)}
                            className={`p-6 rounded-[2rem] border cursor-pointer transition-all flex items-center gap-4 group ${newWhEvents.includes(ev.id) ? 'bg-indigo-500/10 border-indigo-500/50' : 'bg-slate-900/40 border-white/5 hover:border-white/10'}`}
                         >
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${newWhEvents.includes(ev.id) ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-800 text-slate-600'}`}>
                               {newWhEvents.includes(ev.id) ? <Check size={18}/> : <Plus size={18}/>}
                            </div>
                            <div className="text-right">
                               <p className={`text-xs font-black ${newWhEvents.includes(ev.id) ? 'text-white' : 'text-slate-400'}`}>{ev.label}</p>
                               <p className="text-[9px] text-slate-600 font-bold mt-1">{ev.desc}</p>
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>

                 <button 
                    onClick={handleCreateWebhook}
                    disabled={!newWhUrl.trim() || newWhEvents.length === 0}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-6 rounded-[2rem] font-black text-xl transition-all shadow-2xl active:scale-95 disabled:opacity-50"
                 >
                    تفعيل الربط والمزامنة
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* API KEY SUCCESS MODAL */}
      {generatedKey && (
        <div className="fixed inset-0 z-[110] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-4 animate-in fade-in duration-300">
           <div className="glass-card w-full max-w-lg rounded-[4rem] p-12 border border-emerald-500/30 shadow-[0_0_100px_#10b98122] text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl"></div>
              
              <div className="w-28 h-28 bg-emerald-500/20 rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-emerald-500/20 group relative overflow-hidden">
                 <ShieldCheck className="w-14 h-14 text-emerald-500 z-10" />
                 <div className="absolute inset-0 bg-emerald-500/10 animate-pulse"></div>
              </div>

              <h3 className="text-3xl font-black text-white mb-4">تم التوليد بنجاح!</h3>
              <p className="text-slate-400 text-sm mb-12 font-bold leading-relaxed px-4">
                 يرجى نسخ هذا المفتاح وحفظه في مكان آمن. لأسباب أمنية لن تتمكن من رؤيته مرة أخرى أبداً بعد إغلاق هذه النافذة.
              </p>

              <div className="bg-[#010409] border-2 border-emerald-500/20 rounded-[2.5rem] p-8 flex flex-col items-center gap-8 mb-12 shadow-inner group">
                 <code className="text-emerald-400 font-mono text-base break-all text-center selection:bg-emerald-500/40 selection:text-white leading-relaxed">{generatedKey}</code>
                 <button onClick={() => handleCopy(generatedKey)} className="w-full py-5 bg-emerald-600/10 hover:bg-emerald-600 text-emerald-500 hover:text-white rounded-2xl transition-all active:scale-90 flex items-center justify-center gap-4 font-black text-xs uppercase tracking-widest border border-emerald-500/20 shadow-xl shadow-emerald-500/10">
                    {copied ? <><Check size={20} /> تم النسخ بنجاح</> : <><Copy size={20} /> نسخ المفتاح السري</>}
                 </button>
              </div>

              <button 
                onClick={() => setGeneratedKey(null)}
                className="w-full bg-slate-900 hover:bg-slate-800 text-slate-500 hover:text-white py-6 rounded-[2rem] font-black text-xs uppercase tracking-[0.3em] transition-all border border-white/5"
              >
                 تم الحفظ بأمان، أغلق النافذة
              </button>
           </div>
        </div>
      )}

      {/* PERMISSIONS EDIT MODAL */}
      {editingKeyPermissions && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in">
           <div className="glass-card w-full max-w-xl rounded-[4rem] p-12 border border-white/10 shadow-2xl relative overflow-hidden">
              <div className="text-right mb-12">
                 <h3 className="text-3xl font-black text-white">تعديل صلاحيات: {editingKeyPermissions.name}</h3>
                 <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mt-3">Refining Access Policy & Security Scopes</p>
              </div>

              <div className="space-y-10">
                 <div className="grid grid-cols-1 gap-4 max-h-96 overflow-y-auto scrollbar-hide pr-2">
                    {AVAILABLE_PERMISSIONS.map(perm => (
                       <div 
                          key={perm.id} 
                          onClick={() => {
                             const current = editingKeyPermissions.permissions;
                             const updated = current.includes(perm.id) ? current.filter(p => p !== perm.id) : [...current, perm.id];
                             setEditingKeyPermissions({...editingKeyPermissions, permissions: updated});
                          }}
                          className={`p-6 rounded-[2.2rem] border cursor-pointer transition-all flex items-center gap-5 group ${editingKeyPermissions.permissions.includes(perm.id) ? 'bg-indigo-500/10 border-indigo-500/50 shadow-xl shadow-indigo-900/10' : 'bg-slate-900/40 border-white/5 hover:border-white/10'}`}
                       >
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${editingKeyPermissions.permissions.includes(perm.id) ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-800 text-slate-600'}`}>
                             {editingKeyPermissions.permissions.includes(perm.id) ? <Check size={18}/> : <Plus size={18}/>}
                          </div>
                          <div className="text-right flex-1">
                             <div className="flex items-center gap-2">
                                <p className={`text-sm font-black ${editingKeyPermissions.permissions.includes(perm.id) ? 'text-white' : 'text-slate-500'}`}>{perm.label}</p>
                                <span className="text-[8px] px-1.5 py-0.5 rounded bg-black/40 text-slate-600 font-black uppercase">{perm.category}</span>
                             </div>
                             <p className="text-[10px] text-slate-600 font-bold mt-1">{perm.desc}</p>
                          </div>
                       </div>
                    ))}
                 </div>
                 
                 <div className="flex gap-4 pt-4">
                    <button onClick={() => setEditingKeyPermissions(null)} className="flex-1 bg-white/5 text-slate-500 py-6 rounded-[1.8rem] font-black text-xs uppercase tracking-widest border border-white/10 hover:bg-white/10 hover:text-white transition-all">إلغاء التغييرات</button>
                    <button onClick={handleUpdatePermissions} className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white py-6 rounded-[1.8rem] font-black text-xs uppercase tracking-widest shadow-2xl active:scale-95 transition-all">تحديث السياسة الأمنية</button>
                 </div>
              </div>
           </div>
        </div>
      )}

    </div>
  );
};

export default DeveloperTools;
