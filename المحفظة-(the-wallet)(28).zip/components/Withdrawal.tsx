
import React, { useState, useEffect } from 'react';
import { User, Currency, CurrencyConfig } from '../types';
import { 
  ArrowUpRight, Landmark, CreditCard, Wallet, Smartphone, 
  Coins, CheckCircle, Loader2, AlertCircle, Info, Send, 
  ArrowRight, ShieldCheck, DollarSign, XCircle
} from 'lucide-react';

interface WithdrawalProps {
  user: User;
  onWithdraw: (amount: number, currency: Currency, method: string, details: string) => Promise<boolean>;
  currencies: CurrencyConfig[];
}

const Withdrawal: React.FC<WithdrawalProps> = ({ user, onWithdraw, currencies }) => {
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<string>(currencies[0]?.code || 'USD');
  const [method, setMethod] = useState<string>('bank_transfer');
  const [details, setDetails] = useState('');
  const [status, setStatus] = useState<'IDLE' | 'PROCESSING' | 'SUCCESS'>('IDLE');
  const [error, setError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, boolean>>({});

  const currentWallet = user.wallets.find(w => w.currency === currency);
  const currentBalance = currentWallet?.balance || 0;

  const withdrawalMethods = [
    { id: 'bank_transfer', name: 'تحويل بنكي', icon: Landmark, desc: 'تحويل مباشر لحسابك البنكي' },
    { id: 'crypto_usdt', name: 'USDT (TRC20)', icon: Coins, desc: 'سحب عملات رقمية مستقرة' },
    { id: 'vodafone_cash', name: 'فودافون كاش', icon: Smartphone, desc: 'سحب فوري للمحافظ المصرية' },
    { id: 'stc_pay', name: 'STC Pay', icon: Smartphone, desc: 'سحب فوري للمحافظ السعودية' }
  ];

  // Clear errors when input changes
  useEffect(() => {
    setError(null);
    setValidationErrors({});
  }, [amount, currency, method, details]);

  const validate = () => {
    const errors: Record<string, boolean> = {};
    const amountNum = parseFloat(amount);

    if (!amount || isNaN(amountNum) || amountNum <= 0) {
      errors.amount = true;
      setError('يرجى إدخال مبلغ سحب صحيح أكبر من صفر');
    } else if (amountNum > currentBalance) {
      errors.amount = true;
      setError('عذراً، رصيدك الحالي غير كافٍ لإتمام هذه العملية');
    } else if (!details.trim()) {
      errors.details = true;
      setError('يرجى إدخال بيانات الاستلام بدقة لضمان وصول أموالك');
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;

    setStatus('PROCESSING');
    setError(null);
    
    const methodName = withdrawalMethods.find(m => m.id === method)?.name || method;
    try {
      const success = await onWithdraw(parseFloat(amount), currency, methodName, details);
      if (success) {
        setStatus('SUCCESS');
      } else {
        setStatus('IDLE');
        setError('حدث خطأ في النظام أثناء معالجة الطلب، يرجى المحاولة لاحقاً');
      }
    } catch (err) {
      setStatus('IDLE');
      setError('فشل الاتصال بالخادم، يرجى التحقق من اتصالك بالإنترنت');
    }
  };

  if (status === 'SUCCESS') {
    return (
      <div className="max-w-2xl mx-auto p-12 glass-card rounded-[3.5rem] text-center animate-in zoom-in duration-500 shadow-2xl border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
        <div className="w-24 h-24 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner border border-emerald-500/20">
          <CheckCircle className="w-12 h-12 text-emerald-500" />
        </div>
        <h2 className="text-3xl font-black text-white mb-4">تم استلام طلب السحب!</h2>
        <p className="text-slate-400 font-medium mb-10 leading-relaxed">
          طلبك بقيمة <span className="text-emerald-400 font-black">{amount} {currency}</span> قيد المراجعة حالياً. سيتم تحويل المبلغ خلال 24 ساعة عمل.
        </p>
        <button 
          onClick={() => {
            setStatus('IDLE');
            setAmount('');
            setDetails('');
          }}
          className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-5 rounded-2xl font-black transition-all shadow-2xl active:scale-95 glossy-shine"
        >
          طلب سحب جديد
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20">
      
      <div className="text-center space-y-3">
        <h2 className="text-4xl font-black text-white flex items-center justify-center gap-4 uppercase tracking-tighter">
          <ArrowUpRight className="w-10 h-10 text-rose-500 bg-rose-500/10 p-2 rounded-2xl" />
          مركز الخرج والمسحوبات
        </h2>
        <p className="text-slate-500 font-medium">اختر وسيلة السحب المفضلة لديك وقم بتحويل رصيدك إلى أموال حقيقية.</p>
      </div>

      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 p-5 rounded-2xl flex items-center gap-4 animate-in slide-in-from-top-2">
            <XCircle className="text-rose-500 shrink-0" />
            <p className="text-rose-500 text-sm font-black">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Step 1: Selection & Input */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass-card p-10 rounded-[3rem] border-white/5 shadow-2xl space-y-8 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-500 via-transparent to-transparent"></div>
            
            <div className="space-y-4">
              <label className={`text-[10px] font-black uppercase tracking-[0.3em] block px-2 ${validationErrors.amount ? 'text-rose-500' : 'text-slate-500'}`}>مبلغ السحب والعملة</label>
              <div className="flex gap-4">
                <div className="relative flex-1">
                  <input 
                    type="number" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className={`w-full bg-slate-900/50 border rounded-2xl p-6 text-4xl font-black text-white outline-none transition-all placeholder:text-slate-800 dir-ltr ${validationErrors.amount ? 'border-rose-500/50 focus:border-rose-500' : 'border-white/5 focus:border-rose-500/50'}`}
                  />
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none">
                    <span className="text-rose-500 text-xs font-black uppercase">Amount</span>
                  </div>
                </div>
                <select 
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="bg-slate-900 border border-white/5 text-white rounded-2xl px-6 font-black text-xl outline-none focus:border-rose-500/50 cursor-pointer shadow-xl appearance-none"
                >
                  {currencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                </select>
              </div>
              <div className="flex justify-between px-4 text-[10px] font-bold">
                 <span className="text-slate-500">الرصيد المتاح: <span className="text-emerald-400 font-mono">{currentBalance.toLocaleString()} {currency}</span></span>
                 {parseFloat(amount) > currentBalance && <span className="text-rose-500 animate-pulse">! الرصيد غير كافٍ</span>}
              </div>
            </div>

            <div className="space-y-4">
              <label className={`text-[10px] font-black uppercase tracking-[0.3em] block px-2 ${validationErrors.details ? 'text-rose-500' : 'text-slate-500'}`}>بيانات الاستلام</label>
              <div className="relative">
                <textarea 
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="رقم الحساب البنكي، عنوان المحفظة، أو رقم الجوال..."
                  className={`w-full bg-slate-900/50 border rounded-2xl p-6 text-white font-bold outline-none transition-all h-32 resize-none placeholder:text-slate-700 ${validationErrors.details ? 'border-rose-500/50 focus:border-rose-500' : 'border-white/5 focus:border-rose-500/50'}`}
                />
              </div>
            </div>

            <button 
              onClick={handleSubmit}
              disabled={status === 'PROCESSING'}
              className={`w-full py-6 rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-3 shadow-2xl active:scale-95 ${
                status === 'PROCESSING' 
                ? 'bg-slate-800 text-slate-600 cursor-not-allowed' 
                : 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/20 glossy-shine'
              }`}
            >
              {status === 'PROCESSING' ? <Loader2 className="w-8 h-8 animate-spin" /> : <><Send className="w-6 h-6" /> تأكيد طلب الخرج</>}
            </button>
          </div>

          <div className="bg-slate-950/50 p-6 rounded-[2rem] border border-white/5 flex items-start gap-4 shadow-xl">
             <div className="p-3 bg-amber-500/10 rounded-2xl border border-amber-500/20">
                <ShieldCheck className="w-6 h-6 text-amber-500" />
             </div>
             <div>
                <h4 className="text-white font-black text-sm">سياسة الأمان</h4>
                <p className="text-slate-500 text-xs mt-1 leading-relaxed">تخضع جميع عمليات الخرج لمراجعة يدوية دقيقة لضمان وصول الأموال لأصحابها. قد تستغرق العملية من 1 إلى 24 ساعة عمل.</p>
             </div>
          </div>
        </div>

        {/* Step 2: Withdrawal Methods */}
        <div className="space-y-6">
          <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] block px-4">وسيلة السحب</label>
          <div className="grid grid-cols-1 gap-4">
            {withdrawalMethods.map((m) => (
              <button
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`glass-card p-6 rounded-[2rem] text-right transition-all group relative overflow-hidden border ${
                  method === m.id ? 'border-rose-500/50 bg-rose-500/5 shadow-[0_0_30px_rgba(244,63,94,0.15)]' : 'border-white/5 hover:bg-white/5'
                }`}
              >
                {method === m.id && <div className="absolute top-0 right-0 w-12 h-12 bg-rose-500/10 rounded-full blur-xl"></div>}
                <div className="flex items-center gap-5">
                  <div className={`p-4 rounded-2xl ${method === m.id ? 'bg-rose-500 text-white shadow-[0_0_15px_rgba(244,63,94,0.5)]' : 'bg-slate-900 text-slate-500'}`}>
                    <m.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className={`font-black text-sm ${method === m.id ? 'text-white' : 'text-slate-300'}`}>{m.name}</h4>
                    <p className="text-[10px] font-bold text-slate-500 mt-0.5">{m.desc}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Withdrawal;
