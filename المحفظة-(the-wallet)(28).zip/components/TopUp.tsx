
import React, { useState, useMemo, useEffect } from 'react';
import { Currency, ManualGateway, CurrencyConfig } from '../types';
import { CreditCard, Upload, Check, Loader2, AlertCircle, Copy, Wallet, Zap, ShieldCheck, TrendingUp, X, Sparkles, Building2, User, Hash, Globe, FileText, Send } from 'lucide-react';

interface TopUpProps {
  onTopUp: (amount: number, currency: Currency, method: string, proof?: string, gatewayId?: string) => Promise<{ success: boolean; message: string; }>;
  manualGateways: ManualGateway[];
  currencies: CurrencyConfig[];
  manualTopUpFeePercentage: number;
}

const TopUp: React.FC<TopUpProps> = ({ onTopUp, manualGateways, currencies, manualTopUpFeePercentage }) => {
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<string>(currencies[0]?.code || 'USD');
  const [selectedGateway, setSelectedGateway] = useState<ManualGateway | 'CREDIT_CARD' | null>(null);
  const [proofFile, setProofFile] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const activeCurrencyConfig = useMemo(() => currencies.find(c => c.code === currency), [currency, currencies]);

  const availableGateways = useMemo(() => {
    return manualGateways
      .filter(g => g.isActive && (!g.supportedCurrencies || g.supportedCurrencies.includes(currency)))
      .sort((a, b) => a.order - b.order);
  }, [manualGateways, currency]);
  
  useEffect(() => { setPaymentError(null); }, [amount, currency, proofFile]);

  const expectedUSD = useMemo(() => {
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) return 0;
    let currentFee = (selectedGateway && selectedGateway !== 'CREDIT_CARD') ? val * (manualTopUpFeePercentage / 100) : 0;
    return (val - currentFee) * (activeCurrencyConfig?.rateToUSD || 1);
  }, [amount, activeCurrencyConfig, selectedGateway, manualTopUpFeePercentage]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setProofFile(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleCopy = (text: string, fieldName: string) => {
      navigator.clipboard.writeText(text);
      setCopiedField(fieldName);
      setTimeout(() => setCopiedField(null), 1500);
  };

  const handleSubmit = async () => {
    if (!selectedGateway || !amount || parseFloat(amount) <= 0) return;
    const amountNum = parseFloat(amount);
    if (amountNum < (activeCurrencyConfig?.minTransaction || 10)) {
        setPaymentError(`الحد الأدنى للإيداع هو ${activeCurrencyConfig?.minTransaction} ${currency}`);
        return;
    }
    if (selectedGateway !== 'CREDIT_CARD' && !proofFile) {
        setPaymentError('يرجى إرفاق إثبات الدفع');
        return;
    }

    setProcessing(true);
    const method = selectedGateway === 'CREDIT_CARD' ? `شحن بطاقة ائتمان` : `إيداع: ${selectedGateway.name}`;
    const result = await onTopUp(Number(amount), currency, method, proofFile || undefined, selectedGateway !== 'CREDIT_CARD' ? selectedGateway.id : undefined);
    setProcessing(false);
    if (result.success) setCompleted(true);
    else setPaymentError(result.message);
  };

  const renderGatewayImage = (img: string) => {
    const isBase64 = img.length > 50 && !img.includes(' ');
    const finalSrc = isBase64 && !img.startsWith('data:') ? `data:image/png;base64,${img}` : img;

    if (finalSrc.startsWith('http') || finalSrc.startsWith('data:image')) {
      return <img src={finalSrc} className="w-full h-full object-contain filter drop-shadow-[0_0_10px_rgba(16,185,129,0.3)]" alt="Gateway" />;
    }
    return <span className="text-4xl">{img}</span>;
  };

  if (completed) {
      return (
        <div className="max-w-2xl mx-auto p-12 glass-card rounded-[3.5rem] text-center animate-in zoom-in border-emerald-500/20 shadow-2xl mt-10">
          <div className="w-24 h-24 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-8 border border-emerald-500/20"><Check className="w-12 h-12 text-emerald-500" /></div>
          <h2 className="text-3xl font-black text-white mb-4">تم إرسال طلب الشحن!</h2>
          <p className="text-slate-400 font-medium mb-10 leading-relaxed">طلبك بقيمة <span className="text-emerald-400 font-black">{amount} {currency}</span> قيد المراجعة حالياً.</p>
          <button onClick={() => {setCompleted(false); setAmount(''); setSelectedGateway(null); setProofFile(null);}} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-5 rounded-2xl font-black transition-all shadow-lg active:scale-95">إضافة رصيد جديد</button>
        </div>
      );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20">
      <div className="text-center space-y-4 mb-10">
        <div className="inline-flex items-center justify-center p-4 bg-slate-900/50 rounded-3xl border border-white/5 shadow-xl mb-2"><div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-lg"><Wallet className="w-6 h-6 text-white" /></div></div>
        <h2 className="text-4xl font-black text-white tracking-tight">شحن المحفظة الرقمية</h2>
        <p className="text-slate-400 font-medium max-w-lg mx-auto">اختر القيمة ووسيلة الدفع المناسبة لك لشحن رصيدك بأمان وسهولة.</p>
      </div>

      <div className="glass-card rounded-[3.5rem] border-white/5 shadow-2xl overflow-hidden relative">
        <div className="p-8 md:p-14 space-y-14">
            <div className="space-y-8">
                <div className="flex items-center gap-4 mb-2"><div className="w-10 h-10 flex items-center justify-center bg-emerald-500 text-black rounded-full font-black text-sm">1</div><h3 className="text-2xl font-black text-white">حدد المبلغ المطلوب</h3></div>
                <div className="bg-[#020617]/60 p-4 rounded-[3rem] border border-white/5 shadow-inner flex flex-col md:flex-row gap-4">
                    <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" className="flex-1 h-28 bg-transparent text-white text-6xl font-black text-center md:text-left rounded-[2.5rem] px-10 outline-none placeholder:text-slate-800 dir-ltr font-mono" />
                    <select value={currency} onChange={(e) => {setCurrency(e.target.value); setSelectedGateway(null);}} className="w-full md:w-56 h-28 bg-slate-800 text-white font-black text-2xl text-center rounded-[2.5rem] outline-none border-2 border-transparent focus:border-emerald-500/50 cursor-pointer shadow-xl">
                        {currencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                    </select>
                </div>
                <div className="flex flex-col md:flex-row justify-between items-center gap-4 px-6">
                    <div className="flex items-center gap-3 text-amber-500 font-black text-[12px] uppercase bg-amber-500/5 px-5 py-2.5 rounded-full border border-amber-500/10"><AlertCircle size={16} />الحد الأدنى: {activeCurrencyConfig?.minTransaction} {currency}</div>
                    {parseFloat(amount) > 0 && <div className="flex items-center gap-3 text-emerald-400 font-black text-[12px] uppercase bg-emerald-500/5 px-5 py-2.5 rounded-full border border-emerald-500/10"><TrendingUp size={16} />صافي الرصيد المتوقع: ${expectedUSD.toFixed(2)} USD</div>}
                </div>
            </div>

            {parseFloat(amount) >= (activeCurrencyConfig?.minTransaction || 10) && (
                <div className="space-y-10 animate-in fade-in pt-14 border-t border-white/5">
                    <div className="flex items-center gap-4 mb-2">
                        <div className="w-10 h-10 flex items-center justify-center bg-emerald-500 text-black rounded-full font-black text-sm">2</div>
                        <h3 className="text-2xl font-black text-white">اختر وسيلة الدفع</h3>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                        {/* Credit Card (Coming Soon / Standard) */}
                        <button 
                            onClick={() => setSelectedGateway('CREDIT_CARD')} 
                            className={`group relative h-[220px] rounded-[2.8rem] border-2 transition-all duration-500 overflow-hidden flex flex-col items-center justify-center gap-5 hover:scale-[1.05] active:scale-[0.98] ${selectedGateway === 'CREDIT_CARD' ? 'border-emerald-500 bg-emerald-500/15 shadow-[0_0_50px_rgba(16,185,129,0.3)]' : 'border-white/5 bg-[#0f172a]/80 backdrop-blur-xl hover:border-emerald-500/30'}`}
                        >
                            <div className={`w-24 h-24 rounded-[2rem] flex items-center justify-center transition-all duration-500 relative ${selectedGateway === 'CREDIT_CARD' ? 'bg-emerald-500 shadow-[0_0_30px_rgba(16,185,129,0.5)]' : 'bg-slate-800 shadow-inner group-hover:bg-slate-700'}`}>
                                <CreditCard size={40} className={selectedGateway === 'CREDIT_CARD' ? 'text-white' : 'text-slate-400'} />
                                {selectedGateway === 'CREDIT_CARD' && <Sparkles className="absolute -top-2 -right-2 text-white w-6 h-6 animate-pulse" />}
                            </div>
                            <div className="text-center">
                                <span className={`font-black text-lg block ${selectedGateway === 'CREDIT_CARD' ? 'text-white' : 'text-slate-300'}`}>بطاقة ائتمانية</span>
                                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1 opacity-60">دفع فوري</span>
                            </div>
                        </button>

                        {/* Manual Gateways */}
                        {availableGateways.map(gw => (
                            <button 
                                key={gw.id} 
                                onClick={() => setSelectedGateway(gw)} 
                                className={`group relative h-[220px] rounded-[2.8rem] border-2 transition-all duration-500 overflow-hidden flex flex-col items-center justify-center gap-5 hover:scale-[1.05] active:scale-[0.98] ${typeof selectedGateway === 'object' && selectedGateway?.id === gw.id ? 'border-emerald-500 bg-emerald-500/20 shadow-[0_0_50px_rgba(16,185,129,0.4)]' : 'border-white/10 bg-[#0f172a]/80 backdrop-blur-2xl hover:border-emerald-500/30'}`}
                            >
                                <div className={`w-24 h-24 rounded-[2.5rem] p-4 flex items-center justify-center transition-all duration-500 relative overflow-hidden ${typeof selectedGateway === 'object' && selectedGateway?.id === gw.id ? 'bg-white/10 backdrop-blur-md shadow-[0_0_30px_rgba(16,185,129,0.5)] border border-emerald-400/30 scale-110' : 'bg-slate-900 shadow-inner group-hover:bg-slate-800 group-hover:scale-105'}`}>
                                    {renderGatewayImage(gw.image)}
                                    {typeof selectedGateway === 'object' && selectedGateway?.id === gw.id && (
                                      <div className="absolute inset-0 bg-emerald-500/10 pointer-events-none"></div>
                                    )}
                                </div>
                                <div className="text-center px-4 relative z-10">
                                    <span className={`font-black text-lg block truncate max-w-[150px] ${typeof selectedGateway === 'object' && selectedGateway?.id === gw.id ? 'text-emerald-400' : 'text-slate-300'}`}>{gw.name}</span>
                                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1 opacity-60">بوابة يدوية</span>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {selectedGateway && (
                <div className="space-y-10 animate-in fade-in pt-14 border-t border-white/5">
                    <div className="flex justify-between items-center"><div className="flex items-center gap-4"><div className="w-10 h-10 flex items-center justify-center bg-emerald-500 text-black rounded-full font-black text-sm">3</div><h3 className="text-2xl font-black text-white">إكمال عملية الدفع</h3></div><button onClick={() => setSelectedGateway(null)} className="p-3 bg-slate-800 rounded-full text-slate-400 hover:bg-rose-600 hover:text-white transition-all"><X size={20}/></button></div>
                    
                    {/* Specialized Bank Transfer View */}
                    {selectedGateway !== 'CREDIT_CARD' && selectedGateway.bankDetails ? (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                            {/* Structured Bank Info */}
                            <div className="bg-[#020617] rounded-[3rem] border border-white/10 overflow-hidden shadow-2xl relative">
                                <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
                                <div className="p-8 border-b border-white/5 flex items-center justify-between bg-slate-900/50">
                                    <h4 className="text-white font-black text-lg flex items-center gap-3">
                                        <Building2 className="text-emerald-500" />
                                        بيانات التحويل البنكي
                                    </h4>
                                    <span className="bg-emerald-500/10 text-emerald-500 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">Official Account</span>
                                </div>
                                <div className="p-8 space-y-4">
                                    {[
                                        { label: 'اسم البنك', value: selectedGateway.bankDetails.bankName, icon: Building2 },
                                        { label: 'اسم المستفيد', value: selectedGateway.bankDetails.accountHolder, icon: User },
                                        { label: 'رقم الحساب', value: selectedGateway.bankDetails.accountNumber, icon: Hash },
                                        { label: 'IBAN', value: selectedGateway.bankDetails.iban, icon: Globe },
                                        { label: 'Swift/BIC', value: selectedGateway.bankDetails.swiftCode, icon: Zap },
                                        { label: 'العملة', value: currency, icon: TrendingUp },
                                        { label: 'ملاحظة التحويل', value: `TopUp Ref`, icon: FileText }, 
                                    ].filter(f => f.value).map((field, idx) => (
                                        <div key={idx} className="flex items-center justify-between p-4 bg-slate-900/60 rounded-2xl border border-white/5 hover:border-emerald-500/30 transition-all group">
                                            <div className="flex items-center gap-4">
                                                <div className="p-2.5 bg-slate-800 rounded-xl text-slate-400 group-hover:text-emerald-400 group-hover:bg-emerald-500/10 transition-colors">
                                                    <field.icon size={18} />
                                                </div>
                                                <div>
                                                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{field.label}</p>
                                                    <p className={`font-mono font-bold text-sm ${field.label === 'IBAN' ? 'tracking-wider' : ''} ${field.label === 'ملاحظة التحويل' ? 'text-emerald-400' : 'text-white'}`}>{field.value}</p>
                                                </div>
                                            </div>
                                            <button 
                                                onClick={() => handleCopy(field.value || '', field.label)}
                                                className="p-2.5 text-slate-500 hover:text-white bg-white/5 hover:bg-emerald-600 rounded-xl transition-all active:scale-90 relative"
                                            >
                                                {copiedField === field.label ? <Check size={16} className="text-emerald-500 hover:text-white" /> : <Copy size={16} />}
                                            </button>
                                        </div>
                                    ))}
                                </div>
                                <div className="p-4 bg-amber-500/5 text-amber-500/80 text-[10px] font-bold text-center border-t border-white/5">
                                    <AlertCircle size={12} className="inline mr-2" />
                                    ⚠️ تأكد من إدخال البيانات بدقة لتجنب تأخير التحويل. أرفق الإيصال بالأسفل.
                                </div>
                            </div>

                            {/* Upload & Confirm */}
                            <div className="space-y-6">
                                <label className={`border-3 border-dashed rounded-[3.5rem] h-[280px] flex flex-col items-center justify-center cursor-pointer transition-all shadow-xl bg-black/20 ${proofFile ? 'border-emerald-500 bg-emerald-500/5' : 'border-slate-800 hover:bg-slate-900/40 hover:border-emerald-500/30'}`}>
                                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                                    {proofFile ? (
                                        <div className="text-center animate-in zoom-in duration-300">
                                            <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/30">
                                                <Check size={40} className="text-emerald-500" />
                                            </div>
                                            <span className="text-white font-black block">تم رفع الإيصال بنجاح</span>
                                            <span className="text-[10px] text-slate-500 uppercase mt-2 block">انقر للتغيير</span>
                                        </div>
                                    ) : (
                                        <div className="text-center group">
                                            <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform border border-white/5">
                                                <Upload className="w-8 h-8 text-slate-500 group-hover:text-emerald-400" />
                                            </div>
                                            <span className="text-slate-400 font-black">صورة الإيصال البنكي</span>
                                            <p className="text-[10px] text-slate-600 mt-2 font-bold uppercase tracking-widest px-8">JPEG, PNG Max 5MB</p>
                                        </div>
                                    )}
                                </label>

                                {paymentError && <div className="bg-rose-500/10 p-6 rounded-[2rem] border border-rose-500/20 text-rose-400 text-sm font-bold text-center animate-shake flex items-center justify-center gap-2"><AlertCircle size={16}/> {paymentError}</div>}
                                
                                <button 
                                    onClick={handleSubmit} 
                                    disabled={processing} 
                                    className="group w-full bg-emerald-600 hover:bg-emerald-500 text-white text-xl font-black py-8 rounded-[2.5rem] shadow-[0_20px_50px_rgba(16,185,129,0.3)] flex items-center justify-center gap-4 active:scale-[0.98] transition-all relative overflow-hidden"
                                >
                                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-shimmer"></div>
                                    {processing ? <Loader2 className="w-8 h-8 animate-spin" /> : <Send size={24} className="rtl:rotate-180" />}
                                    {processing ? 'جاري التحقق...' : 'تم التحويل - إرسال الطلب'}
                                </button>
                            </div>
                        </div>
                    ) : selectedGateway === 'CREDIT_CARD' ? (
                        <div className="p-16 glass-card rounded-[3.5rem] text-center bg-emerald-500/5 border border-emerald-500/20 shadow-2xl relative overflow-hidden">
                            <div className="absolute -top-10 -right-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-[80px]"></div>
                            <Zap className="w-16 h-16 mx-auto mb-6 text-emerald-500 animate-pulse" />
                            <h4 className="text-2xl font-black text-white mb-2">بوابة الدفع المباشر</h4>
                            <p className="text-slate-400 font-medium max-w-sm mx-auto">سيتم تفعيل الدفع ببطاقات Visa/MasterCard قريباً لجميع العملاء بشكل آلي.</p>
                        </div>
                    ) : (
                        // Standard Manual Gateway View
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                            <div className="bg-slate-900/60 p-10 rounded-[3rem] border border-white/5 space-y-6 text-right shadow-2xl backdrop-blur-md">
                                <h3 className="text-white font-black flex items-center gap-4 text-xl justify-end">تعليمات التحويل <ShieldCheck size={18} className="text-emerald-500" /></h3>
                                <div className="space-y-4">
                                    {selectedGateway?.instructions.split('\n').map((line, i) => (
                                        <div key={i} className="flex justify-between items-center p-5 bg-slate-950/80 rounded-2xl border border-white/5 hover:border-emerald-500/30 transition-all group">
                                            <span className="truncate flex-1 text-sm font-mono text-slate-200 tracking-wider text-right">{line}</span>
                                            <button onClick={() => {navigator.clipboard.writeText(line.split(': ')[1] || line); alert('تم النسخ!');}} className="text-slate-600 group-hover:text-emerald-400 p-2 transition-colors"><Copy className="w-5 h-5" /></button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div className="space-y-6">
                                <label className={`border-4 border-dashed rounded-[3.5rem] h-[280px] flex flex-col items-center justify-center cursor-pointer transition-all shadow-2xl ${proofFile ? 'border-emerald-500 bg-emerald-500/10' : 'border-slate-800 hover:bg-slate-900/40 hover:border-emerald-500/20'}`}>
                                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                                    {proofFile ? (
                                        <div className="text-center animate-in zoom-in duration-300">
                                            <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/30">
                                                <Check size={40} className="text-emerald-500" />
                                            </div>
                                            <span className="text-white font-black block">تم رفع الإيصال بنجاح</span>
                                            <span className="text-[10px] text-slate-500 uppercase mt-2 block">انقر للتغيير</span>
                                        </div>
                                    ) : (
                                        <div className="text-center group">
                                            <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                                                <Upload className="w-8 h-8 text-slate-500 group-hover:text-emerald-400" />
                                            </div>
                                            <span className="text-slate-400 font-black">ارفق صورة التحويل هنا</span>
                                            <p className="text-[10px] text-slate-600 mt-2 font-bold uppercase tracking-widest px-8">JPEG, PNG Max 5MB</p>
                                        </div>
                                    )}
                                </label>
                                
                                {paymentError && <div className="bg-rose-500/10 p-6 rounded-[2rem] border border-rose-500/20 text-rose-400 text-sm font-bold text-center animate-shake">{paymentError}</div>}
                                
                                <button 
                                    onClick={handleSubmit} 
                                    disabled={processing} 
                                    className="group w-full bg-emerald-600 hover:bg-emerald-500 text-white text-2xl font-black py-8 rounded-[2.5rem] shadow-[0_20px_50px_rgba(16,185,129,0.3)] flex items-center justify-center gap-4 active:scale-[0.98] transition-all relative overflow-hidden"
                                >
                                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-shimmer"></div>
                                    {processing ? <Loader2 className="w-8 h-8 animate-spin" /> : <Zap size={32} fill="currentColor" />}
                                    {processing ? 'جاري التحقق من البيانات...' : 'إرسال طلب الشحن للمراجعة'}
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default TopUp;
