
import React from 'react';
import { 
  Wallet, ShieldCheck, Globe, Zap, ArrowLeft, 
  CheckCircle, Users, BarChart3, Smartphone, ChevronDown, 
  Lock, CreditCard, PlayCircle, Star
} from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  return (
    <div className="min-h-screen bg-[#020617] text-white overflow-x-hidden font-sans selection:bg-emerald-500 selection:text-white" dir="rtl">
      
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none">
          <div className="absolute top-[-20%] right-[-10%] w-[800px] h-[800px] bg-emerald-500/5 rounded-full blur-[120px]"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-indigo-500/5 rounded-full blur-[120px]"></div>
          <div className="absolute top-[40%] left-[20%] w-[400px] h-[400px] bg-blue-500/5 rounded-full blur-[100px]"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-50 px-6 py-6 container mx-auto flex justify-between items-center">
        <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <Wallet className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-black tracking-tighter">Horizon Wallet</span>
        </div>
        <div className="hidden md:flex gap-8 text-sm font-bold text-slate-400">
            <a href="#features" className="hover:text-white transition-colors">المميزات</a>
            <a href="#security" className="hover:text-white transition-colors">الأمان</a>
            <a href="#games" className="hover:text-white transition-colors">الألعاب</a>
        </div>
        <button 
            onClick={onGetStarted}
            className="bg-white/5 hover:bg-white/10 text-white px-6 py-3 rounded-xl font-black text-xs transition-all border border-white/10"
        >
            تسجيل الدخول
        </button>
      </nav>

      {/* Hero Section */}
      <header className="relative z-10 container mx-auto px-6 pt-10 pb-20 md:pt-20 md:pb-32 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-widest mb-8 animate-in fade-in slide-in-from-bottom-4">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              الجيل الجديد من المحافظ الرقمية
          </div>
          
          <h1 className="text-5xl md:text-7xl font-black mb-8 leading-tight animate-in fade-in slide-in-from-bottom-6 duration-700">
              تحكم في أموالك <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">بذكاء وسرعة فائقة</span>
          </h1>
          
          <p className="text-slate-400 text-lg md:text-xl font-medium max-w-2xl mx-auto mb-12 leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-100">
              منصة واحدة تجمع بين التحويلات المالية، صرف العملات، الدفع الإلكتروني، والألعاب التنافسية. آمنة، سريعة، ومتاحة للجميع.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-in fade-in slide-in-from-bottom-10 duration-700 delay-200">
              <button 
                onClick={onGetStarted}
                className="group px-10 py-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-[2rem] font-black text-lg shadow-[0_20px_50px_rgba(16,185,129,0.3)] transition-all active:scale-95 flex items-center gap-3"
              >
                  ابدأ الآن مجاناً <ArrowLeft className="rtl:rotate-180 group-hover:-translate-x-1 transition-transform" />
              </button>
              <button className="px-10 py-5 bg-white/5 hover:bg-white/10 text-white rounded-[2rem] font-black text-lg transition-all flex items-center gap-3 border border-white/5">
                  <PlayCircle className="w-6 h-6" /> كيف يعمل؟
              </button>
          </div>

          {/* Stats Bar */}
          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto border-t border-white/5 pt-10">
              {[
                  { label: 'مستخدم نشط', value: '+50K' },
                  { label: 'حجم تداول يومي', value: '$2M+' },
                  { label: 'دولة مدعومة', value: '12+' },
                  { label: 'نسبة أمان', value: '99.9%' },
              ].map((stat, i) => (
                  <div key={i}>
                      <p className="text-3xl font-black text-white mb-1">{stat.value}</p>
                      <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">{stat.label}</p>
                  </div>
              ))}
          </div>
      </header>

      {/* Features Grid */}
      <section id="features" className="relative z-10 py-24 bg-[#0a0f1e]/50 border-y border-white/5">
          <div className="container mx-auto px-6">
              <div className="text-center mb-20">
                  <h2 className="text-3xl md:text-4xl font-black mb-4">كل ما تحتاجه في مكان واحد</h2>
                  <p className="text-slate-400 max-w-xl mx-auto">صممنا Horizon Wallet لتكون الرفيق المالي الأمثل، مع مجموعة أدوات متكاملة لإدارة أصولك.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                      { icon: Globe, title: 'تحويلات عالمية', desc: 'أرسل واستقبل الأموال من أي مكان في العالم برسوم تنافسية وسرعة لحظية.' },
                      { icon: ShieldCheck, title: 'حماية متقدمة', desc: 'نظام تشفير من الدرجة العسكرية ومصادقة ثنائية لضمان أمان حسابك 24/7.' },
                      { icon: Zap, title: 'دفع فوري', desc: 'ادفع فواتيرك، اشترِ بطاقات الألعاب، واشحن رصيدك بضغطة زر واحدة.' },
                      { icon: Users, title: 'مجتمع نشط', desc: 'تواصل مع مستخدمين آخرين، شارك في الغرف الصوتية، وتبادل الخبرات.' },
                      { icon: BarChart3, title: 'تحليل مالي AI', desc: 'مساعد ذكي يحلل مصاريفك ويقدم لك نصائح مخصصة لتحسين ميزانيتك.' },
                      { icon: CreditCard, title: 'بوابات متعددة', desc: 'دعم كامل للبطاقات الائتمانية، التحويلات البنكية، والعملات الرقمية.' },
                  ].map((feature, i) => (
                      <div key={i} className="glass-card p-8 rounded-[2.5rem] border border-white/5 hover:border-emerald-500/30 transition-all group">
                          <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-inner">
                              <feature.icon className="w-7 h-7 text-emerald-500" />
                          </div>
                          <h3 className="text-xl font-black text-white mb-3">{feature.title}</h3>
                          <p className="text-slate-400 text-sm leading-relaxed">{feature.desc}</p>
                      </div>
                  ))}
              </div>
          </div>
      </section>

      {/* App Preview Section */}
      <section className="py-24 container mx-auto px-6 relative overflow-hidden">
          <div className="bg-gradient-to-br from-emerald-900/40 to-slate-900/40 rounded-[4rem] p-10 md:p-20 border border-white/5 relative">
              <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none"></div>
              
              <div className="flex flex-col lg:flex-row items-center gap-16 relative z-10">
                  <div className="flex-1 space-y-8 text-center lg:text-right">
                      <h2 className="text-3xl md:text-5xl font-black leading-tight">
                          تجربة مستخدم <br/>
                          <span className="text-emerald-400">سلسة وبسيطة</span>
                      </h2>
                      <p className="text-slate-300 text-lg leading-relaxed">
                          واجهة التطبيق مصممة لتعمل بكفاءة على جميع الأجهزة. سواء كنت تستخدم الهاتف أو الكمبيوتر، ستجد كل أدواتك المالية في متناول يدك.
                      </p>
                      <ul className="space-y-4 inline-block text-right">
                          {['لوحة تحكم شاملة', 'إشعارات فورية', 'دعم فني مباشر', 'سجل عمليات مفصل'].map((item, i) => (
                              <li key={i} className="flex items-center gap-3 text-white font-bold">
                                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center"><CheckCircle size={14} className="text-emerald-500"/></div>
                                  {item}
                              </li>
                          ))}
                      </ul>
                  </div>
                  <div className="flex-1 relative">
                      {/* Abstract App Mockup */}
                      <div className="relative w-full max-w-md mx-auto aspect-[3/4] bg-[#020617] rounded-[3rem] border-8 border-slate-800 shadow-2xl overflow-hidden flex flex-col">
                          <div className="h-8 bg-slate-800 w-full absolute top-0 left-0 z-20 flex justify-center"><div className="w-24 h-4 bg-black rounded-b-2xl"></div></div>
                          <div className="flex-1 p-6 space-y-6 pt-12">
                              <div className="flex justify-between items-center">
                                  <div className="w-10 h-10 bg-slate-800 rounded-full"></div>
                                  <div className="w-10 h-10 bg-slate-800 rounded-full"></div>
                              </div>
                              <div className="bg-emerald-600/20 h-40 rounded-3xl border border-emerald-500/20 w-full animate-pulse"></div>
                              <div className="grid grid-cols-2 gap-4">
                                  <div className="h-24 bg-slate-800/50 rounded-2xl"></div>
                                  <div className="h-24 bg-slate-800/50 rounded-2xl"></div>
                              </div>
                              <div className="space-y-3">
                                  <div className="h-16 bg-slate-800/30 rounded-2xl w-full"></div>
                                  <div className="h-16 bg-slate-800/30 rounded-2xl w-full"></div>
                              </div>
                          </div>
                          {/* Floating Elements */}
                          <div className="absolute top-1/4 -right-12 bg-slate-900 p-4 rounded-2xl border border-white/10 shadow-xl animate-float">
                              <div className="flex items-center gap-3">
                                  <div className="p-2 bg-emerald-500 rounded-lg"><CheckCircle size={20} className="text-white"/></div>
                                  <div>
                                      <p className="text-[10px] text-slate-400 font-bold uppercase">إيداع ناجح</p>
                                      <p className="text-white font-black">+$500.00</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#010409] py-16 border-t border-white/5 relative z-10">
          <div className="container mx-auto px-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                  <div className="col-span-1 md:col-span-2">
                      <div className="flex items-center gap-3 mb-6">
                          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                              <Wallet className="w-5 h-5 text-white" />
                          </div>
                          <span className="text-xl font-black">Horizon Wallet</span>
                      </div>
                      <p className="text-slate-500 max-w-sm leading-relaxed text-sm">
                          منصتك الآمنة لإدارة الأموال الرقمية. مرخصة ومحمية بأحدث تقنيات الأمن السيبراني.
                      </p>
                  </div>
                  <div>
                      <h4 className="text-white font-bold mb-6">روابط سريعة</h4>
                      <ul className="space-y-3 text-sm text-slate-400">
                          <li><a href="#" className="hover:text-emerald-500 transition-colors">عن المنصة</a></li>
                          <li><a href="#" className="hover:text-emerald-500 transition-colors">الأسئلة الشائعة</a></li>
                          <li><a href="#" className="hover:text-emerald-500 transition-colors">شروط الخدمة</a></li>
                          <li><a href="#" className="hover:text-emerald-500 transition-colors">سياسة الخصوصية</a></li>
                      </ul>
                  </div>
                  <div>
                      <h4 className="text-white font-bold mb-6">تواصل معنا</h4>
                      <ul className="space-y-3 text-sm text-slate-400">
                          <li>support@horizon.com</li>
                          <li>+966 50 000 0000</li>
                          <li className="flex gap-4 mt-4">
                              {/* Social Icons Placeholder */}
                              <div className="w-8 h-8 bg-white/5 rounded-full hover:bg-emerald-500 transition-colors cursor-pointer"></div>
                              <div className="w-8 h-8 bg-white/5 rounded-full hover:bg-emerald-500 transition-colors cursor-pointer"></div>
                              <div className="w-8 h-8 bg-white/5 rounded-full hover:bg-emerald-500 transition-colors cursor-pointer"></div>
                          </li>
                      </ul>
                  </div>
              </div>
              <div className="border-t border-white/5 pt-8 text-center text-slate-600 text-xs font-bold uppercase tracking-widest">
                  &copy; 2025 Horizon Wallet. All rights reserved.
              </div>
          </div>
      </footer>
    </div>
  );
};

export default LandingPage;
