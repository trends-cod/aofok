
import React, { useState, useEffect } from 'react';
import { ThemeProvider } from './components/ThemeContext';
import { LanguageProvider } from './i18n';
import Layout from './components/Layout';
import Auth from './components/Auth';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import UserWallet from './components/UserWallet';
import Transfer from './components/Transfer';
import Exchange from './components/Exchange';
import TopUp from './components/TopUp';
import Withdrawal from './components/Withdrawal';
import AdminPanel from './components/AdminPanel';
import AiAdvisor from './components/AiAdvisor';
import UserProfile from './components/UserProfile';
import PageViewer from './components/PageViewer';
import GameCenter from './components/GameCenter';
import ChatSystem from './components/ChatSystem';
import LiveVoiceAdvisor from './components/LiveVoiceAdvisor';
import DeveloperTools from './components/DeveloperTools';
import { supabase, isDbConnected } from './lib/supabaseClient';
import { 
  User, View, Transaction, Currency, Category, Product, Banner, StoreSettings, 
  TransactionStatus, TransactionType, CurrencyConfig, ManualGateway, CustomPage, 
  GameConfig, TransferTypeConfig, UserRole, UserNotification, WebHook, GameDefinition
} from './types';
import { 
  MOCK_USERS, INITIAL_TRANSACTIONS, INITIAL_CURRENCIES, INITIAL_CATEGORIES, 
  INITIAL_PRODUCTS, INITIAL_BANNERS, INITIAL_SETTINGS, INITIAL_MANUAL_GATEWAYS, 
  INITIAL_PAGES, INITIAL_GAME_CONFIG, INITIAL_TRANSFER_TYPES, INITIAL_GAMES
} from './constants';
import { WifiOff, Database } from 'lucide-react';

const App: React.FC = () => {
  // --- Data Persistence Layer ---
  const [user, setUser] = useState<User | null>(null);
  
  // App view state: 'LANDING' | 'AUTH' | 'APP'
  const [viewState, setViewState] = useState<'LANDING' | 'AUTH' | 'APP'>('LANDING');

  // Initialize with local storage fallback, but will be overwritten by DB if connected
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('horizon_users');
    return saved ? JSON.parse(saved) : MOCK_USERS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('horizon_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  // Load Settings
  const [settings, setSettings] = useState<StoreSettings>(() => {
    const saved = localStorage.getItem('horizon_settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  // Other States
  const [activeView, setActiveView] = useState<View>(View.DASHBOARD);
  const [currencies, setCurrencies] = useState<CurrencyConfig[]>(INITIAL_CURRENCIES);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [banners, setBanners] = useState<Banner[]>(INITIAL_BANNERS);
  const [gateways, setGateways] = useState<ManualGateway[]>(INITIAL_MANUAL_GATEWAYS);
  const [pages, setPages] = useState<CustomPage[]>(INITIAL_PAGES);
  const [gameConfig, setGameConfig] = useState<GameConfig>(INITIAL_GAME_CONFIG);
  const [games, setGames] = useState<GameDefinition[]>(INITIAL_GAMES);
  const [transferTypes, setTransferTypes] = useState<TransferTypeConfig[]>(INITIAL_TRANSFER_TYPES);
  const [historyStack, setHistoryStack] = useState<View[]>([]);
  const [currentPageId, setCurrentPageId] = useState<string | null>(null);
  const [dbLoading, setDbLoading] = useState(isDbConnected);

  // --- DATABASE SYNCHRONIZATION ---

  // 1. Fetch Initial Data from DB
  useEffect(() => {
    const fetchData = async () => {
      if (!supabase) return;
      try {
        setDbLoading(true);
        // Fetch Users
        const { data: dbUsers } = await supabase.from('users').select('*');
        if (dbUsers && dbUsers.length > 0) {
          setUsers(dbUsers.map(row => row.data));
        }

        // Fetch Transactions
        const { data: dbTx } = await supabase.from('transactions').select('*').order('created_at', { ascending: false });
        if (dbTx && dbTx.length > 0) {
          setTransactions(dbTx.map(row => row.data));
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setDbLoading(false);
      }
    };

    fetchData();

    // 2. Real-time Subscription (For Admin to see new users instantly)
    if (supabase) {
      const channel = supabase.channel('global_changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'users' }, (payload) => {
           if (payload.new && (payload.new as any).data) {
             const newUser = (payload.new as any).data as User;
             setUsers(prev => {
                const exists = prev.find(u => u.id === newUser.id);
                return exists ? prev.map(u => u.id === newUser.id ? newUser : u) : [...prev, newUser];
             });
             // Update current user session if it's me
             if (user && user.id === newUser.id) setUser(newUser);
           }
        })
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'transactions' }, (payload) => {
           if (payload.new && (payload.new as any).data) {
             const newTx = (payload.new as any).data as Transaction;
             setTransactions(prev => [newTx, ...prev]);
           }
        })
        .subscribe();

      return () => { supabase.removeChannel(channel); };
    }
  }, []);

  // 3. Helper to Save Data (Hybrid: DB + Local)
  const saveUserGlobally = async (userData: User) => {
    // Optimistic Update
    setUsers(prev => {
      const exists = prev.find(u => u.id === userData.id);
      return exists ? prev.map(u => u.id === userData.id ? userData : u) : [...prev, userData];
    });
    if (user && user.id === userData.id) setUser(userData);

    // Persist
    localStorage.setItem('horizon_users', JSON.stringify(users)); // Backup
    if (supabase) {
      await supabase.from('users').upsert({ id: userData.id, data: userData });
    }
  };

  const saveTransactionGlobally = async (tx: Transaction) => {
    // Optimistic
    setTransactions(prev => [tx, ...prev]);
    
    // Persist
    localStorage.setItem('horizon_transactions', JSON.stringify(transactions)); // Backup
    if (supabase) {
      await supabase.from('transactions').insert({ id: tx.id, data: tx });
    }
  };

  // --- Effects for LocalStorage Backup ---
  useEffect(() => {
    if (!isDbConnected) {
      localStorage.setItem('horizon_users', JSON.stringify(users));
    }
  }, [users]);

  useEffect(() => {
    if (!isDbConnected) {
      localStorage.setItem('horizon_transactions', JSON.stringify(transactions));
    }
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('horizon_settings', JSON.stringify(settings));
  }, [settings]);

  // Sync current user state logic
  useEffect(() => {
    if (user) {
        const freshUserData = users.find(u => u.id === user.id);
        if (freshUserData && JSON.stringify(freshUserData) !== JSON.stringify(user)) {
            setUser(freshUserData);
            if (freshUserData.status === 'suspended') {
                alert('تم إيقاف حسابك من قبل الإدارة.');
                handleLogout();
            }
        }
    }
  }, [users]);

  // --- Leveling System Logic ---
  const XP_PER_LEVEL = 1000;
  const calculateLevel = (xp: number) => Math.floor(xp / XP_PER_LEVEL) + 1;

  const updateUserXp = (currentUser: User, xpAmount: number, reason: string): User => {
    const newXp = currentUser.xp + xpAmount;
    const oldLevel = currentUser.level;
    const newLevel = calculateLevel(newXp);
    let notifications = [...currentUser.notifications];

    if (newLevel > oldLevel) {
      const levelUpNotif: UserNotification = {
        id: `ntf_lvl_${Date.now()}`,
        title: '🎉 مبروك! مستوى جديد',
        message: `لقد وصلت إلى المستوى ${newLevel}! تم فتح مميزات جديدة في حسابك.`,
        date: new Date().toISOString(),
        isRead: false,
        type: 'success'
      };
      notifications = [levelUpNotif, ...notifications];
    }

    return {
      ...currentUser,
      xp: newXp,
      level: newLevel,
      notifications
    };
  };

  // Authentication Handlers
  const handleLogin = (email: string, pass: string) => {
    // Search in the persisted users array (which is now synced from DB)
    const found = users.find(u => (u.email === email || u.userCode === email) && u.password === pass);
    if (found) {
      if (found.status === 'suspended') {
        alert('عذراً، هذا الحساب موقوف حالياً. يرجى مراجعة الإدارة.');
        return;
      }
      setUser(found);
      setActiveView(View.DASHBOARD);
      setViewState('APP');
    } else {
      alert('بيانات الدخول غير صحيحة');
    }
  };

  const handleRegister = async (name: string, email: string, password: string) => {
    if (!settings.allowRegistrations) {
      alert('التسجيل مغلق حالياً');
      return;
    }
    const newUser: User = {
      id: `u_${Date.now()}`,
      userCode: `BNK-${Math.floor(Math.random() * 10000)}X`,
      name, email, password,
      role: 'user',
      status: 'active',
      wallets: [{ currency: 'USD', balance: 0 }],
      joinDate: new Date().toISOString(),
      notifications: [],
      apiKeys: [], webhooks: [], devEvents: [],
      level: 1, xp: 0
    };
    
    await saveUserGlobally(newUser);
    setUser(newUser);
    setActiveView(View.DASHBOARD);
    setViewState('APP');
  };

  const handleLogout = () => {
    setUser(null);
    setActiveView(View.DASHBOARD);
    setHistoryStack([]);
    setViewState('LANDING'); // Go back to landing on logout
  };

  // Navigation
  const handleNavigate = (view: View, params?: any) => {
    if (view === View.CUSTOM_PAGE && params?.pageId) {
      setCurrentPageId(params.pageId);
    }
    setHistoryStack(prev => [...prev, activeView]);
    setActiveView(view);
  };

  const handleBack = () => {
    if (historyStack.length > 0) {
      const prev = historyStack[historyStack.length - 1];
      setHistoryStack(prevStack => prevStack.slice(0, -1));
      setActiveView(prev);
    }
  };

  // Transactions Handlers
  const handleTopUp = async (amount: number, currency: Currency, method: string, proof?: string, gatewayId?: string) => {
    if (!user) return { success: false, message: 'User not found' };
    
    const fee = amount * (settings.manualTopUpFeePercentage / 100);
    const netAmount = amount - fee;

    const tx: Transaction = {
      id: `dep_${Date.now()}`,
      type: TransactionType.DEPOSIT,
      amount: netAmount,
      currency,
      date: new Date().toISOString(),
      description: `إيداع عبر: ${method}`,
      status: TransactionStatus.PENDING,
      proofImage: proof,
      gatewayId,
      userId: user.id,
      userName: user.name
    };
    
    await saveTransactionGlobally(tx);
    return { success: true, message: 'Request submitted' };
  };

  const handleWithdrawal = async (amount: number, currency: Currency, method: string, details: string) => {
    if (!user) return false;
    const wallet = user.wallets.find(w => w.currency === currency);
    if (!wallet || wallet.balance < amount) return false;

    // Deduct immediately
    const updatedWallets = user.wallets.map(w => 
      w.currency === currency ? { ...w, balance: w.balance - amount } : w
    );
    
    const updatedUser = { ...user, wallets: updatedWallets };
    await saveUserGlobally(updatedUser);

    const tx: Transaction = {
      id: `wth_${Date.now()}`,
      type: TransactionType.WITHDRAWAL,
      amount,
      currency,
      date: new Date().toISOString(),
      description: `سحب عبر: ${method} | ${details}`,
      status: TransactionStatus.PENDING,
      userId: user.id,
      userName: user.name
    };
    await saveTransactionGlobally(tx);
    return true;
  };

  const handleExchange = async (from: Currency, to: Currency, amountFrom: number, amountTo: number) => {
      if (!user) return false;
      const fromWallet = user.wallets.find(w => w.currency === from);
      if (!fromWallet || fromWallet.balance < amountFrom) return false;
      
      let updatedWallets = user.wallets.map(w => 
          w.currency === from ? { ...w, balance: w.balance - amountFrom } : w
      );

      const targetWalletIndex = updatedWallets.findIndex(w => w.currency === to);
      if (targetWalletIndex >= 0) {
          updatedWallets[targetWalletIndex] = {
              ...updatedWallets[targetWalletIndex],
              balance: updatedWallets[targetWalletIndex].balance + amountTo
          };
      } else {
          updatedWallets.push({ currency: to, balance: amountTo });
      }

      let updatedUser = { ...user, wallets: updatedWallets };
      updatedUser = updateUserXp(updatedUser, 50, 'exchange');

      await saveUserGlobally(updatedUser);

      const tx: Transaction = {
          id: `ex_${Date.now()}`,
          type: TransactionType.EXCHANGE,
          amount: amountFrom,
          currency: from,
          date: new Date().toISOString(),
          description: `صرف عملة: ${amountFrom} ${from} إلى ${amountTo} ${to}`,
          status: TransactionStatus.COMPLETED,
          userId: user.id,
          userName: user.name
      };
      await saveTransactionGlobally(tx);
      return true;
  };

  const handleTransfer = async (amount: number, currency: Currency, recipient: string, note: string) => {
    if (!user) return false;
    const wallet = user.wallets.find(w => w.currency === currency);
    const fee = amount * (settings.transferFeePercentage / 100);
    const total = amount + fee;

    if (!wallet || wallet.balance < total) return false;

    // Deduct from sender
    const senderWallets = user.wallets.map(w => 
      w.currency === currency ? { ...w, balance: w.balance - total } : w
    );
    
    let updatedSender = { ...user, wallets: senderWallets };
    updatedSender = updateUserXp(updatedSender, 20, 'transfer');
    await saveUserGlobally(updatedSender);

    // Handle Internal Transfer (Find Recipient in Global User List)
    let recipientFound = false;
    const recipientUser = users.find(u => u.userCode === recipient);
    
    if (recipientUser) {
        recipientFound = true;
        const recWallets = [...recipientUser.wallets];
        const recWalletIdx = recWallets.findIndex(w => w.currency === currency);
        if (recWalletIdx >= 0) {
          recWallets[recWalletIdx] = { ...recWallets[recWalletIdx], balance: recWallets[recWalletIdx].balance + amount };
        } else {
          recWallets.push({ currency, balance: amount });
        }
        
        const updatedRecipient = { ...recipientUser, wallets: recWallets };
        
        // Add Notification to Recipient
        const receivedNotif: UserNotification = {
            id: `ntf_recv_${Date.now()}`,
            title: 'تم استلام حوالة مالية',
            message: `وصلك ${amount} ${currency} من ${user.name}`,
            date: new Date().toISOString(),
            isRead: false,
            type: 'success'
        };
        updatedRecipient.notifications = [receivedNotif, ...updatedRecipient.notifications];
        
        await saveUserGlobally(updatedRecipient);
    }

    const tx: Transaction = {
      id: `tr_${Date.now()}`,
      type: TransactionType.TRANSFER,
      amount,
      currency,
      date: new Date().toISOString(),
      description: `تحويل إلى: ${recipient} | ${note} ${recipientFound ? '(تمت الإضافة للمستفيد)' : '(خارجي)'}`,
      status: TransactionStatus.COMPLETED,
      userId: user.id,
      userName: user.name
    };
    await saveTransactionGlobally(tx);
    return true;
  };

  const handlePurchase = async (product: Product, quantity: number, inputs: Record<string, string>) => {
    if (!user) return { success: false, message: 'Login required' };
    
    const units = product.quantityForPrice || 1;
    const unitPrice = (product.offerPrice || product.price) / units;
    const totalCost = unitPrice * quantity;

    const usdWallet = user.wallets.find(w => w.currency === 'USD');
    if (!usdWallet || usdWallet.balance < totalCost) {
      return { success: false, message: 'رصيد المحفظة (USD) غير كافٍ' };
    }

    const updatedWallets = user.wallets.map(w => 
      w.currency === 'USD' ? { ...w, balance: w.balance - totalCost } : w
    );
    
    const xpEarned = Math.max(50, Math.floor(totalCost * 10));
    let updatedUser = { ...user, wallets: updatedWallets };
    updatedUser = updateUserXp(updatedUser, xpEarned, 'purchase');

    await saveUserGlobally(updatedUser);

    const inputDetails = Object.entries(inputs).map(([k, v]) => `${k}: ${v}`).join(', ');
    const tx: Transaction = {
      id: `pur_${Date.now()}`,
      type: TransactionType.PURCHASE,
      amount: totalCost,
      currency: 'USD',
      date: new Date().toISOString(),
      description: `شراء: ${product.name} (x${quantity}) | ${inputDetails}`,
      status: product.deliveryType === 'AUTO' ? TransactionStatus.COMPLETED : TransactionStatus.PENDING,
      userId: user.id,
      userName: user.name
    };
    await saveTransactionGlobally(tx);
    return { success: true, message: 'تم الشراء بنجاح' };
  };

  const handleUpdateUser = async (data: Partial<User>) => {
    if (!user) return;
    const updated = { ...user, ...data };
    await saveUserGlobally(updated);
  };

  const handleAddTransaction = async (tx: Transaction) => {
    await saveTransactionGlobally(tx);
  };

  // --- Admin Logic Handlers ---

  const onUpdateTransactionStatus = async (id: string, status: TransactionStatus, note?: string, adminProof?: string) => {
    // Find transaction locally first
    const tx = transactions.find(t => t.id === id);
    if (!tx) return;

    const updatedTx = { ...tx, status, adminNote: note, adminProofImage: adminProof };
    
    // Update Transaction
    setTransactions(prev => prev.map(t => t.id === id ? updatedTx : t));
    if (supabase) {
        await supabase.from('transactions').update({ data: updatedTx }).eq('id', id);
    } else {
        localStorage.setItem('horizon_transactions', JSON.stringify(transactions.map(t => t.id === id ? updatedTx : t)));
    }

    // Logic: If Completed Deposit, Add Balance to Specific User
    if (status === TransactionStatus.COMPLETED && tx.type === TransactionType.DEPOSIT) {
        const targetUser = users.find(u => u.id === tx.userId);
        if (targetUser) {
            const wallets = targetUser.wallets.map(w => w.currency === tx.currency ? { ...w, balance: w.balance + tx.amount } : w);
            if (!wallets.find(w => w.currency === tx.currency)) wallets.push({ currency: tx.currency, balance: tx.amount });
            
            // Notification
            const depositNotif: UserNotification = {
                id: `ntf_dep_${Date.now()}`,
                title: 'إيداع ناجح',
                message: `تم قبول طلب الإيداع بقيمة ${tx.amount} ${tx.currency}`,
                date: new Date().toISOString(),
                isRead: false,
                type: 'success'
            };

            let updatedU = { ...targetUser, wallets, notifications: [depositNotif, ...targetUser.notifications] };
            updatedU = updateUserXp(updatedU, Math.min(1000, Math.floor(tx.amount)), 'deposit_approved');
            
            await saveUserGlobally(updatedU);
        }
    }
  };

  // Developer Tools Handlers
  const handleCreateApiKey = async (name: string, permissions: string[]) => {
    if (!user) return '';
    const newKeyStr = `sk_live_${Math.random().toString(36).substr(2, 9)}_${user.userCode}`;
    const newKeyObj = {
      id: `key_${Date.now()}`,
      name, key: newKeyStr, prefix: newKeyStr.substring(0, 8),
      createdAt: new Date().toISOString(), status: 'active' as const, permissions
    };
    const updatedUser = { ...user, apiKeys: [...user.apiKeys, newKeyObj] };
    await saveUserGlobally(updatedUser);
    return newKeyStr;
  };

  const handleRevokeApiKey = async (id: string) => {
    if (!user) return;
    const updatedKeys = user.apiKeys.map(k => k.id === id ? { ...k, status: 'revoked' as const } : k);
    const updatedUser = { ...user, apiKeys: updatedKeys };
    await saveUserGlobally(updatedUser);
  };

  const handleUpdateApiKeyPermissions = async (id: string, permissions: string[]) => {
    if (!user) return;
    const updatedKeys = user.apiKeys.map(k => k.id === id ? { ...k, permissions } : k);
    const updatedUser = { ...user, apiKeys: updatedKeys };
    await saveUserGlobally(updatedUser);
  };

  const handleAddWebhook = async (webhook: Omit<WebHook, 'id' | 'createdAt' | 'secret'>) => {
    if (!user) return;
    const newWh: WebHook = {
      ...webhook, id: `wh_${Date.now()}`, createdAt: new Date().toISOString(), secret: `whsec_${Math.random().toString(36).substr(2)}`,
    };
    const updatedUser = { ...user, webhooks: [...user.webhooks, newWh] };
    await saveUserGlobally(updatedUser);
  };

  const handleToggleWebhook = async (id: string) => {
    if (!user) return;
    const updatedWhs = user.webhooks.map(wh => wh.id === id ? { ...wh, isActive: !wh.isActive } : wh);
    const updatedUser = { ...user, webhooks: updatedWhs };
    await saveUserGlobally(updatedUser);
  };

  const handleDeleteWebhook = async (id: string) => {
    if (!user) return;
    const updatedWhs = user.webhooks.filter(wh => wh.id !== id);
    const updatedUser = { ...user, webhooks: updatedWhs };
    await saveUserGlobally(updatedUser);
  };

  // --- Render Logic ---

  const renderContent = () => {
    if (viewState === 'LANDING') {
      return <LandingPage onGetStarted={() => setViewState('AUTH')} />;
    }

    if (viewState === 'AUTH') {
      return <Auth onLogin={handleLogin} onRegister={handleRegister} onBack={() => setViewState('LANDING')} />;
    }

    // Default: APP View (User is logged in)
    if (!user) return null; // Should not happen due to flow logic, but safeguards type

    switch (activeView) {
      case View.DASHBOARD:
        return <Dashboard user={user} transactions={transactions} banners={banners} categories={categories} products={products} currencies={currencies} gateways={gateways} onNavigate={handleNavigate} onPurchase={handlePurchase} />;
      case View.WALLET:
        return <UserWallet user={user} transactions={transactions} currencies={currencies} onExchange={handleExchange} lowBalanceThreshold={settings.lowBalanceThreshold} onNavigate={handleNavigate} />;
      case View.TRANSFER:
        return <Transfer user={user} onTransfer={handleTransfer} transferFeePercentage={settings.transferFeePercentage} currencies={currencies} transactions={transactions} transferTypes={transferTypes} onNavigate={handleNavigate} allUsers={users} />;
      case View.EXCHANGE:
        return <Exchange user={user} currencies={currencies} onExchange={handleExchange} onNavigate={handleNavigate} />;
      case View.TOPUP:
        return <TopUp onTopUp={handleTopUp} manualGateways={gateways} currencies={currencies} manualTopUpFeePercentage={settings.manualTopUpFeePercentage} />;
      case View.WITHDRAWAL:
        return <Withdrawal user={user} onWithdraw={handleWithdrawal} currencies={currencies} />;
      case View.AI_ADVISOR:
        return <AiAdvisor user={user} transactions={transactions} />;
      case View.LIVE_VOICE:
        return <LiveVoiceAdvisor user={user} transactions={transactions} />;
      case View.PROFILE:
        return <UserProfile user={user} currencies={currencies} onUpdateUser={handleUpdateUser} />;
      case View.GAMES:
        return <GameCenter user={user} onUpdateUser={handleUpdateUser} gameConfig={gameConfig} onNavigate={handleNavigate} onAddTransaction={handleAddTransaction} games={games} />;
      case View.DEVELOPER:
        return <DeveloperTools user={user} onCreateApiKey={handleCreateApiKey} onRevokeApiKey={handleRevokeApiKey} onUpdateApiKeyPermissions={handleUpdateApiKeyPermissions} onAddWebhook={handleAddWebhook} onToggleWebhook={handleToggleWebhook} onDeleteWebhook={handleDeleteWebhook} />;
      case View.COMMUNITY:
        return <ChatSystem currentUser={user} allUsers={users} />;
      case View.CUSTOM_PAGE:
        const page = pages.find(p => p.id === currentPageId);
        return page ? <PageViewer page={page} /> : <div>Page not found</div>;
      case View.ADMIN:
        if (!['admin', 'super_admin', 'moderator'].includes(user.role)) return <div>Access Denied</div>;
        return (
          <AdminPanel 
            currentUser={user}
            gateways={gateways}
            transactions={transactions}
            users={users}
            products={products}
            categories={categories}
            banners={banners}
            settings={settings}
            currencies={currencies}
            pages={pages}
            gameConfig={gameConfig}
            games={games}
            transferTypes={transferTypes}
            auditLogs={[]}
            onUpdateTransferType={(t) => setTransferTypes(prev => prev.map(x => x.id === t.id ? t : x))}
            onAddTransferType={(t) => setTransferTypes(prev => [...prev, t])}
            onDeleteTransferType={(id) => setTransferTypes(prev => prev.filter(x => x.id !== id))}
            onUpdateGateway={(g) => setGateways(prev => prev.map(x => x.id === g.id ? g : x))}
            onAddGateway={(g) => setGateways(prev => [...prev, g])}
            onDeleteGateway={(id) => setGateways(prev => prev.filter(x => x.id !== id))}
            onUpdateTransactionStatus={onUpdateTransactionStatus}
            onUpdateUserRole={async (id, role) => {
               const target = users.find(u => u.id === id);
               if(target) await saveUserGlobally({...target, role});
            }}
            onUpdateUserStatus={async (id, status) => {
               const target = users.find(u => u.id === id);
               if(target) await saveUserGlobally({...target, status});
            }}
            onUpdateProduct={(p) => setProducts(prev => { const exists = prev.find(x => x.id === p.id); return exists ? prev.map(x => x.id === p.id ? p : x) : [...prev, p]; })}
            onDeleteProduct={(id) => setProducts(prev => prev.filter(x => x.id !== id))}
            onUpdateCategory={(c) => setCategories(prev => { const exists = prev.find(x => x.id === c.id); return exists ? prev.map(x => x.id === c.id ? c : x) : [...prev, c]; })}
            onDeleteCategory={(id) => setCategories(prev => prev.filter(x => x.id !== id))}
            onUpdateBanner={(b) => setBanners(prev => { const exists = prev.find(x => x.id === b.id); return exists ? prev.map(x => x.id === b.id ? b : x) : [...prev, b]; })}
            onDeleteBanner={(id) => setBanners(prev => prev.filter(x => x.id !== id))}
            onUpdateSettings={setSettings}
            onUpdateGameConfig={setGameConfig}
            onNavigate={handleNavigate}
            onAddAuditLog={() => {}}
            onAddCurrency={(c) => setCurrencies(prev => [...prev, c])}
            onUpdateCurrency={(c) => setCurrencies(prev => prev.map(x => x.code === c.code ? c : x))}
            onDeleteCurrency={(code) => setCurrencies(prev => prev.filter(x => x.code !== code))}
            onAddPage={(p) => setPages(prev => [...prev, p])}
            onUpdatePage={(p) => setPages(prev => prev.map(x => x.id === p.id ? p : x))}
            onDeletePage={(id) => setPages(prev => prev.filter(x => x.id !== id))}
            initialTab="DASHBOARD"
            onSyncExchangeRates={async () => ({ success: true, message: 'Synced' })}
            onAdminUpdateUser={saveUserGlobally}
            onAdminRegisterUser={saveUserGlobally}
            onBack={() => setActiveView(View.DASHBOARD)}
            // Dev props
            onCreateApiKey={handleCreateApiKey}
            onRevokeApiKey={handleRevokeApiKey}
            onUpdateApiKeyPermissions={handleUpdateApiKeyPermissions}
            onAddWebhook={handleAddWebhook}
            onToggleWebhook={handleToggleWebhook}
            onDeleteWebhook={handleDeleteWebhook}
            // Game props
            onAddGame={(g) => setGames(prev => [...prev, g])}
            onUpdateGame={(g) => setGames(prev => prev.map(x => x.id === g.id ? g : x))}
            onDeleteGame={(id) => setGames(prev => prev.filter(x => x.id !== id))}
          />
        );
      default:
        return <div>View Not Found</div>;
    }
  };

  return (
    <ThemeProvider>
      <LanguageProvider>
        {isDbConnected && (
            <div className="fixed bottom-4 left-4 z-[9999] bg-emerald-600 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase flex items-center gap-2 shadow-lg animate-in slide-in-from-bottom-2">
                <Database size={12} /> Connected to Cloud DB
            </div>
        )}
        {!isDbConnected && user && user.role === 'super_admin' && (
            <div className="fixed bottom-4 left-4 z-[9999] bg-slate-800 text-slate-400 px-3 py-1 rounded-full text-[10px] font-black uppercase flex items-center gap-2 border border-white/10">
                <WifiOff size={12} /> Local Mode
            </div>
        )}
        
        {viewState === 'APP' && user ? (
          <Layout 
            activeView={activeView} 
            onNavigate={handleNavigate} 
            onBack={handleBack} 
            canGoBack={historyStack.length > 0}
            user={user} 
            onLogout={handleLogout} 
            onMarkNotificationsRead={() => { /* Logic to mark read */ }}
            pages={pages}
            transactions={transactions}
            settings={settings}
          >
            {renderContent()}
          </Layout>
        ) : (
          renderContent()
        )}
      </LanguageProvider>
    </ThemeProvider>
  );
};

export default App;
