
import React, { useState, useMemo } from 'react';
import { User, Transaction, TransactionType, TransactionStatus, Currency, CurrencyConfig, View } from '../types';
import { 
  ClipboardList, X, Check, Wallet, RefreshCcw, 
  ArrowDown, ArrowUpRight, Clock, CheckCircle, XCircle,
  Download, Share2, Calendar, Send, Info, Activity, PieChart, ArrowRight, ArrowRightLeft, DollarSign,
  ShoppingCart, Plus, TrendingUp, BarChart3, Gamepad2, Star, ArrowDownLeft
} from 'lucide-react';
import { useLanguage } from '../i18n';
import { PieChart as RePieChart, Pie, Cell, Tooltip, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid } from 'recharts';

interface UserWalletProps {
  user: User;
  transactions: Transaction[];
  currencies: CurrencyConfig[];
  onExchange: (from: Currency, to: Currency, amountFrom: number, amountTo: number) => Promise<boolean>;
  lowBalanceThreshold: number;
  onNavigate: (view: View) => void;
}

const UserWallet: React.FC<UserWalletProps> = ({ 
  user, transactions, currencies, onExchange, 
  lowBalanceThreshold, onNavigate
}) => {
  const { t, language } = useLanguage();
  const [activeCurrency, setActiveCurrency] = useState<string>(currencies[0]?.code || 'USD');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const CHART_COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ec4899', '#6366f1', '#14b8a6'];
  const getNumberLocale = () => 'en-US';
  const getDateLocale = () => (language === 'ar' ? 'ar-EG' : 'en-US');

  const formatFinancial = (val: number, currencyCode: string) => {
    const config = currencies.find(c => c.code === currencyCode);
    const symbol = config?.symbol || currencyCode;
    const formatted = val.toLocaleString(getNumberLocale(), {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    return { formatted, symbol };
  };

  const walletTransactions = useMemo(() => {
    let filtered = transactions.filter(t => t.userId === user.id && t.currency === activeCurrency);
    if (dateFrom) {
        const fromDate = new Date(dateFrom);
        fromDate.setHours(0, 0, 0, 0);
        filtered = filtered.filter(t => new Date(t.date).getTime() >= fromDate.getTime());
    }
    if (dateTo) {
        const toDate = new Date(dateTo);
        toDate.setHours(23, 59, 59, 999);
        filtered = filtered.filter(t => new Date(t.date).getTime() <= toDate.getTime());
    }
    return filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transactions, user.id, activeCurrency, dateFrom, dateTo]);

  const assetDistribution = useMemo(() => {
      const totalWealthUSD = user.wallets.reduce((acc, w) => {
          const rate = currencies.find(c => c.code === w.currency)?.rateToUSD || 0;
          return acc + (w.balance * rate);
      }, 0);
      if (totalWealthUSD === 0) return [];
      return user.wallets
          .map(w => {
              const rate = currencies.find(c => c.code === w.currency)?.rateToUSD || 0;
              const usdValue = w.balance * rate;
              const percentage = (usdValue / totalWealthUSD) * 100;
              return { ...w, percentage, usdValue };
          })
          .sort((a, b) => b.usdValue - a.usdValue)
          .filter(w => w.percentage > 0);
  }, [user.wallets, currencies]);

  const totalWealth = useMemo(() => {
      return user.wallets.reduce((acc, w) => {
          const rate = currencies.find(c => c.code === w.currency)?.rateToUSD || 0;
          return acc + (w.balance * rate);
      }, 0);
  }, [user.wallets, currencies]);

  const wealthHistoryData = useMemo(() => {
    const data = [];
    const now = new Date();
    for (let i = 29; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(now.getDate() - i);
        const dayStr = date.toLocaleDateString(getDateLocale(), { day: 'numeric', month: 'short' });
        const entry: any = { name: dayStr };
        let dayTotal = 0;
        user.wallets.forEach(w => {
            const config = currencies.find(c => c.code === w.currency);
            const rate = config?.rateToUSD || 0;
            const seed = w.currency.charCodeAt(0) + i;
            const fluctuation = 1 + (Math.sin(seed * 0.5) * 0.1); 
            const historicalBalance = w.balance * fluctuation;
            const usdValue = historicalBalance * rate;
            entry[w.currency] = parseFloat(usdValue.toFixed(2));
            dayTotal += usdValue;
        });
        entry.total = parseFloat(dayTotal.toFixed(2));
        data.push(entry);
    }
    return data;
  }, [user.wallets, currencies, language]);

  return (
    <div className="max-w-7xl mx-auto space-y-10 animate-in fade-in duration-700 pb-20">
      
      <div className="flex flex-col md:flex-row justify-between items-end gap-6">
          <div>
              <h1 className="text-3xl font-black text-white flex items-center gap-3">
                  <Wallet className="w-8 h-8 text-emerald-500" />
                  محافظي الرقمية
              </h1>
              <p className="text-slate-500 font-bold mt-2">إدارة كاملة لكل أصولك النقدية والعملات</p>
          </div>
          <div className="bg-slate-900/50 px-8 py-4 rounded-[2rem] border border-white/5 flex items-center gap-4 shadow-xl">
              <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                  <DollarSign className="w-6 h-6 text-indigo-400" />
              </div>
              <div>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">صافي الثروة المقدر (USD)</p>
                  <p className="text-2xl font-mono font-black text-white dir-ltr">
                      $ {totalWealth.toLocaleString(getNumberLocale(), {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                  </p>
              </div>
          </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {user.wallets.map(wallet => {
              const config = currencies.find(c => c.code === wallet.currency);
              const usdEquiv = wallet.balance * (config?.rateToUSD || 0);
              const isActive = activeCurrency === wallet.currency;
              
              return (
                  <div 
                    key={wallet.currency} 
                    className={`
                        glass-card rounded-[2.5rem] p-8 border transition-all duration-300 flex flex-col justify-between h-[450px] shadow-2xl relative overflow-hidden group hover:scale-[1.03] cursor-pointer
                        ${isActive ? 'bg-[#050b18] border-emerald-500/40 ring-1 ring-emerald-500/20' : 'bg-[#030712] border-white/5 hover:border-white/10'}
                    `}
                    onClick={() => setActiveCurrency(wallet.currency)}
                  >
                      {/* Top Section: Icon & Info */}
                      <div className="flex justify-between items-start">
                          <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center text-white shadow-2xl transition-all duration-500 group-hover:scale-110 ${isActive ? 'bg-[#10b981] shadow-emerald-500/30' : 'bg-[#10b981]/80 text-white/90'}`}>
                              <span className="text-3xl font-black">{config?.symbol || '$'}</span>
                          </div>
                          <div className="text-left">
                              <h3 className="text-white text-2xl font-black tracking-tighter">{config?.name || 'Currency'}</h3>
                              <p className="text-slate-600 text-sm font-mono font-black uppercase tracking-widest mt-1 text-right">{wallet.currency}</p>
                          </div>
                      </div>

                      {/* Middle Section: Balance Display */}
                      <div className="flex flex-col items-center justify-center py-6 text-center">
                          <div className="text-6xl font-black text-white font-mono tracking-tighter mb-4 dir-ltr">
                              {wallet.balance.toLocaleString(getNumberLocale(), { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </div>
                          <div className="inline-flex items-center gap-2 bg-[#0a0f1e] px-6 py-2 rounded-full border border-white/5 dir-ltr">
                              <span className="text-emerald-500 font-black text-base">${usdEquiv.toLocaleString(getNumberLocale(), { minimumFractionDigits: 2 })}</span>
                              <span className="text-slate-500 font-bold text-xs">≈</span>
                          </div>
                      </div>

                      {/* Bottom Section: Action Buttons */}
                      <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                              <button 
                                onClick={(e) => { e.stopPropagation(); onNavigate(View.TOPUP); }}
                                className="bg-[#030712] hover:bg-slate-900 text-emerald-400 py-4 rounded-[1.2rem] border border-white/5 flex items-center justify-center gap-3 font-black text-xs transition-all active:scale-95"
                              >
                                  إيداع <ArrowDownLeft size={18} className="text-emerald-500" />
                              </button>
                              <button 
                                onClick={(e) => { e.stopPropagation(); onNavigate(View.EXCHANGE); }}
                                className="bg-[#030712] hover:bg-slate-900 text-slate-300 py-4 rounded-[1.2rem] border border-white/5 flex items-center justify-center gap-3 font-black text-xs transition-all active:scale-95"
                              >
                                  صرف <RefreshCcw size={18} className="text-blue-500" />
                              </button>
                          </div>
                          <button 
                            onClick={(e) => { e.stopPropagation(); onNavigate(View.TRANSFER); }}
                            className="w-full bg-[#030712] hover:bg-slate-900 text-slate-300 py-4 rounded-[1.2rem] border border-white/5 flex items-center justify-center gap-3 font-black text-xs transition-all active:scale-95 group/btn"
                          >
                              <Send size={18} className="text-indigo-400 rotate-[-45deg] group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" /> تحويل
                          </button>
                      </div>
                  </div>
              );
          })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 glass-card rounded-[3.5rem] p-10 border border-white/5">
              <div className="flex justify-between items-center mb-10">
                  <div>
                    <h3 className="text-white font-black text-xl flex items-center gap-3">
                        <TrendingUp size={24} className="text-emerald-500" /> تحليل نمو الأصول
                    </h3>
                    <p className="text-slate-500 text-xs font-bold mt-1">تتبع التغير المقدر في ثروتك الرقمية خلال 30 يوماً</p>
                  </div>
              </div>
              <div className="h-[400px] w-full dir-ltr">
                  <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={wealthHistoryData}>
                          <defs>
                              <linearGradient id="colorWealth" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                              </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" vertical={false} />
                          <XAxis dataKey="name" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                          <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', borderRadius: '1.5rem', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 20px 40px rgba(0,0,0,0.4)' }}
                            itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                          />
                          <Area type="monotone" dataKey="total" stroke="#10b981" strokeWidth={4} fillOpacity={1} fill="url(#colorWealth)" />
                      </AreaChart>
                  </ResponsiveContainer>
              </div>
          </div>

          <div className="glass-card rounded-[3.5rem] p-10 border border-white/5 flex flex-col">
              <h3 className="text-white font-black text-xl mb-10 flex items-center gap-3">
                  <PieChart size={24} className="text-indigo-400" /> توزيع المحفظة
              </h3>
              <div className="flex-1 min-h-[300px] dir-ltr">
                  <ResponsiveContainer width="100%" height="100%">
                      <RePieChart>
                          <Pie
                              data={assetDistribution}
                              cx="50%" cy="50%"
                              innerRadius={80}
                              outerRadius={120}
                              paddingAngle={8}
                              dataKey="usdValue"
                              stroke="none"
                          >
                              {assetDistribution.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                              ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', borderRadius: '1rem', border: 'none' }}
                            itemStyle={{ color: '#fff', fontSize: '10px' }}
                          />
                      </RePieChart>
                  </ResponsiveContainer>
              </div>
              <div className="mt-8 space-y-4">
                  {assetDistribution.slice(0, 4).map((asset, idx) => (
                      <div key={asset.currency} className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
                          <div className="flex items-center gap-3">
                              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: CHART_COLORS[idx % CHART_COLORS.length] }}></div>
                              <span className="text-slate-300 font-bold text-xs">{asset.currency}</span>
                          </div>
                          <span className="text-white font-black font-mono text-xs">{asset.percentage.toFixed(1)}%</span>
                      </div>
                  ))}
              </div>
          </div>
      </div>

      <div className="glass-card rounded-[3rem] p-10 border border-white/5 overflow-hidden">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-10">
              <h3 className="text-white text-xl font-black flex items-center gap-3">
                  <Activity size={24} className="text-blue-500" /> العمليات الأخيرة للعملة: {activeCurrency}
              </h3>
              <div className="flex gap-4">
                  <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="bg-slate-900/50 border border-white/10 rounded-xl px-4 py-2 text-xs font-bold text-white outline-none focus:border-emerald-500" />
                  <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="bg-slate-900/50 border border-white/10 rounded-xl px-4 py-2 text-xs font-bold text-white outline-none focus:border-emerald-500" />
              </div>
          </div>
          
          <div className="space-y-4">
              {walletTransactions.length > 0 ? (
                  walletTransactions.map(tx => (
                      <div key={tx.id} className="bg-[#030712]/60 p-6 rounded-[2rem] border border-white/5 flex justify-between items-center hover:bg-[#050b18] transition-all group hover:border-emerald-500/20">
                          <div className="flex items-center gap-5">
                              <div className={`w-14 h-14 rounded-2xl border border-white/5 flex items-center justify-center transition-all group-hover:scale-110 ${tx.type === TransactionType.DEPOSIT ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
                                  {tx.type === TransactionType.DEPOSIT ? <ArrowDownLeft /> : <ArrowUpRight />}
                              </div>
                              <div className="text-right">
                                  <p className="text-white font-black text-sm">{tx.description.split('|')[0]}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                      <span className="text-[10px] text-slate-500 font-bold">{new Date(tx.date).toLocaleString(getDateLocale())}</span>
                                      <span className="w-1 h-1 rounded-full bg-slate-800"></span>
                                      <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase ${tx.status === TransactionStatus.COMPLETED ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'}`}>
                                          {tx.status}
                                      </span>
                                  </div>
                              </div>
                          </div>
                          <div className="text-left">
                              <p className={`text-xl font-mono font-black ${tx.type === TransactionType.DEPOSIT ? 'text-emerald-400' : 'text-rose-400'}`}>
                                  {tx.type === TransactionType.DEPOSIT ? '+' : '-'}{tx.amount.toLocaleString()} <span className="text-[10px] text-slate-600">{tx.currency}</span>
                              </p>
                              <p className="text-[9px] text-slate-600 font-mono tracking-tighter mt-1">ID: {tx.id.slice(-8).toUpperCase()}</p>
                          </div>
                      </div>
                  ))
              ) : (
                  <div className="py-24 text-center opacity-30 italic flex flex-col items-center gap-4">
                      <ClipboardList size={64} className="text-slate-500" />
                      <p className="font-black text-sm uppercase tracking-[0.3em]">{t('no_activity')}</p>
                  </div>
              )}
          </div>
      </div>
    </div>
  );
};

export default UserWallet;
