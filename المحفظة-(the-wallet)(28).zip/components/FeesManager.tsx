
import React, { useState } from 'react';
import { StoreSettings, CurrencyConfig } from '../types';
import { 
  Percent, Save, ShieldCheck, Globe, DollarSign, 
  ArrowRightLeft, CreditCard, ArrowUpRight, CheckCircle, Info,
  AlertCircle
} from 'lucide-react';

interface FeesManagerProps {
  settings: StoreSettings;
  onUpdateSettings: (settings: StoreSettings) => void;
  currencies: CurrencyConfig[];
  onUpdateCurrency: (currency: CurrencyConfig) => void;
}

const FeesManager: React.FC<FeesManagerProps> = ({ 
  settings, onUpdateSettings, currencies, onUpdateCurrency 
}) => {
  const [globalSettings, setGlobalSettings] = useState<StoreSettings>({ ...settings });
  const [editingCurrencies, setEditingCurrencies] = useState<CurrencyConfig[]>(JSON.parse(JSON.stringify(currencies)));
  const [isDirty, setIsDirty] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleGlobalChange = (field: keyof StoreSettings, value: number) => {
    setGlobalSettings(prev => ({ ...prev, [field]: value }));
    setIsDirty(true);
  };

  const handleCurrencyChange = (code: string, field: keyof CurrencyConfig, value: number) => {
    setEditingCurrencies(prev => prev.map(c => 
      c.code === code ? { ...c, [field]: value } : c
    ));
    setIsDirty(true);
  };

  const handleSaveAll = () => {
    // Save global settings
    onUpdateSettings(globalSettings);
    
    // Save all changed currencies
    editingCurrencies.forEach(c => {
        const original = currencies.find(oc => oc.code === c.code);
        if (JSON.stringify(original) !== JSON.stringify(c)) {
            onUpdateCurrency(c);
        }
    });

    setIsDirty(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      
      {/* Save Action Header */}
      <div className="glass-card p-8 rounded-[2.5rem] border border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 sticky top-0 z-20 bg-slate-900/60 backdrop-blur-3xl shadow-2xl">
          <div className="flex items-center gap-5">
              <div className="p-4 bg-emerald-600 rounded-2xl shadow-lg shadow-emerald-900/40">
                  <Percent className="w-6 h-6 text-white" />
              </div>
              <div className="text-right">
                  <h2 className="text-2xl font-black text-white">إدارة سياسات الرسوم</h2>
                  <p className="text-slate-500 font-bold text-xs uppercase tracking-widest mt-1">Transaction Fees & Commission Engine</p>
              </div>
          </div>

          <div className="flex items-center gap-4">
              {showSuccess && (
                  <span className="text-emerald-500 text-xs font-black animate-pulse flex items-center gap-2">
                      <ShieldCheck size={16} /> تم تحديث السياسات بنجاح
                  </span>
              )}
              <button 
                  onClick={handleSaveAll}
                  disabled={!isDirty}
                  className={`px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl active:scale-95 flex items-center gap-2 ${
                    isDirty ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/20' : 'bg-slate-800 text-slate-600 grayscale border border-white/5'
                  }`}
              >
                  <Save size={18} /> حفظ جميع التغييرات
              </button>
          </div>
      </div>

      {/* Global Fees Section */}
      <div className="glass-card p-10 rounded-[3rem] border border-white/5 relative overflow-hidden bg-[#0a0f1e]/50">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-[80px]"></div>
          
          <div className="flex items-center gap-4 mb-10 border-b border-white/5 pb-6">
              <Globe className="w-6 h-6 text-emerald-500" />
              <div>
                  <h3 className="text-xl font-black text-white">الرسوم العامة للنظام</h3>
                  <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">Global Default Commission Percentages</p>
              </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                  { id: 'transferFeePercentage', label: 'رسوم التحويل الداخلي', icon: ArrowRightLeft, color: 'indigo' },
                  { id: 'manualTopUpFeePercentage', label: 'رسوم الإيداع اليدوي', icon: CreditCard, color: 'emerald' },
                  { id: 'withdrawalFeePercentage', label: 'رسوم السحب العام', icon: ArrowUpRight, color: 'rose' }
              ].map(fee => (
                  <div key={fee.id} className="bg-black/30 p-6 rounded-[2rem] border border-white/5 space-y-4">
                      <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg bg-${fee.color}-500/10 text-${fee.color}-400`}><fee.icon size={16} /></div>
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{fee.label}</label>
                      </div>
                      <div className="relative">
                          <input 
                              type="number" 
                              value={(globalSettings as any)[fee.id] || 0}
                              onChange={e => handleGlobalChange(fee.id as any, parseFloat(e.target.value) || 0)}
                              className="w-full bg-[#030712] border border-white/10 rounded-xl p-4 text-white font-mono font-black text-2xl outline-none focus:border-emerald-500 transition-all text-center"
                          />
                          <span className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-600 font-black">%</span>
                      </div>
                  </div>
              ))}
          </div>
          
          <div className="mt-8 bg-blue-500/5 p-4 rounded-2xl border border-blue-500/10 flex items-start gap-4">
              <Info className="w-5 h-5 text-blue-400 shrink-0 mt-1" />
              <p className="text-[10px] text-slate-500 leading-relaxed font-bold">
                  هذه الرسوم هي القيم الافتراضية التي تُطبق على العمليات العامة. يمكنك تخصيص رسوم مختلفة لكل عملة على حدة في الجدول أدناه. في حال عدم تحديد رسوم لعملة معينة، سيتم الرجوع لهذه القيم.
              </p>
          </div>
      </div>

      {/* Per-Currency Fees Section */}
      <div className="glass-card rounded-[3rem] border border-white/5 overflow-hidden shadow-2xl">
          <div className="p-8 border-b border-white/5 bg-slate-900/50 flex items-center gap-4">
              <DollarSign className="w-6 h-6 text-amber-500" />
              <div>
                <h3 className="text-xl font-black text-white">تخصيص الرسوم حسب العملة</h3>
                <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">Specific Fee Override Per Asset</p>
              </div>
          </div>

          <div className="overflow-x-auto scrollbar-hide">
              <table className="w-full text-right text-sm">
                  <thead className="bg-[#030712] text-slate-600 text-[9px] font-black uppercase tracking-widest">
                      <tr>
                          <th className="p-6">العملة</th>
                          <th className="p-6 text-center">رسوم الإيداع (%)</th>
                          <th className="p-6 text-center">رسوم السحب (%)</th>
                          <th className="p-6 text-center">رسوم التحويل (%)</th>
                          <th className="p-6 text-center">هامش البيع (%)</th>
                          <th className="p-6 text-center">هامش الشراء (%)</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                      {editingCurrencies.map(c => (
                          <tr key={c.code} className="hover:bg-white/[0.02] transition-colors group">
                              <td className="p-6">
                                  <div className="flex items-center gap-4">
                                      <div className="w-10 h-10 rounded-xl bg-[#030712] border border-white/10 flex items-center justify-center font-black text-emerald-400 shadow-inner group-hover:scale-105 transition-transform">{c.symbol}</div>
                                      <div>
                                          <p className="font-black text-white text-xs">{c.name}</p>
                                          <p className="text-[10px] text-slate-500 font-mono font-bold uppercase">{c.code}</p>
                                      </div>
                                  </div>
                              </td>
                              {[
                                  { id: 'depositFee', color: 'emerald' },
                                  { id: 'withdrawalFee', color: 'rose' },
                                  { id: 'transferFee', color: 'indigo' },
                                  { id: 'sellMargin', color: 'slate' },
                                  { id: 'buyMargin', color: 'slate' }
                              ].map(field => (
                                  <td key={field.id} className="p-4 text-center">
                                      <div className="relative inline-block w-24">
                                          <input 
                                              type="number" 
                                              value={(c as any)[field.id]}
                                              onChange={e => handleCurrencyChange(c.code, field.id as any, parseFloat(e.target.value) || 0)}
                                              className="w-full bg-black/40 border border-white/5 rounded-xl p-2.5 text-center text-xs font-mono font-bold text-white focus:border-emerald-500 outline-none transition-all"
                                          />
                                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[9px] text-slate-700 font-black">%</span>
                                      </div>
                                  </td>
                              ))}
                          </tr>
                      ))}
                  </tbody>
              </table>
          </div>
          
          <div className="p-6 bg-slate-900/30 border-t border-white/5">
              <div className="flex items-center gap-3 text-amber-500/80">
                  <AlertCircle size={16} />
                  <p className="text-[10px] font-bold">تأكد من الضغط على "حفظ جميع التغييرات" في الأعلى لاعتماد التعديلات الجديدة.</p>
              </div>
          </div>
      </div>
    </div>
  );
};

export default FeesManager;
