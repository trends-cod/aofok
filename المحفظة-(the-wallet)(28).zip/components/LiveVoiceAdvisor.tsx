
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { User, Transaction } from '../types';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
// Added User as UserIcon to resolve the missing import error
import { Mic, MicOff, Volume2, VolumeX, Loader2, Sparkles, MessageSquare, Info, AlertCircle, Headphones, User as UserIcon } from 'lucide-react';

interface LiveVoiceAdvisorProps {
  user: User;
  transactions: Transaction[];
}

// Audio Encoding & Decoding Helpers
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const LiveVoiceAdvisor: React.FC<LiveVoiceAdvisorProps> = ({ user, transactions }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [userTranscription, setUserTranscription] = useState('');
  const [modelTranscription, setModelTranscription] = useState('');
  const [status, setStatus] = useState<'idle' | 'listening' | 'speaking'>('idle');

  const sessionRef = useRef<any>(null);
  const audioContextsRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const startSession = async () => {
    setIsConnecting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextsRef.current = { input: inputCtx, output: outputCtx };

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            setStatus('listening');

            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Transcriptions
            if (message.serverContent?.outputTranscription) {
              setModelTranscription(prev => prev + message.serverContent!.outputTranscription!.text);
              setStatus('speaking');
            } else if (message.serverContent?.inputTranscription) {
              setUserTranscription(prev => prev + message.serverContent!.inputTranscription!.text);
              setStatus('listening');
            }

            if (message.serverContent?.turnComplete) {
              setModelTranscription('');
              setUserTranscription('');
            }

            // Handle Audio Data
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outputCtx) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputCtx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error('Gemini Live Error:', e);
            stopSession();
          },
          onclose: () => {
            stopSession();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } },
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: `أنت مساعد مالي ذكي يدعى "أفق". تتحدث العربية بطلاقة وأسلوب ودي ومهني. 
          مهمتك هي مساعدة المستخدم في شؤونه المالية داخل تطبيق محفظة أفق. 
          بيانات المستخدم الحالي: ${user.name}.
          تاريخ التحويلات الأخير: ${JSON.stringify(transactions.slice(0, 3))}.
          كن مقتضباً وواضحاً في ردودك الصوتية.`,
        },
      });

      sessionRef.current = sessionPromise;
    } catch (err) {
      console.error('Failed to start Live session:', err);
      setIsConnecting(false);
    }
  };

  const stopSession = () => {
    setIsActive(false);
    setStatus('idle');
    streamRef.current?.getTracks().forEach(track => track.stop());
    audioContextsRef.current?.input.close();
    audioContextsRef.current?.output.close();
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    sessionRef.current?.then((s: any) => s.close());
    sessionRef.current = null;
  };

  useEffect(() => {
    return () => stopSession();
  }, []);

  return (
    <div className="max-w-4xl mx-auto h-full flex flex-col space-y-6 animate-in fade-in duration-500">
      
      {/* Cinematic Header Card */}
      <div className="bg-gradient-to-br from-[#1e293b] to-[#0f172a] rounded-[2.5rem] p-10 border border-slate-800 shadow-2xl relative overflow-hidden group">
        <div className={`absolute -top-20 -right-20 w-80 h-80 rounded-full blur-[120px] transition-all duration-1000 ${isActive ? 'bg-emerald-500/20' : 'bg-indigo-500/10'}`}></div>
        
        <div className="relative z-10 flex flex-col items-center text-center space-y-8">
            <div className="flex flex-col items-center">
                <div className="p-4 bg-emerald-500/10 rounded-3xl border border-emerald-500/20 mb-4">
                    <Headphones className="w-10 h-10 text-emerald-500" />
                </div>
                <h2 className="text-3xl font-black text-white tracking-tight">المستشار الصوتي المباشر</h2>
                <p className="text-slate-400 text-sm mt-2 max-w-sm">تحدث مع "أفق" مباشرة للحصول على نصائح مالية فورية وتحليل لميزانيتك.</p>
            </div>

            {/* Visualizer Orb */}
            <div className="relative py-12">
                <div className={`
                    w-40 h-40 rounded-full flex items-center justify-center transition-all duration-700 relative
                    ${isActive ? 'bg-emerald-500/20 shadow-[0_0_50px_rgba(16,185,129,0.3)]' : 'bg-slate-800/50'}
                `}>
                    {/* Animated Rings */}
                    {isActive && (
                        <>
                            <div className="absolute inset-0 rounded-full border border-emerald-500/30 animate-ping"></div>
                            <div className={`absolute inset-0 rounded-full border-2 border-emerald-500/20 animate-pulse delay-75 ${status === 'speaking' ? 'scale-125' : 'scale-110'}`}></div>
                        </>
                    )}
                    
                    <div className={`
                        w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500 border-2
                        ${isActive ? 'bg-emerald-600 border-emerald-400 shadow-inner' : 'bg-slate-700 border-slate-600'}
                    `}>
                        {isConnecting ? (
                            <Loader2 className="w-10 h-10 text-white animate-spin" />
                        ) : isActive ? (
                            status === 'speaking' ? <Volume2 className="w-10 h-10 text-white animate-bounce" /> : <Mic className="w-10 h-10 text-white" />
                        ) : (
                            <MicOff className="w-10 h-10 text-slate-500" />
                        )}
                    </div>
                </div>
            </div>

            {/* Control Button */}
            <button 
                onClick={isActive ? stopSession : startSession}
                disabled={isConnecting}
                className={`
                    px-12 py-5 rounded-3xl font-black text-lg transition-all transform active:scale-95 shadow-2xl flex items-center gap-3
                    ${isActive 
                        ? 'bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500 hover:text-white' 
                        : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-emerald-900/30'}
                `}
            >
                {isActive ? <VolumeX className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                {isActive ? 'إنهاء المحادثة' : 'بدء التحدث الآن'}
            </button>
        </div>
      </div>

      {/* Transcription & Interaction Log */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#1e293b]/50 backdrop-blur-md rounded-3xl p-6 border border-slate-800 min-h-[150px] flex flex-col">
              <div className="flex items-center gap-2 mb-4 text-slate-400 text-xs font-black uppercase tracking-widest">
                  <UserIcon className="w-4 h-4 text-indigo-400" /> كلامك أنت
              </div>
              <p className="text-slate-200 text-lg font-medium leading-relaxed italic">
                  {userTranscription || (isActive ? 'أنا أستمع إليك...' : 'اضغط على البدء للتحدث')}
              </p>
          </div>

          <div className="bg-emerald-500/5 backdrop-blur-md rounded-3xl p-6 border border-emerald-500/10 min-h-[150px] flex flex-col">
              <div className="flex items-center gap-2 mb-4 text-emerald-400/60 text-xs font-black uppercase tracking-widest">
                  <Sparkles className="w-4 h-4 text-emerald-400" /> رد المساعد أفق
              </div>
              <p className="text-emerald-100 text-lg font-bold leading-relaxed">
                  {modelTranscription}
              </p>
              {status === 'speaking' && (
                  <div className="mt-auto flex gap-1 items-center">
                      <div className="w-1 h-3 bg-emerald-500 rounded-full animate-bounce"></div>
                      <div className="w-1 h-5 bg-emerald-500 rounded-full animate-bounce delay-75"></div>
                      <div className="w-1 h-3 bg-emerald-500 rounded-full animate-bounce delay-150"></div>
                  </div>
              )}
          </div>
      </div>

      {/* Instructions Card */}
      <div className="bg-slate-900/40 rounded-2xl p-4 border border-slate-800 flex items-center gap-4">
          <div className="p-2 bg-blue-500/10 rounded-lg">
              <Info className="w-5 h-5 text-blue-400" />
          </div>
          <p className="text-xs text-slate-500">
             للحصول على أفضل تجربة، تأكد من وجودك في مكان هادئ واستخدم سماعات الرأس. المساعد أفق يمكنه سماعك بشكل أفضل عند تفعيل الميكروفون.
          </p>
      </div>
    </div>
  );
};

export default LiveVoiceAdvisor;
