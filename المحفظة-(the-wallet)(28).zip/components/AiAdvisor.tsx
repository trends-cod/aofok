
import React, { useState, useRef, useEffect } from 'react';
import { User, Transaction } from '../types';
import { getFinancialAdvice, ChatHistoryMessage } from '../services/geminiService';
/* Added comment above fix: Added Clock icon to lucide-react imports to fix "Cannot find name 'Clock'" error */
import { 
  Bot, Send, User as UserIcon, Sparkles, Brain, 
  TrendingUp, Zap, Info, MessageSquare, Loader2, 
  ChevronLeft, BarChart3, ShieldCheck, Trash2, Clock
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface AiAdvisorProps {
  user: User;
  transactions: Transaction[];
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const AiAdvisor: React.FC<AiAdvisorProps> = ({ user, transactions }) => {
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'assistant', 
      content: `مرحباً بك يا **${user.name}**! أنا مساعدك المالي الذكي "أفق AI". 🤖\n\nلقد قمت بتحليل أرصدة محافظك وعملياتك الأخيرة. كيف يمكنني مساعدتك اليوم في إدارة أموالك؟` 
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    const newMessages = [...messages, { role: 'user' as const, content: userMsg }];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    // Convert UI messages to API history format (excluding the very last message)
    const apiHistory: ChatHistoryMessage[] = messages.map(m => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }]
    }));

    try {
      const response = await getFinancialAdvice(userMsg, user, transactions, apiHistory);
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'عذراً، واجهت صعوبة في معالجة طلبك. يرجى المحاولة مرة أخرى.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    if (confirm('هل تريد حقاً مسح سجل المحادثة والبدء من جديد؟')) {
      setMessages([{ 
        role: 'assistant', 
        content: `أهلاً بك مجدداً يا **${user.name}**. السجل الآن نظيف وجاهز لتحليلات جديدة. كيف أخدمك؟` 
      }]);
    }
  };

  const suggestions = [
    { text: "حلل نمط إنفاقي", icon: BarChart3 },
    { text: "نصيحة بخصوص رصيدي", icon: Zap },
    { text: "كيف أشحن حسابي؟", icon: Info },
    { text: "هل محفظتي آمنة؟", icon: ShieldCheck }
  ];

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-180px)] flex flex-col glass-card rounded-[3rem] border border-white/5 overflow-hidden shadow-2xl animate-in fade-in slide-in-from-bottom-6 duration-700">
      
      {/* Premium Header */}
      <div className="bg-[#0f172a]/80 backdrop-blur-xl p-6 md:p-8 flex items-center justify-between border-b border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2"></div>
        
        <div className="flex items-center gap-5 relative z-10">
          <div className="relative">
            <div className="w-14 h-14 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(16,185,129,0.4)] glossy-shine">
               <Bot className="w-8 h-8 text-white" />
            </div>
            <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-4 border-[#0f172a] ${isLoading ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`}></div>
          </div>
          <div>
             <h3 className="text-xl font-black text-white flex items-center gap-2">
                مستشار أفق الذكي
                <span className="bg-emerald-500/10 text-emerald-500 text-[9px] font-black px-2 py-0.5 rounded-full border border-emerald-500/20 uppercase tracking-tighter">Pro Context</span>
             </h3>
             <p className="text-slate-500 text-xs font-bold flex items-center gap-1.5 mt-1">
               <Brain className="w-3.5 h-3.5 text-emerald-400" />
               يفكر الآن باستخدام Gemini 3 Pro
             </p>
          </div>
        </div>

        <button 
          onClick={clearChat}
          className="p-3 bg-white/5 hover:bg-rose-500/10 text-slate-500 hover:text-rose-500 rounded-xl transition-all active:scale-90"
          title="مسح المحادثة"
        >
          <Trash2 size={18} />
        </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-8 scrollbar-hide bg-[#020617]/30">
        {messages.map((msg, index) => (
          <div 
            key={index} 
            className={`flex gap-5 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} animate-in fade-in slide-in-from-bottom-2 duration-500`}
          >
            <div className={`
              w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-lg
              ${msg.role === 'user' ? 'bg-slate-800' : 'bg-emerald-600/10 border border-emerald-500/20'}
            `}>
              {msg.role === 'user' ? <UserIcon className="w-5 h-5 text-slate-400" /> : <Bot className="w-5 h-5 text-emerald-500" />}
            </div>
            
            <div className={`
              max-w-[85%] md:max-w-[70%] p-6 rounded-[2rem] text-sm leading-relaxed shadow-xl relative
              ${msg.role === 'user' 
                ? 'bg-emerald-600 text-white rounded-tr-none' 
                : 'bg-[#0f172a]/80 text-slate-200 rounded-tl-none border border-white/5 backdrop-blur-md'}
            `}>
               <div className={`prose prose-invert prose-sm max-w-none ${msg.role === 'user' ? 'text-white font-bold' : 'text-slate-300'}`}>
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
               </div>
               <div className={`text-[8px] mt-3 font-black uppercase tracking-widest opacity-30 flex items-center gap-2 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                  <Clock size={8} /> {new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
               </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-5 animate-pulse">
             <div className="w-10 h-10 rounded-xl bg-emerald-600/10 border border-emerald-500/20 flex items-center justify-center">
                <Brain className="w-5 h-5 text-emerald-500 animate-pulse" />
             </div>
             <div className="bg-white/5 p-6 rounded-[2rem] rounded-tl-none border border-white/5 flex flex-col gap-3 min-w-[200px]">
                <div className="flex items-center gap-2 text-emerald-500/60 text-[10px] font-black uppercase tracking-widest">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    جاري التفكير في بياناتك...
                </div>
                <div className="space-y-2">
                    <div className="h-2 bg-white/5 rounded-full w-full"></div>
                    <div className="h-2 bg-white/5 rounded-full w-[60%]"></div>
                </div>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-6 md:p-10 bg-[#0f172a]/60 border-t border-white/5 backdrop-blur-2xl">
        <div className="flex gap-3 mb-6 overflow-x-auto pb-4 scrollbar-hide">
           {suggestions.map((s, i) => (
             <button 
               key={i} 
               onClick={() => setInput(s.text)}
               disabled={isLoading}
               className="whitespace-nowrap px-6 py-3 bg-white/5 text-slate-400 text-[10px] font-black rounded-2xl border border-white/5 hover:border-emerald-500/50 hover:bg-emerald-500/10 hover:text-emerald-400 transition-all flex items-center gap-2 active:scale-95 shadow-lg disabled:opacity-50"
             >
               <s.icon className="w-3 h-3" />
               {s.text}
             </button>
           ))}
        </div>

        <div className="flex items-center gap-4 bg-black/40 p-3 rounded-[2.5rem] border border-white/10 shadow-inner group focus-within:border-emerald-500/50 transition-all">
          <div className="w-12 h-12 rounded-full bg-slate-900 flex items-center justify-center text-slate-600 group-focus-within:text-emerald-500 transition-colors">
            <Zap size={20} />
          </div>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="اسأل 'أفق AI' عن ميزانيتك، أسعار الصرف، أو نصيحة ادخار..."
            className="flex-1 bg-transparent border-none px-2 py-3 text-white font-bold text-base outline-none placeholder:text-slate-700"
            disabled={isLoading}
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className={`
                p-5 rounded-full transition-all shadow-2xl flex items-center justify-center active:scale-90
                ${!input.trim() || isLoading 
                    ? 'bg-slate-800 text-slate-600' 
                    : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-emerald-900/40'}
            `}
          >
            {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-6 h-6 rtl:rotate-180" />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AiAdvisor;
