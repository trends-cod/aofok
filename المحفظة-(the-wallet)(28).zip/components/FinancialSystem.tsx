
import React, { useState, useEffect, useMemo } from 'react';
import { CurrencyConfig, ManualGateway } from '../types';
import { 
  DollarSign, TrendingUp, Percent, ArrowRightLeft, Shield, 
  AlertTriangle, Save, RefreshCw, Layers, Edit3, Check, X,
  Globe, Wallet, Activity, Landmark, Plus, Search, Filter, SortAsc, SortDesc,
  Link as LinkIcon, Unlink, Image as ImageIcon, Upload, Trash2, ToggleLeft, ToggleRight,
  Info, ChevronRight
} from 'lucide-react';

interface FinancialSystemProps {
  currencies: CurrencyConfig[];
  gateways: ManualGateway[];
  onUpdateCurrency: (currency: CurrencyConfig) => void;
  onAddCurrency: (currency: CurrencyConfig) => void;
  onDeleteCurrency: (code: string) => void;
  onUpdateGateway: (gateway: ManualGateway) => void;
  onAddGateway: (gateway: ManualGateway) => void;
  onDeleteGateway: (id: string) => void;
  onManageGateways: (currency: CurrencyConfig) => void;
  showAddModal?: boolean;
  onCloseAddModal?: () => void;
}

const FinancialSystem: React.FC<FinancialSystemProps> = ({ 
  currencies, gateways, onUpdateCurrency, onAddCurrency, onDeleteCurrency, 
  onUpdateGateway, onAddGateway, onDeleteGateway, onManageGateways,
  showAddModal, onCloseAddModal
}) => {
  const [activeTab, setActiveTab] = useState<'CURRENCIES' | 'GATEWAYS'>('CURRENCIES');
  const [editingCode, setEditingCode] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<CurrencyConfig | null>(null);
  const [editingGateway, setEditingGateway] = useState<ManualGateway | null>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [sortBy, setSortBy] = useState<'code' | 'name' | 'rate'>('code');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  useEffect(() => {
    if (showAddModal) {
        handleAddNewCurrency();
    }
  }, [showAddModal]);

  const handleAddNewCurrency = () => {
    setEditingCode('NEW');
    setEditForm({
        code: '', name: '', symbol: '', rateToUSD: 1, isActive: true, isBase: false,
        buyMargin: 0, sellMargin: 0, depositFee: 0, withdrawalFee: 0, transferFee: 0,
        minTransaction: 0, maxTransaction: 0
    });
  };

  const handleAddNewGateway = () => {
    setEditingGateway({
      id: `gw_${Date.now()}`,
      name: '',
      image: '🏦',
      instructions: '',
      isActive: true,
      order: (gateways.length + 1) * 10,
      supportedCurrencies: []
    });
  };

  const startEditCurrency = (currency: CurrencyConfig) => {
    setEditingCode(currency.code);
    setEditForm({ ...currency });
  };

  const cancelEdit = () => {
    setEditingCode(null);
    setEditForm(null);
    setEditingGateway(null);
    if (onCloseAddModal) onCloseAddModal();
  };

  const saveCurrency = () => {
    if (editForm) {
      if (editingCode === 'NEW') {
          if (!editForm.code || !editForm.name) {
              alert('يرجى إدخال رمز واسم العملة');
              return;
          }
          onAddCurrency(editForm);
      } else {
          onUpdateCurrency(editForm);
      }
      setEditingCode(null);
      setEditForm(null);
      if (onCloseAddModal) onCloseAddModal();
    }
  };

  const saveGateway = () => {
    if (editingGateway) {
      const isNew = !gateways.some(g => g.id === editingGateway.id);
      if (isNew) {
        onAddGateway(editingGateway);
      } else {
        onUpdateGateway(editingGateway);
      }
      setEditingGateway(null);
    }
  };

  const handleInputChange = (field: keyof CurrencyConfig, value: any) => {
    if (editForm) {
      setEditForm({ ...editForm, [field]: value });
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingGateway) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditingGateway({ ...editingGateway, image: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleGatewayForCurrency = (gateway: ManualGateway, currencyCode: string) => {
    if (!currencyCode) return;
    const supported = (gateway.supportedCurrencies || []);
    const isLinked = supported.includes(currencyCode);
    const newSupported = isLinked 
        ? supported.filter(c => c !== currencyCode)
        : [...supported, currencyCode];
    onUpdateGateway({ ...gateway, supportedCurrencies: newSupported });
  };

  const filteredCurrencies = useMemo(() => {
    let result = [...currencies];
    if (searchTerm) {
      const lower = searchTerm.toLowerCase();
      result = result.filter(c => 
        c.code.toLowerCase().includes(lower) || 
        c.name.toLowerCase().includes(lower)
      );
    }
    if (filterStatus !== 'all') {
      result = result.filter(c => filterStatus === 'active' ? c.isActive : !c.isActive);
    }
    result.sort((a, b) => {
      let cmp = 0;
      switch (sortBy) {
        case 'code': cmp = a.code.localeCompare(b.code); break;
        case 'name': cmp = a.name.localeCompare(b.name); break;
        case 'rate': cmp = a.rateToUSD - b.rateToUSD; break;
      }
      return sortOrder === 'asc' ? cmp : -cmp;
    });
    return result;
  }, [currencies, searchTerm, filterStatus, sortBy, sortOrder]);

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      
      {/* Header Widget */}
      <div className="glass-card p-10 rounded-[3rem] border border-white/5 relative overflow-hidden bg-gradient-to-br from-slate-900 to-[#020617]">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-10">
          <div className="text-right">
            <h2 className="text-4xl font-black text-white flex items-center gap-4">
              <div className="w-16 h-16 bg-emerald-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-emerald-900/40 transform -rotate-3">
                <Landmark className="w-8 h-8 text-white" />
              </div>
              النظام المالي المركزي
            </h2>
            <p className="text-slate-500 font-bold mt-3 text-lg">تحكم كامل في الأصول، بوابات الدفع، وسياسات التسعير.</p>
          </div>

          <div className="bg-black/30 p-2 rounded-3xl border border-white/5 flex gap-2 w-full lg:w-auto">
              <button 
                onClick={() => setActiveTab('CURRENCIES')}
                className={`flex-1 lg:px-10 py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all ${activeTab === 'CURRENCIES' ? 'bg-emerald-600 text-white shadow-xl' : 'text-slate-500 hover:text-white'}`}
              >
                العملات والصرف
              </button>
              <button 
                onClick={() => setActiveTab('GATEWAYS')}
                className={`flex-1 lg:px-10 py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all ${activeTab === 'GATEWAYS' ? 'bg-indigo-600 text-white shadow-xl' : 'text-slate-500 hover:text-white'}`}
              >
                بوابات الدفع
              </button>
          </div>
        </div>
      </div>

      {activeTab === 'CURRENCIES' ? (
        <div className="space-y-8 animate-in slide-in-from-bottom-4">
            <div className="flex flex-col md:flex-row gap-4 px-2">
                <div className="relative flex-1 group">
                    <Search className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600 group-focus-within:text-emerald-500 transition-colors" />
                    <input 
                        type="text" 
                        placeholder="بحث عن عملة..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-[#030712] border border-white/10 rounded-[1.8rem] py-5 pr-14 pl-6 text-white font-bold focus:border-emerald-500/50 outline-none transition-all shadow-inner"
                    />
                </div>
                <button 
                    onClick={handleAddNewCurrency} 
                    className="bg-emerald-600 hover:bg-emerald-500 text-white px-10 py-5 rounded-[1.8rem] font-black shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 uppercase text-xs tracking-widest"
                >
                    <Plus size={20} /> إضافة عملة
                </button>
            </div>

            {editingCode === 'NEW' && editForm && (
                <div className="glass-card rounded-[3rem] border border-emerald-500/50 bg-slate-900/40 p-10 space-y-10 animate-in zoom-in duration-300">
                    <div className="flex justify-between items-center border-b border-white/5 pb-6">
                        <h3 className="text-2xl font-black text-white">تعريف عملة جديدة</h3>
                        <div className="flex gap-3">
                            <button onClick={saveCurrency} className="bg-emerald-600 hover:bg-emerald-500 text-white p-4 rounded-2xl shadow-xl transition-all"><Save size={20}/></button>
                            <button onClick={cancelEdit} className="bg-white/5 hover:bg-rose-600 text-white p-4 rounded-2xl transition-all"><X size={20}/></button>
                        </div>
                    </div>
                    {/* Render Form logic here (shared with edit) */}
                    {renderCurrencyForm(editForm, handleInputChange, true, gateways, toggleGatewayForCurrency)}
                </div>
            )}

            <div className="grid grid-cols-1 gap-6">
                {filteredCurrencies.map(currency => (
                    <div key={currency.code} className={`glass-card rounded-[3rem] border border-white/5 overflow-hidden transition-all group ${editingCode === currency.code ? 'ring-2 ring-emerald-500/50 bg-slate-900/60' : 'hover:border-white/10'}`}>
                        <div className="p-8 flex flex-col lg:flex-row justify-between items-center gap-8">
                            <div className="flex items-center gap-6 w-full lg:w-auto">
                                <div className="w-20 h-20 rounded-3xl bg-[#030712] border border-white/10 flex items-center justify-center text-3xl font-black text-emerald-400 shadow-inner group-hover:scale-105 transition-transform">
                                    {currency.symbol}
                                </div>
                                <div>
                                    <div className="flex items-center gap-3">
                                        <h3 className="text-2xl font-black text-white">{currency.name}</h3>
                                        <span className="bg-white/5 px-3 py-1 rounded-xl text-xs font-mono text-slate-500 border border-white/5 uppercase">{currency.code}</span>
                                        {currency.isBase && <span className="bg-emerald-500 text-black text-[9px] font-black px-2 py-0.5 rounded-full">BASE</span>}
                                    </div>
                                    <p className="text-slate-500 font-mono mt-2 flex items-center gap-2">
                                        <TrendingUp size={14} className="text-emerald-500" />
                                        1 {currency.code} = {currency.rateToUSD.toFixed(6)} USD
                                    </p>
                                </div>
                            </div>

                            {editingCode !== currency.code && (
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 flex-1">
                                    {[
                                        { label: 'هامش البيع', val: `${currency.sellMargin}%`, icon: Percent, color: 'rose' },
                                        { label: 'هامش الشراء', val: `${currency.buyMargin}%`, icon: Percent, color: 'emerald' },
                                        { label: 'رسوم التحويل', val: `${currency.transferFee}%`, icon: ArrowRightLeft, color: 'indigo' },
                                        { label: 'البوابات', val: gateways.filter(g => g.supportedCurrencies?.includes(currency.code)).length, icon: Landmark, color: 'amber' }
                                    ].map((stat, i) => (
                                        <div key={i} className="bg-black/20 p-4 rounded-2xl border border-white/5 text-center">
                                            <p className="text-[9px] text-slate-500 font-black uppercase mb-1">{stat.label}</p>
                                            <p className={`text-sm font-black text-${stat.color}-400 font-mono`}>{stat.val}</p>
                                        </div>
                                    ))}
                                </div>
                            )}

                            <div className="flex gap-3">
                                {editingCode === currency.code ? (
                                    <>
                                        <button onClick={saveCurrency} className="bg-emerald-600 hover:bg-emerald-500 text-white p-4 rounded-2xl shadow-xl transition-all"><Save size={20}/></button>
                                        <button onClick={cancelEdit} className="bg-white/5 hover:bg-rose-600 text-white p-4 rounded-2xl transition-all"><X size={20}/></button>
                                    </>
                                ) : (
                                    <>
                                        <button onClick={() => startEditCurrency(currency)} className="bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white p-4 rounded-2xl border border-white/5 transition-all"><Edit3 size={20}/></button>
                                        <button onClick={() => onDeleteCurrency(currency.code)} className="bg-white/5 hover:bg-rose-600 text-slate-400 hover:text-white p-4 rounded-2xl border border-white/5 transition-all"><Trash2 size={20}/></button>
                                    </>
                                )}
                            </div>
                        </div>
                        {editingCode === currency.code && (
                            <div className="p-10 border-t border-white/5 bg-[#030712]/20">
                                {renderCurrencyForm(editForm!, handleInputChange, false, gateways, toggleGatewayForCurrency)}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
      ) : (
        <div className="space-y-8 animate-in slide-in-from-bottom-4">
             <div className="flex flex-col md:flex-row justify-between items-center gap-6 px-2">
                <div className="text-right">
                    <h3 className="text-2xl font-black text-white">سجل بوابات الدفع</h3>
                    <p className="text-slate-500 font-bold mt-1">إدارة البوابات العالمية المتاحة في النظام لجميع العملات.</p>
                </div>
                <button 
                    onClick={handleAddNewGateway}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white px-10 py-5 rounded-[1.8rem] font-black shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 uppercase text-xs tracking-widest"
                >
                    <PlusSquare size={20} /> إضافة بوابة دفع
                </button>
            </div>

            {editingGateway && (
                <div className="glass-card rounded-[3rem] border border-indigo-500/50 bg-slate-900/40 p-10 space-y-8 animate-in zoom-in duration-300">
                    <div className="flex justify-between items-center border-b border-white/5 pb-6">
                        <h3 className="text-2xl font-black text-white">{gateways.some(g => g.id === editingGateway.id) ? 'تعديل بوابة دفع' : 'إضافة بوابة دفع جديدة'}</h3>
                        <div className="flex gap-3">
                            <button onClick={saveGateway} className="bg-indigo-600 hover:bg-indigo-500 text-white p-4 rounded-2xl shadow-xl transition-all"><Save size={20}/></button>
                            <button onClick={() => setEditingGateway(null)} className="bg-white/5 hover:bg-rose-600 text-white p-4 rounded-2xl transition-all"><X size={20}/></button>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                        <div className="space-y-6">
                            <div className="space-y-2">
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">اسم البوابة</label>
                                <input type="text" value={editingGateway.name} onChange={e => setEditingGateway({...editingGateway, name: e.target.value})} className="w-full bg-[#030712] border border-white/10 rounded-2xl p-5 text-white font-bold outline-none focus:border-indigo-500 transition-all" />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الترتيب</label>
                                    <input type="number" value={editingGateway.order} onChange={e => setEditingGateway({...editingGateway, order: parseInt(e.target.value) || 0})} className="w-full bg-[#030712] border border-white/10 rounded-2xl p-5 text-white font-black outline-none focus:border-indigo-500" />
                                </div>
                                <div className="flex items-end pb-1">
                                    <button onClick={() => setEditingGateway({...editingGateway, isActive: !editingGateway.isActive})} className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${editingGateway.isActive ? 'bg-emerald-600/10 text-emerald-500 border border-emerald-500/20' : 'bg-rose-600/10 text-rose-500 border border-rose-500/20'}`}>
                                        {editingGateway.isActive ? 'بوابة نشطة' : 'بوابة معطلة'}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-6">
                            <div className="space-y-2">
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الأيقونة (Logo / Emoji)</label>
                                <div className="flex gap-4">
                                    <div className="w-24 h-24 bg-[#030712] rounded-3xl border border-white/10 flex items-center justify-center text-4xl shrink-0 overflow-hidden relative group">
                                        {editingGateway.image.startsWith('http') || editingGateway.image.startsWith('data:') ? <img src={editingGateway.image} className="w-full h-full object-contain p-2" /> : editingGateway.image}
                                        <label className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                                            <Upload className="w-6 h-6 text-white" />
                                            <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                                        </label>
                                    </div>
                                    <input type="text" value={editingGateway.image} onChange={e => setEditingGateway({...editingGateway, image: e.target.value})} className="flex-1 bg-[#030712] border border-white/10 rounded-2xl p-5 text-white font-mono text-xs outline-none focus:border-indigo-500" placeholder="Emoji or URL..." />
                                </div>
                            </div>
                        </div>

                        <div className="lg:col-span-2 space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">تعليمات الدفع (تظهر للعميل)</label>
                            <textarea value={editingGateway.instructions} onChange={e => setEditingGateway({...editingGateway, instructions: e.target.value})} className="w-full bg-[#030712] border border-white/10 rounded-[2rem] p-8 text-white font-medium text-sm h-40 resize-none outline-none focus:border-indigo-500 leading-relaxed" placeholder="أدخل بيانات الحساب البنكي، أو عنوان المحفظة، أو أي تعليمات أخرى..." />
                        </div>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {gateways.map(gw => (
                    <div key={gw.id} className="glass-card p-8 rounded-[2.5rem] border border-white/5 group hover:border-indigo-500/40 transition-all flex flex-col justify-between h-full bg-[#030712]/20">
                        <div>
                            <div className="flex justify-between items-start mb-6">
                                <div className="w-16 h-16 rounded-2xl bg-[#030712] border border-white/10 flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 transition-transform">
                                    {gw.image.startsWith('http') || gw.image.startsWith('data:') ? <img src={gw.image} className="w-full h-full object-contain p-2" /> : gw.image}
                                </div>
                                <div className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${gw.isActive ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
                                    {gw.isActive ? 'نشط' : 'معطل'}
                                </div>
                            </div>
                            <h4 className="text-xl font-black text-white mb-2">{gw.name}</h4>
                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-4">مرتبطة بـ {gw.supportedCurrencies?.length || 0} عملة</p>
                            <div className="bg-black/20 p-4 rounded-2xl border border-white/5 mb-6">
                                <p className="text-[10px] text-slate-500 leading-relaxed line-clamp-2 italic">{gw.instructions}</p>
                            </div>
                        </div>
                        
                        <div className="flex gap-3 pt-4 border-t border-white/5">
                            <button onClick={() => setEditingGateway(gw)} className="flex-1 bg-white/5 hover:bg-indigo-600 text-slate-400 hover:text-white py-3 rounded-xl transition-all flex items-center justify-center gap-2 text-[10px] font-black uppercase"><Edit3 size={14}/> تعديل</button>
                            <button onClick={() => onDeleteGateway(gw.id)} className="bg-white/5 hover:bg-rose-600 text-slate-400 hover:text-white p-3 rounded-xl transition-all"><Trash2 size={16}/></button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      )}
    </div>
  );
};

const renderCurrencyForm = (data: CurrencyConfig, onChange: any, isNew: boolean, allGateways: ManualGateway[], toggleGateway: any) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        <div className="space-y-6">
            <h4 className="text-emerald-500 font-black text-xs uppercase tracking-widest border-b border-emerald-500/20 pb-3 flex items-center gap-2"><Globe className="w-4 h-4" /> البيانات الأساسية</h4>
            <div className="space-y-4">
                {isNew && (
                    <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">الرمز</label><input type="text" value={data.code} onChange={e => onChange('code', e.target.value.toUpperCase())} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-mono font-bold" placeholder="USD" /></div>
                        <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">العلامة</label><input type="text" value={data.symbol} onChange={e => onChange('symbol', e.target.value)} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-bold" placeholder="$" /></div>
                    </div>
                )}
                <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">اسم العملة</label><input type="text" value={data.name} onChange={e => onChange('name', e.target.value)} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-bold" placeholder="US Dollar" /></div>
                <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">سعر الصرف (لكل 1 USD)</label><input type="number" value={data.rateToUSD} onChange={e => onChange('rateToUSD', Number(e.target.value))} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-emerald-400 font-mono font-bold" step="0.000001" /></div>
            </div>
        </div>

        <div className="space-y-6">
            <h4 className="text-blue-500 font-black text-xs uppercase tracking-widest border-b border-blue-500/20 pb-3 flex items-center gap-2"><TrendingUp className="w-4 h-4" /> هوامش الربح (%)</h4>
            <div className="space-y-4">
                <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">هامش الشراء</label><input type="number" value={data.buyMargin} onChange={e => onChange('buyMargin', Number(e.target.value))} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-mono" /></div>
                <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">هامش البيع</label><input type="number" value={data.sellMargin} onChange={e => onChange('sellMargin', Number(e.target.value))} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-mono" /></div>
            </div>
        </div>

        <div className="space-y-6">
            <h4 className="text-amber-500 font-black text-xs uppercase tracking-widest border-b border-amber-500/20 pb-3 flex items-center gap-2"><Percent className="w-4 h-4" /> هيكل الرسوم (%)</h4>
            <div className="space-y-4">
                <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">رسوم التحويل الداخلي</label><input type="number" value={data.transferFee} onChange={e => onChange('transferFee', Number(e.target.value))} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-mono" /></div>
                <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">رسوم السحب</label><input type="number" value={data.withdrawalFee} onChange={e => onChange('withdrawalFee', Number(e.target.value))} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-mono" /></div>
            </div>
        </div>

        <div className="space-y-6">
            <h4 className="text-rose-500 font-black text-xs uppercase tracking-widest border-b border-rose-500/20 pb-3 flex items-center gap-2"><Shield className="w-4 h-4" /> حدود العمليات</h4>
            <div className="space-y-4">
                <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">الحد الأدنى</label><input type="number" value={data.minTransaction} onChange={e => onChange('minTransaction', Number(e.target.value))} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-mono" /></div>
                <div className="space-y-1"><label className="text-[9px] text-slate-600 font-black uppercase px-2">الحد الأقصى</label><input type="number" value={data.maxTransaction} onChange={e => onChange('maxTransaction', Number(e.target.value))} className="w-full bg-[#030712] border border-white/10 rounded-xl p-3 text-white font-mono" /></div>
            </div>
        </div>

        <div className="lg:col-span-4 pt-10 border-t border-white/5">
            <div className="flex justify-between items-center mb-6">
                <h4 className="text-indigo-400 font-black text-xs uppercase tracking-widest flex items-center gap-2"><Landmark size={18}/> ربط بوابات الدفع لهذه العملة</h4>
                <p className="text-[10px] text-slate-600 font-bold">سيتم عرض هذه البوابات للعميل عند شحن رصيد بـ {data.code}</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {allGateways.map(gw => {
                    const isLinked = gw.supportedCurrencies?.includes(data.code);
                    return (
                        <button
                            key={gw.id}
                            type="button"
                            onClick={() => toggleGateway(gw, data.code)}
                            className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-3 active:scale-95 group ${isLinked ? 'bg-emerald-600/10 border-emerald-500 text-white shadow-lg' : 'bg-[#030712] border-white/5 text-slate-500 hover:border-white/20'}`}
                        >
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0 border ${isLinked ? 'bg-emerald-500/20 border-emerald-500/20' : 'bg-slate-900 border-white/5'}`}>
                                {gw.image.startsWith('http') || gw.image.startsWith('data:') ? <img src={gw.image} className="w-full h-full object-contain p-1" /> : gw.image}
                            </div>
                            <div className="text-center overflow-hidden">
                                <p className="text-[10px] font-black truncate w-full">{gw.name}</p>
                                <div className="flex items-center justify-center gap-1.5 mt-1">
                                    <div className={`w-1.5 h-1.5 rounded-full ${isLinked ? 'bg-emerald-500' : 'bg-slate-700'}`}></div>
                                    <span className="text-[8px] font-black uppercase">{isLinked ? 'متصلة' : 'مفصولة'}</span>
                                </div>
                            </div>
                        </button>
                    );
                })}
            </div>
        </div>
    </div>
);

const PlusSquare: React.FC<{size?: number}> = ({size = 24}) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
);

export default FinancialSystem;
