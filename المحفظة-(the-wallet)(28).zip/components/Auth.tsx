
import React, { useState } from 'react';
import { Wallet, Mail, Lock, User as UserIcon, ArrowRight, Shield, Zap, Check, Copy, Star, ArrowLeft } from 'lucide-react';

interface AuthProps {
  onLogin: (email: string, password: string) => void;
  onRegister: (name: string, email: string, password: string) => void;
  error?: string;
  onClearError?: () => void;
  onBack?: () => void; // Added prop
}

const Auth: React.FC<AuthProps> = ({ onLogin, onRegister, error, onClearError, onBack }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    if (isLogin) {
      onLogin(email, password);
    } else {
      onRegister(name, email, password);
    }
    setLoading(false);
  };

  const handleCopyLink = () => {
      navigator.clipboard.writeText(window.location.href);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center p-4 relative overflow-hidden" dir="rtl">
      
      {/* Back Button */}
      {onBack && (
        <button 
            onClick={onBack}
            className="absolute top-6 right-6 z-50 p-3 bg-white/5 hover:bg-white/10 text-white rounded-xl backdrop-blur-md border border-white/5 transition-all flex items-center gap-2 group"
        >
            <ArrowRight size={20} className="group-hover:-translate-x-1 transition-transform" />
            <span className="font-bold text-xs">العودة للرئيسية</span>
        </button>
      )}

      {/* Dynamic Background Effects */}
      <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute top-[-10%] right-[-5%] w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[120px] animate-pulse"></div>
          <div className="absolute bottom-[-10%] left-[-5%] w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[120px] animate-pulse delay-700"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10"></div>
      </div>

      <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 bg-[#0f172a]/60 backdrop-blur-2xl rounded-[3rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.5)] overflow-hidden border border-white/5 animate-in fade-in zoom-in duration-500 relative z-10">
        
        {/* Left Side: Branding & Inspiration */}
        <div className="hidden lg:flex flex-col justify-between p-12 bg-gradient-to-br from-emerald-900/80 via-[#064e3b]/50 to-[#020617] relative overflow-hidden">
             {/* Decorative Circles */}
             <div className="absolute top-10 right-10 w-32 h-32 bg-emerald-400/20 rounded-full blur-3xl"></div>
             <div className="absolute bottom-10 left-10 w-40 h-40 bg-indigo-400/20 rounded-full blur-3xl"></div>
             
             <div className="relative z-10">
                 <div className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/10 mb-8 shadow-lg">
                     <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.4)]">
                         <Wallet className="w-5 h-5 text-white" />
                     </div>
                     <span className="text-xl font-black text-white tracking-tight">محفظة أفق</span>
                 </div>
                 
                 <h1 className="text-5xl font-black text-white mb-6 leading-tight drop-shadow-lg">
                     بوابتك نحو <br/>
                     <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">المستقبل المالي</span>
                 </h1>
                 <p className="text-slate-300 font-bold text-lg leading-relaxed max-w-md">
                     انضم إلى مجتمع النخبة وتمتع بأسرع وأأمن تجربة مالية رقمية. تحويلات فورية، استثمار ذكي، وخدمات دفع بلا حدود.
                 </p>
             </div>
             
             {/* Removed Demo/Quick Access Buttons */}
             <div className="relative z-10 mt-12 opacity-50 pointer-events-none">
                 {/* Placeholder for future promotional content or just empty space */}
             </div>
        </div>

        {/* Right Side: Auth Form */}
        <div className="p-10 md:p-14 bg-white dark:bg-[#0b1120] flex flex-col justify-center relative">
          {/* Mobile Header (Visible only on small screens) */}
          <div className="lg:hidden mb-8 text-center">
             <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-500 rounded-2xl shadow-lg shadow-emerald-500/30 mb-4">
                 <Wallet className="w-8 h-8 text-white" />
             </div>
             <h2 className="text-2xl font-black text-white">Horizon Wallet</h2>
          </div>

          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center p-3 bg-emerald-500/10 rounded-full mb-4 animate-bounce">
                <Star className="w-6 h-6 text-emerald-500 fill-current" />
            </div>
            <h2 className="text-3xl font-black text-white mb-3">
              {isLogin ? 'مرحباً بك في أفق! 🚀' : 'انضم إلينا الآن! ✨'}
            </h2>
            <p className="text-slate-400 text-sm font-medium max-w-sm mx-auto leading-relaxed">
              {isLogin 
                ? 'ابدأ رحلتك نحو الحرية المالية اليوم. عالم من الإمكانيات بانتظارك، سجل الدخول للمتابعة.' 
                : 'أنشئ حسابك الجديد في ثوانٍ واستمتع بمميزات حصرية ومكافآت ترحيبية.'}
            </p>
          </div>

          {error && (
            <div className="bg-rose-500/10 text-rose-500 p-4 rounded-2xl text-xs font-black mb-6 text-center border border-rose-500/20 flex items-center justify-center gap-2 animate-in fade-in slide-in-from-top-2">
              <Shield className="w-4 h-4" /> {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {!isLogin && (
              <div className="group relative transition-all duration-300 focus-within:-translate-y-1">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-emerald-500 transition-colors pointer-events-none">
                    <UserIcon className="w-5 h-5" />
                </div>
                <input 
                  type="text" 
                  placeholder="الاسم الكامل"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-4 pr-4 pl-12 font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all shadow-inner text-right"
                  required={!isLogin}
                />
              </div>
            )}

            <div className="group relative transition-all duration-300 focus-within:-translate-y-1">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-emerald-500 transition-colors pointer-events-none">
                  {isLogin ? <UserIcon className="w-5 h-5" /> : <Mail className="w-5 h-5" />}
              </div>
              <input 
                type={isLogin ? "text" : "email"}
                placeholder={isLogin ? "البريد الإلكتروني أو كود المستخدم" : "البريد الإلكتروني"}
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-4 pr-4 pl-12 font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all shadow-inner text-right"
                required
              />
            </div>

            <div className="group relative transition-all duration-300 focus-within:-translate-y-1">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-emerald-500 transition-colors pointer-events-none">
                  <Lock className="w-5 h-5" />
              </div>
              <input 
                type="password" 
                placeholder="كلمة المرور"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-4 pr-4 pl-12 font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all shadow-inner text-right"
                required
              />
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white py-4 rounded-2xl font-black text-lg transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-70 flex items-center justify-center gap-2 active:scale-95 group mt-4"
            >
              {loading ? (
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  {isLogin ? 'دخول آمن' : 'إنشاء حساب جديد'}
                  <ArrowRight className="w-5 h-5 rtl:rotate-180 group-hover:-translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-slate-500 text-sm font-bold mb-4">
                {isLogin ? 'ليس لديك حساب؟' : 'لديك حساب بالفعل؟'}
            </p>
            <button 
              onClick={() => { setIsLogin(!isLogin); if (onClearError) onClearError(); }}
              className="px-8 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-500 font-black text-sm border border-slate-800 hover:border-emerald-500/30 transition-all"
            >
              {isLogin ? 'انشئ حساباً جديداً' : 'سجل الدخول'}
            </button>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-800 flex justify-center">
             <button 
                onClick={handleCopyLink}
                className="flex items-center gap-2 text-slate-500 hover:text-white text-xs font-bold transition-colors group"
             >
                {linkCopied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                {linkCopied ? 'تم النسخ' : 'مشاركة التطبيق'}
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
