
import React from 'react';
import ReactMarkdown from 'react-markdown';
import { CustomPage } from '../types';
import { Calendar, FileText } from 'lucide-react';

interface PageViewerProps {
  page: CustomPage;
}

const PageViewer: React.FC<PageViewerProps> = ({ page }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20">
      
      {/* Header */}
      <div className="bg-[#1e293b] rounded-[3rem] p-10 border border-white/5 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2"></div>
        <div className="relative z-10">
            <h1 className="text-4xl font-black text-white mb-4">{page.title}</h1>
            <div className="flex items-center gap-4 text-slate-400 text-xs font-bold uppercase tracking-widest">
                <span className="flex items-center gap-2"><FileText className="w-4 h-4"/> صفحة رسمية</span>
                <span className="w-1 h-1 bg-slate-600 rounded-full"></span>
                <span className="flex items-center gap-2"><Calendar className="w-4 h-4"/> آخر تحديث: {new Date(page.lastUpdated).toLocaleDateString()}</span>
            </div>
        </div>
      </div>

      {/* Content */}
      <div className="glass-card rounded-[2.5rem] p-10 md:p-14 border border-white/5 shadow-2xl">
        <div className="prose prose-invert prose-lg max-w-none">
            <ReactMarkdown>{page.content}</ReactMarkdown>
        </div>
      </div>
    </div>
  );
};

export default PageViewer;
