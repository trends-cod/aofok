
import React, { useState, useEffect, useMemo } from 'react';
import { User, Currency, CurrencyConfig, View } from '../types';
import { RefreshCcw, TrendingUp, Wallet, Loader2, CheckCircle, Share2, X, Clock, Check, Sparkles, DollarSign, ArrowDownLeft, ChevronRight, Info, ArrowLeftRight, ShieldCheck } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface ExchangeProps {
  user: User;
  currencies: CurrencyConfig[];
  onExchange: (from: Currency, to: Currency, amountFrom: number, amountTo: number) => Promise<boolean>;
  onNavigate: (view: View) => void;
}

const Exchange: React.FC<ExchangeProps> = ({ user, currencies, onExchange, onNavigate }) => {
  const [fromCurrency, setFromCurrency] = useState<string>(currencies[0]?.code || 'USD');
  const [toCurrency, setToCurrency] = useState<string>(currencies[1]?.code || 'SAR');
  const [amountFrom, setAmountFrom] = useState<string>('');
  const [amountTo, setAmountTo] = useState<string>('');
  const [status, setStatus] = useState<'IDLE' | 'PROCESSING' | 'SUCCESS'>('IDLE');

  const getRate = (fromCode: string, toCode: string): number => {
    if (fromCode === toCode) return 1;
    const fromCurr = currencies.find(c => c.code === fromCode);
    const toCurr = currencies.find(c => c.code === toCode);
    if (!fromCurr || !toCurr) return 1;
    const baseRate = fromCurr.rateToUSD / toCurr.rateToUSD;
    const spread = fromCurr.sellMargin || 0; 
    return baseRate * (1 - (spread / 100));
  };

  const currentRate = getRate(fromCurrency, toCurrency);

  const historyData = useMemo(() => {
    const data = [];
    const seed = fromCurrency.charCodeAt(0) + toCurrency.charCodeAt(0);
    for (let i = 6; i >= 0; i--) {
      const noise = Math.sin(i + seed) * (currentRate * 0.02); 
      data.push({ day: `d${i}`, rate: currentRate + noise });
    }
    return data;
  }, [fromCurrency, toCurrency, currentRate]);

  useEffect(() => {
    if (amountFrom && !isNaN(Number(amountFrom))) setAmountTo((Number(amountFrom) * currentRate).toFixed(4));
    else setAmountTo('');
  }, [amountFrom, currentRate]);

  const handleSwap = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
    setAmountFrom(amountTo);
  };

  const handleExchange = async () => {
    if (!amountFrom || Number(amountFrom) <= 0) return;
    setStatus('PROCESSING');
    
    // Simulate a brief delay for effect
    await new Promise(resolve => setTimeout(resolve, 800));

    const success = await onExchange(fromCurrency, toCurrency, Number(amountFrom), Number(amountTo));
    
    if (success) {
      setStatus('SUCCESS');
    } else {
      setStatus('IDLE');
    }
  };

  const fromWallet = user.wallets.find(w => w.currency === fromCurrency);
  const toWallet = user.wallets.find(w => w.currency === toCurrency);

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-in slide-in-from-bottom-6 duration-500 relative" dir="rtl">
      {status === 'SUCCESS' ? (
        <div className="flex flex-col items-center justify-center min-h-[500px] bg-[#0a0f1e] rounded-[3.5rem] border border-emerald-500/20 p-8 text-center animate-in zoom-in shadow-[0_30px_80px_rgba(0,0,0,0.7)] relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-[100px]"></div>
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/10 rounded-full blur-[100px]"></div>
            
            <div className="relative z-10 w-full max-w-2xl flex flex-col items-center">
                <div className="w-28 h-28 bg-emerald-500/20 rounded-full flex items-center justify-center mb-8 border-4 border-emerald-500/30 shadow-[0_0_40px_rgba(16,185,129,0.3)] animate-in zoom-in duration-300 delay-100">
                    <CheckCircle className="w-14 h-14 text-emerald-500" />
                </div>
                
                <h2 className="text-4xl font-black text-white mb-4">تم التحويل بنجاح! 🎉</h2>
                <p className="text-slate-400 text-lg mb-10 max-w-md mx-auto leading-relaxed">
                    تم تحويل الرصيد وإضافته إلى محفظتك مباشرة. يمكنك الآن استخدام <span className="text-white font-bold">{toCurrency}</span> في عملياتك.
                </p>
                
                <div className="w-full max-w-sm bg-black/40 p-8 rounded-[2.5rem] border border-white/5 space-y-6 mb-10 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-blue-500"></div>
                    <div className="flex justify-between items-center">
                        <div className="text-right">
                            <span className="text-slate-500 font-bold text-[10px] uppercase tracking-widest">المحول</span>
                            <p className="text-white font-mono font-black text-xl">{amountFrom} <span className="text-slate-500 text-sm">{fromCurrency}</span></p>
                        </div>
                        <ArrowLeftRight className="text-slate-600" />
                        <div className="text-left">
                            <span className="text-slate-500 font-bold text-[10px] uppercase tracking-widest">المستلم</span>
                            <p className="text-emerald-400 font-mono font-black text-xl">{amountTo} <span className="text-emerald-600 text-sm">{toCurrency}</span></p>
                        </div>
                    </div>
                </div>

                <div className="flex gap-4 w-full max-w-md">
                    <button onClick={() => { setStatus('IDLE'); setAmountFrom(''); }} className="flex-1 px-8 py-5 bg-slate-800 hover:bg-slate-700 text-white rounded-2xl font-black transition-all shadow-xl active:scale-95">عملية جديدة</button>
                    <button onClick={() => onNavigate(View.WALLET)} className="flex-1 px-8 py-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black transition-all shadow-xl shadow-emerald-900/20 active:scale-95 flex items-center justify-center gap-2">
                        المحفظة <Wallet size={18} />
                    </button>
                </div>
            </div>
        </div>
      ) : (
        <div className="bg-[#0f172a] rounded-[3.5rem] shadow-[0_40px_100px_rgba(0,0,0,0.6)] overflow-hidden border border-slate-800 relative">
          <div className="bg-slate-900/50 p-10 text-center border-b border-slate-800 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-64 h-64 bg-blue-500/5 rounded-full blur-[80px]"></div>
              <h2 className="text-3xl font-black text-white flex items-center justify-center gap-4 relative z-10">
                  <div className="p-3 bg-blue-500/10 rounded-2xl">
                    <RefreshCcw className="w-8 h-8 text-blue-500 animate-spin-slow" />
                  </div>
                  مركز تبديل العملات
              </h2>
              <p className="text-slate-500 font-bold mt-3 relative z-10 max-w-lg mx-auto">
                قم بالتحويل من محفظة لعملة أخرى بسهولة. (مثال: من محفظة <span className="text-emerald-500">الدولار</span> إلى محفظة <span className="text-blue-500">الجنيه</span>)
              </p>
          </div>
          
          <div className="p-8 md:p-14 space-y-12">
            <div className="flex flex-col gap-10 items-center relative">
              
              {/* محفظة المصدر - ترسل من */}
              <div className="w-full bg-[#020617] p-10 rounded-[3.5rem] border border-white/5 shadow-inner group focus-within:border-blue-500/30 transition-all relative">
                <div className="flex justify-between items-center mb-5">
                   <div className="flex items-center gap-2 text-slate-500">
                      <span className="text-[10px] font-black uppercase tracking-[0.2em]">ترسل من محفظة</span>
                      <Info size={12} className="opacity-50" />
                   </div>
                   <span className="text-[9px] text-slate-700 font-bold">مثلاً: محفظة الدولار</span>
                </div>
                
                <div className="flex gap-6 items-center">
                    <div className="flex items-center gap-3 bg-slate-900 border border-white/10 rounded-3xl p-3 pl-6 pr-4 cursor-pointer hover:border-blue-500/50 transition-all min-w-[140px] relative">
                        <select 
                          value={fromCurrency} 
                          onChange={(e) => setFromCurrency(e.target.value)} 
                          className="absolute inset-0 opacity-0 cursor-pointer z-10 w-full"
                        >
                            {currencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                        </select>
                        <span className="text-2xl font-black text-white">{fromCurrency}</span>
                        <ArrowLeftRight size={18} className="text-slate-600 group-hover:text-blue-500 transition-colors" />
                    </div>
                    
                    <input 
                        type="number" 
                        value={amountFrom} 
                        onChange={(e) => setAmountFrom(e.target.value)} 
                        placeholder="0.00" 
                        className="flex-1 bg-transparent text-7xl font-black text-white focus:outline-none placeholder-slate-900 text-left dir-ltr font-mono tracking-tighter" 
                    />
                </div>
                
                <div className="mt-10 bg-white/[0.02] p-5 rounded-[2rem] border border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-500/10 rounded-xl text-blue-500">
                          <Wallet size={16} />
                        </div>
                        <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">الرصيد المتاح:</span>
                    </div>
                    <span className="text-white font-mono font-black text-lg">{fromWallet?.balance.toLocaleString() || '0.00'} <span className="text-slate-600 text-xs">{fromCurrency}</span></span>
                </div>
              </div>

              {/* أيقونة التبديل المتحركة */}
              <div className="relative h-4 w-full flex items-center justify-center">
                  <div className="absolute h-[1px] w-full bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
                  <button onClick={handleSwap} className="relative z-10 bg-blue-600 hover:bg-blue-500 p-6 rounded-[2rem] shadow-[0_0_50px_rgba(59,130,246,0.4)] transition-all text-white active:scale-90 border-4 border-[#0f172a] hover:rotate-180 duration-700 group">
                      <RefreshCcw className="w-7 h-7 group-hover:scale-110 transition-transform" />
                  </button>
              </div>

              {/* محفظة الهدف - تستلم في */}
              <div className="w-full bg-[#020617] p-10 rounded-[3.5rem] border border-white/5 shadow-inner group focus-within:border-emerald-500/30 transition-all relative">
                <div className="flex justify-between items-center mb-5">
                   <div className="flex items-center gap-2 text-slate-500">
                      <span className="text-[10px] font-black uppercase tracking-[0.2em]">تستلم في محفظة</span>
                      <Info size={12} className="opacity-50" />
                   </div>
                   <span className="text-[9px] text-slate-700 font-bold">مثلاً: محفظة الجنيه</span>
                </div>

                <div className="flex gap-6 items-center">
                    <div className="flex items-center gap-3 bg-slate-900 border border-white/10 rounded-3xl p-3 pl-6 pr-4 cursor-pointer hover:border-emerald-500/50 transition-all min-w-[140px] relative">
                        <select 
                          value={toCurrency} 
                          onChange={(e) => setToCurrency(e.target.value)} 
                          className="absolute inset-0 opacity-0 cursor-pointer z-10 w-full"
                        >
                            {currencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                        </select>
                        <span className="text-2xl font-black text-white">{toCurrency}</span>
                        <ArrowLeftRight size={18} className="text-slate-600 group-hover:text-emerald-500 transition-colors" />
                    </div>
                    
                    <input 
                        type="number" 
                        value={amountTo} 
                        readOnly 
                        placeholder="0.00" 
                        className="flex-1 bg-transparent text-7xl font-black text-emerald-400 focus:outline-none dir-ltr font-mono tracking-tighter text-left" 
                    />
                </div>
                
                <div className="mt-10 bg-white/[0.02] p-5 rounded-[2rem] border border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-500">
                          <ArrowDownLeft size={16} />
                        </div>
                        <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">رصيدك الحالي:</span>
                    </div>
                    <span className="text-white font-mono font-black text-lg">{toWallet?.balance.toLocaleString() || '0.00'} <span className="text-slate-600 text-xs">{toCurrency}</span></span>
                </div>
              </div>
            </div>

            {/* مؤشر سعر الصرف والسوق */}
            <div className="space-y-6">
                <div className="flex justify-between items-center px-4">
                    <div className="flex items-center gap-3">
                        <TrendingUp className="text-blue-500 w-5 h-5" />
                        <span className="text-white font-black text-xs uppercase tracking-widest">مؤشر السوق المباشر</span>
                    </div>
                    <div className="bg-blue-500/10 px-6 py-2 rounded-full border border-blue-500/20 shadow-lg">
                        <span className="font-mono text-blue-400 font-black text-sm">1 {fromCurrency} = {currentRate.toFixed(4)} {toCurrency}</span>
                    </div>
                </div>
                <div className="h-64 w-full bg-black/40 rounded-[3rem] p-8 border border-white/5 shadow-inner">
                    <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={historyData}>
                        <defs>
                            <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <YAxis hide domain={['auto', 'auto']} />
                        <Area type="monotone" dataKey="rate" stroke="#3b82f6" strokeWidth={4} fillOpacity={1} fill="url(#colorRate)" />
                    </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* زر تنفيذ الطلب */}
            <button 
                onClick={handleExchange} 
                disabled={status === 'PROCESSING' || !amountFrom || Number(amountFrom) <= 0 || Number(amountFrom) > (fromWallet?.balance || 0)} 
                className={`w-full py-9 rounded-[2.8rem] font-black text-2xl transition-all shadow-[0_20px_50px_rgba(59,130,246,0.3)] active:scale-[0.98] flex items-center justify-center gap-4 relative overflow-hidden ${
                    status === 'PROCESSING' || !amountFrom || Number(amountFrom) <= 0 || Number(amountFrom) > (fromWallet?.balance || 0)
                    ? 'bg-slate-800 text-slate-600 grayscale cursor-not-allowed border border-white/5 shadow-none'
                    : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white'
                }`}
            >
              {status === 'PROCESSING' ? <Loader2 className="w-10 h-10 animate-spin" /> : (
                  <>
                    <RefreshCcw className="w-8 h-8" />
                    {Number(amountFrom) > (fromWallet?.balance || 0) ? 'رصيد غير كافٍ للصرف' : 'تأكيد التحويل الفوري'}
                  </>
              )}
            </button>
            
            <div className="bg-emerald-500/5 p-6 rounded-3xl border border-emerald-500/10 flex items-start gap-4">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-1" />
                <p className="text-[10px] text-slate-500 leading-relaxed font-bold">
                    عملية التحويل فورية وآمنة. سيتم تحديث أرصدة المحفظتين مباشرة بعد التأكيد.
                </p>
            </div>
            
            <p className="text-center text-[10px] text-slate-700 font-black uppercase tracking-[0.3em]">Horizon Liquidity Protocol | Instant Swap v3.2</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Exchange;
