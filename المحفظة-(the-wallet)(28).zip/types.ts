
import { LucideIcon } from 'lucide-react';

export type UserRole = 'user' | 'admin' | 'super_admin' | 'moderator';

export enum View {
  DASHBOARD = 'DASHBOARD',
  WALLET = 'WALLET',
  PROFILE = 'PROFILE',
  GAMES = 'GAMES',
  COMMUNITY = 'COMMUNITY',
  TOPUP = 'TOPUP',
  WITHDRAWAL = 'WITHDRAWAL',
  TRANSFER = 'TRANSFER',
  EXCHANGE = 'EXCHANGE',
  AI_ADVISOR = 'AI_ADVISOR',
  LIVE_VOICE = 'LIVE_VOICE',
  DEVELOPER = 'DEVELOPER',
  ADMIN = 'ADMIN',
  CUSTOM_PAGE = 'CUSTOM_PAGE'
}

export enum TransactionType {
  DEPOSIT = 'DEPOSIT',
  WITHDRAWAL = 'WITHDRAWAL',
  TRANSFER = 'TRANSFER',
  PURCHASE = 'PURCHASE',
  EXCHANGE = 'EXCHANGE',
  BET_WIN = 'BET_WIN',
  AREND_WIN = 'AREND_WIN',
  AREND_COMPENSATION = 'AREND_COMPENSATION',
  AREND_BET = 'AREND_BET'
}

export enum TransactionStatus {
  PENDING = 'PENDING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED'
}

export type Currency = string;

export interface Wallet {
  currency: Currency;
  balance: number;
}

export interface UserNotification {
  id: string;
  title: string;
  message: string;
  date: string;
  isRead: boolean;
  type: 'success' | 'error' | 'info';
}

export interface ApiKey {
  id: string;
  name: string;
  key: string;
  prefix: string;
  createdAt: string;
  status: 'active' | 'revoked';
  permissions: string[];
}

export interface WebHook {
  id: string;
  url: string;
  events: string[];
  isActive: boolean;
  secret: string;
  createdAt: string;
}

export interface DevEvent {
  id: string;
  type: string;
  target: string;
  details: string;
  status: 'success' | 'failure';
  timestamp: number;
}

export interface User {
  id: string;
  userCode: string;
  name: string;
  email: string;
  password?: string;
  phone?: string;
  avatar?: string;
  role: UserRole;
  status: 'active' | 'suspended';
  wallets: Wallet[];
  joinDate: string;
  notifications: UserNotification[];
  apiKeys: ApiKey[];
  webhooks: WebHook[];
  devEvents: DevEvent[];
  level: number;
  xp: number;
  winRate?: number;
}

export interface Transaction {
  id: string;
  type: TransactionType | string;
  amount: number;
  currency: Currency;
  date: string;
  description: string;
  status: TransactionStatus;
  userId: string;
  userName: string;
  proofImage?: string;
  gatewayId?: string;
  adminNote?: string;
  adminProofImage?: string;
}

export interface CurrencyConfig {
  code: string;
  name: string;
  symbol: string;
  rateToUSD: number;
  isActive: boolean;
  isBase: boolean;
  buyMargin: number;
  sellMargin: number;
  depositFee: number;
  withdrawalFee: number;
  transferFee: number;
  minTransaction: number;
  maxTransaction: number;
}

export interface Category {
  id: string;
  name: string;
  icon?: string;
  image?: string;
  description?: string;
  parentCategoryId?: string;
  order: number;
  isActive: boolean;
}

export interface ProductInput {
  id: string;
  label: string;
  type: 'text' | 'number';
  required: boolean;
  placeholder?: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  offerPrice?: number;
  categoryId: string;
  images: string[];
  isActive: boolean;
  stock: number;
  type: 'DIGITAL' | 'PHYSICAL';
  deliveryType: 'MANUAL' | 'AUTO';
  inputFields: ProductInput[];
  quantityForPrice?: number;
  shortDescription?: string;
  isHidden?: boolean;
  minQuantity?: number;
  stepAmount?: number;
}

export interface PriceTier {
  minQty: number;
  price: number;
}

export interface Banner {
  id: string;
  title: string;
  imageUrl: string;
  videoUrl?: string;
  isActive: boolean;
  order: number;
}

export interface ExternalStore {
  id: string;
  name: string;
  platform: 'Shopify' | 'WooCommerce' | 'Magento' | 'Custom';
  apiUrl: string;
  apiKey: string;
  isActive: boolean;
}

export interface EnvVar {
  key: string;
  value: string;
  isSecret: boolean;
}

export interface HostingConfig {
  provider: 'VERCEL' | 'NETLIFY' | 'HOSTINGER' | 'CUSTOM';
  repoUrl: string;
  branch: string;
  autoDeploy: boolean;
  lastDeployStatus: 'SUCCESS' | 'FAILED' | 'BUILDING' | 'IDLE';
  lastDeployTime: string;
  envVars: EnvVar[];
}

export interface StoreSettings {
  siteName: string;
  siteDescription?: string;
  supportEmail: string;
  logoUrl?: string;
  maintenanceMode: boolean;
  allowRegistrations: boolean;
  autoUpdateRates: boolean;
  transferFeePercentage: number;
  manualTopUpFeePercentage: number;
  withdrawalFeePercentage: number;
  lowBalanceThreshold: number;
  maxTransactionLimit?: number;
  exchangeRateApiKey?: string;
  externalStores: ExternalStore[];
  hostingConfig: HostingConfig;
}

export interface BankDetails {
  bankName: string;
  accountHolder: string;
  accountNumber: string;
  iban: string;
  swiftCode?: string;
}

export interface ManualGateway {
  id: string;
  name: string;
  image: string;
  instructions: string;
  isActive: boolean;
  order: number;
  supportedCurrencies?: string[];
  bankDetails?: BankDetails;
}

export interface CustomPage {
  id: string;
  title: string;
  content: string;
  isActive: boolean;
  showInSidebar: boolean;
  icon?: string;
  lastUpdated: string;
}

export interface GameConfig {
  isActive: boolean; 
  houseEdge: number; 
  maxBet: number;
  multipliers: any;
  soundEnabled: boolean;
  winnerPercentage: number;
}

export interface GameDefinition {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  type: 'INTERNAL' | 'EMBEDDED' | 'EXTERNAL_LINK';
  url?: string; // For embedded or external games
  provider?: string;
  isActive: boolean;
  isHot?: boolean;
}

export interface TransferTypeConfig {
  id: string;
  label: string;
  icon: any; // Lucide icon or string
  description: string;
  isActive: boolean;
  order: number;
  formType: 'INTERNAL' | 'SYRIAN' | 'INTERNATIONAL';
}

export interface AuditLog {
  id: string;
  action: string;
  details: string;
  adminName: string;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface ChatRoom {
  id: string;
  name: string;
  type: 'VOICE' | 'TEXT';
  participants: string[];
  activeSpeakers?: string[];
  icon?: any;
}
