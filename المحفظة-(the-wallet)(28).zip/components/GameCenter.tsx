
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { User, GameConfig, View, GameDefinition } from '../types';
import { 
  Gamepad2, Trophy, History, AlertCircle, Shield, 
  Volume2, VolumeX, Zap, Star, Flame, Crown, Timer, Target, Coins, Lock, AlertTriangle,
  ArrowUp, Sparkles, X, Plus, ChevronUp, ChevronDown, ShieldCheck, Info, Activity,
  TrendingUp, MousePointer2, Layers, BarChart, Check, Swords, RefreshCw, Gem, Shirt, ArrowRight, PlayCircle
} from 'lucide-react';
import { useLanguage } from '../i18n';
import ArenDGame from './ArenDGame';

interface GameCenterProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
  gameConfig: GameConfig;
  onNavigate: (view: View) => void;
  onAddTransaction: (tx: any) => void;
  games?: GameDefinition[];
}

// Updated Bet Types for Football Groups
type BetGroup = 'SPANISH' | 'ENGLISH' | 'GERMAN' | 'ITALIAN';
type GameState = 'WAITING' | 'SPINNING' | 'RESULT';

interface GameResult {
  id: string;
  teamId: string;
  group: BetGroup;
  timestamp: number;
  hash: string;
  serverSeed: string;
}

interface FloatingEffect {
  id: number;
  x: number;
  y: number;
  color: string;
  text: string;
}

interface FootballClub {
  id: string;
  name: string;
  shortName: string;
  color: string;
  secondaryColor: string;
  group: BetGroup;
  icon: string; // Using emojis or simple text for reliability, can be replaced with URLs
}

const CLUBS: FootballClub[] = [
  { id: 'RM', name: 'Real Madrid', shortName: 'R.MAD', color: '#fff', secondaryColor: '#FEBE10', group: 'SPANISH', icon: '👑' },
  { id: 'BAR', name: 'Barcelona', shortName: 'BARCA', color: '#A50044', secondaryColor: '#004D98', group: 'SPANISH', icon: '🔵🔴' },
  { id: 'MCI', name: 'Man City', shortName: 'CITY', color: '#6CABDD', secondaryColor: '#1C2C5B', group: 'ENGLISH', icon: '⚓' },
  { id: 'LIV', name: 'Liverpool', shortName: 'LIV', color: '#C8102E', secondaryColor: '#00B2A9', group: 'ENGLISH', icon: '🦅' },
  { id: 'BAY', name: 'Bayern', shortName: 'BAYERN', color: '#DC052D', secondaryColor: '#0066B2', group: 'GERMAN', icon: '🔴' },
  { id: 'DOR', name: 'Dortmund', shortName: 'BVB', color: '#FDE100', secondaryColor: '#000', group: 'GERMAN', icon: '🐝' },
  { id: 'JUV', name: 'Juventus', shortName: 'JUVE', color: '#000', secondaryColor: '#fff', group: 'ITALIAN', icon: '🦓' },
  { id: 'INT', name: 'Inter Milan', shortName: 'INTER', color: '#010E80', secondaryColor: '#000', group: 'ITALIAN', icon: '🔵⚫' },
];

const SOUNDS = {
  TICK: 'https://assets.mixkit.co/active_storage/sfx/2578/2578-preview.mp3',
  SPIN: 'https://assets.mixkit.co/active_storage/sfx/2003/2003-preview.mp3',
  WIN: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3',
  LOSE: 'https://assets.mixkit.co/active_storage/sfx/2030/2030-preview.mp3',
  BET: 'https://assets.mixkit.co/active_storage/sfx/2573/2573-preview.mp3',
};

const GameCenter: React.FC<GameCenterProps> = ({ user, onUpdateUser, gameConfig, onNavigate, onAddTransaction, games = [] }) => {
  const { t, language } = useLanguage();
  const [activeGameId, setActiveGameId] = useState<string | null>(null);
  const [gameState, setGameState] = useState<GameState>('WAITING');
  const [countdown, setCountdown] = useState(15);
  const [betAmount, setBetAmount] = useState<string>('10');
  const [activeBets, setActiveBets] = useState<{group: BetGroup, amount: number}[]>([]);
  const [wheelRotation, setWheelRotation] = useState(0);
  const [gameHistory, setGameHistory] = useState<GameResult[]>([]);
  const [lastWin, setLastWin] = useState<number>(0);
  const [isMuted, setIsMuted] = useState(!gameConfig.soundEnabled);
  const [shake, setShake] = useState(false);
  const [showFairnessInfo, setShowFairnessInfo] = useState(false);
  
  const [floatingChips, setFloatingChips] = useState<FloatingEffect[]>([]);
  const [sessionStats, setSessionStats] = useState({ wins: 0, losses: 0, totalWagered: 0 });
  const audioRefs = useRef<{[key: string]: HTMLAudioElement}>({});

  const currentWallet = user.wallets.find(w => w.currency === 'USD');
  const balance = currentWallet?.balance || 0;

  const totalPool = useMemo(() => activeBets.reduce((acc, b) => acc + b.amount, 0), [activeBets]);

  useEffect(() => {
    Object.entries(SOUNDS).forEach(([key, url]) => {
      const audio = new Audio(url);
      audio.volume = 0.3;
      audioRefs.current[key] = audio;
    });
  }, []);

  const playSound = (key: string) => {
    if (!isMuted && audioRefs.current[key]) {
      const audio = audioRefs.current[key];
      audio.currentTime = 0;
      audio.play().catch(() => {}); 
    }
  };

  useEffect(() => {
    if (!gameConfig.isActive || activeGameId !== 'SPIN') return;
    let timer: ReturnType<typeof setTimeout>;
    if (gameState === 'WAITING') {
      if (countdown > 0) {
        timer = setTimeout(() => {
            setCountdown(prev => prev - 0.1);
            if (Math.floor(countdown) !== Math.floor(countdown - 0.1) && countdown <= 3) playSound('TICK');
        }, 100);
      } else {
        spinWheel();
      }
    } else if (gameState === 'RESULT') {
        timer = setTimeout(() => {
            setGameState('WAITING');
            setCountdown(15);
            setActiveBets([]);
            setLastWin(0);
            setShake(false);
        }, 4000); 
    }
    return () => clearTimeout(timer);
  }, [gameState, countdown, gameConfig.isActive, activeGameId]);

  const spinWheel = () => {
    setGameState('SPINNING');
    playSound('SPIN');

    // 8 Segments logic
    const resultIndex = Math.floor(Math.random() * 8); 
    const winningClub = CLUBS[resultIndex];
    
    const segmentAngle = 360 / 8;
    // Add extra rotations + target angle
    const randomOffset = Math.random() * 30 - 15; // Randomness within segment
    const targetRot = (360 * 8) + (360 - (resultIndex * segmentAngle)) - (segmentAngle / 2) + randomOffset; 
    
    setWheelRotation(prev => prev + targetRot);
    
    setTimeout(() => { 
        handleGameResult(winningClub); 
    }, 5000); 
  };

  const handleGameResult = (club: FootballClub) => {
    setGameState('RESULT');
    setShake(true); 
    
    const serverSeed = Math.random().toString(36).substring(2, 15);
    const hash = btoa(serverSeed + club.id).substring(0, 24);
    
    const newResult: GameResult = {
        id: `rnd_${Date.now()}`,
        teamId: club.id,
        group: club.group,
        timestamp: Date.now(),
        hash,
        serverSeed
    };

    setGameHistory(prev => [newResult, ...prev].slice(0, 10));
    
    let totalWin = 0;
    let totalBet = 0;
    activeBets.forEach(bet => {
        totalBet += bet.amount;
        if (bet.group === club.group) {
            const multiplier = 3; // Fixed 3x multiplier as requested
            totalWin += bet.amount * multiplier;
        }
    });

    setSessionStats(prev => ({ 
        wins: totalWin > 0 ? prev.wins + 1 : prev.wins, 
        losses: (totalWin === 0 && totalBet > 0) ? prev.losses + 1 : prev.losses, 
        totalWagered: prev.totalWagered + totalBet 
    }));

    if (totalWin > 0) {
        setLastWin(totalWin);
        playSound('WIN');
        const updatedWallets = user.wallets.map(w => w.currency === 'USD' ? { ...w, balance: w.balance + totalWin } : w);
        onUpdateUser({ ...user, wallets: updatedWallets });
        onAddTransaction({
            id: `spin_w_${Date.now()}`,
            type: 'BET_WIN',
            amount: totalWin,
            currency: 'USD',
            description: `فوز في Club Spin (${club.name})`,
            status: 'COMPLETED',
            date: new Date().toISOString()
        });
    } else if (totalBet > 0) {
        playSound('LOSE');
    }
  };

  const placeBet = (group: BetGroup, e: React.MouseEvent) => {
    if (!gameConfig.isActive || gameState !== 'WAITING') return;
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount <= 0) return; 
    if (amount > gameConfig.maxBet) return;
    if (amount > balance) return;

    playSound('BET');
    const rect = e.currentTarget.getBoundingClientRect();
    const newFloatingChip = { 
        id: Date.now(), 
        x: rect.left + rect.width / 2, 
        y: rect.top, 
        color: '#10b981',
        text: `-$${amount}` 
    };
    setFloatingChips(prev => [...prev, newFloatingChip]);
    setTimeout(() => setFloatingChips(prev => prev.filter(c => c.id !== newFloatingChip.id)), 800);

    const updatedWallets = user.wallets.map(w => w.currency === 'USD' ? { ...w, balance: w.balance - amount } : w);
    onUpdateUser({ ...user, wallets: updatedWallets });
    setActiveBets(prev => [...prev, { group, amount }]);
  };

  // Conic gradient for 8 segments
  const wheelGradient = `conic-gradient(
    #ffffff 0deg 45deg,
    #0f172a 45deg 90deg,
    #ffffff 90deg 135deg,
    #0f172a 135deg 180deg,
    #ffffff 180deg 225deg,
    #0f172a 225deg 270deg,
    #ffffff 270deg 315deg,
    #0f172a 315deg 360deg
  )`; 

  const getGroupColor = (group: BetGroup) => {
      switch(group) {
          case 'SPANISH': return 'from-amber-500 to-red-600';
          case 'ENGLISH': return 'from-blue-400 to-indigo-600';
          case 'GERMAN': return 'from-red-600 to-black';
          case 'ITALIAN': return 'from-emerald-500 to-green-800';
          default: return 'from-slate-700 to-slate-900';
      }
  };

  const getGroupLabel = (group: BetGroup) => {
      switch(group) {
          case 'SPANISH': return 'الدوري الإسباني';
          case 'ENGLISH': return 'الدوري الإنجليزي';
          case 'GERMAN': return 'الدوري الألماني';
          case 'ITALIAN': return 'الدوري الإيطالي';
      }
  };

  const handleLaunchGame = (game: GameDefinition) => {
      if (game.type === 'EXTERNAL_LINK' && game.url) {
          window.open(game.url, '_blank');
      } else if (game.type === 'EMBEDDED' && game.url) {
          setActiveGameId(game.id);
      } else if (game.type === 'INTERNAL') {
          setActiveGameId(game.id);
      }
  };

  // LOBBY VIEW
  if (!activeGameId) {
      return (
          <div className="max-w-7xl mx-auto space-y-10 animate-in fade-in pb-32">
              <div className="flex justify-between items-end">
                  <div>
                      <h1 className="text-4xl font-black text-white flex items-center gap-3">
                          <Gamepad2 className="w-10 h-10 text-purple-500" />
                          مركز الألعاب
                      </h1>
                      <p className="text-slate-500 font-bold mt-2 text-lg">اربح جوائز نقدية فورية واستمتع بأفضل الألعاب التنافسية</p>
                  </div>
                  <div className="bg-slate-900/50 px-6 py-3 rounded-2xl border border-white/5 flex items-center gap-3">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_#10b981]"></div>
                      <span className="text-emerald-400 font-black text-xs uppercase tracking-widest">{games.filter(g => g.isActive).length} ألعاب نشطة</span>
                  </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {games.filter(g => g.isActive).map(game => (
                      <div key={game.id} className="glass-card rounded-[2.5rem] overflow-hidden border border-white/5 group hover:border-purple-500/30 transition-all duration-500 relative bg-[#0a0514]">
                          <div className="h-56 relative overflow-hidden">
                              {game.imageUrl ? <img src={game.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" /> : <div className="w-full h-full bg-slate-800 flex items-center justify-center text-4xl">🎮</div>}
                              <div className="absolute inset-0 bg-gradient-to-t from-[#0a0514] to-transparent"></div>
                              {game.isHot && <div className="absolute top-4 right-4 bg-rose-600 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-lg flex items-center gap-1"><Flame size={12}/> HOT</div>}
                          </div>
                          <div className="p-8 relative -mt-10">
                              <h3 className="text-2xl font-black text-white mb-2">{game.name}</h3>
                              <p className="text-slate-400 text-sm font-medium line-clamp-2 h-10 mb-6">{game.description}</p>
                              
                              <button 
                                onClick={() => handleLaunchGame(game)}
                                className="w-full py-4 bg-white/5 hover:bg-purple-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest transition-all group/btn flex items-center justify-center gap-3 border border-white/10 hover:border-purple-500"
                              >
                                  {game.type === 'EXTERNAL_LINK' ? 'فتح الرابط' : 'لعب الآن'} <ArrowRight size={16} className="rtl:rotate-180 group-hover/btn:-translate-x-1 transition-transform"/>
                              </button>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      );
  }

  // INTERNAL: AREND
  if (activeGameId === 'AREND') {
      return (
        <div className="relative">
            <button onClick={() => setActiveGameId(null)} className="absolute top-0 left-0 z-50 p-3 bg-slate-800/50 text-white rounded-full hover:bg-slate-700 transition-all backdrop-blur-md border border-white/10"><ArrowRight className="rtl:rotate-180"/></button>
            <ArenDGame user={user} onUpdateUser={onUpdateUser} onAddTransaction={onAddTransaction} onNavigate={onNavigate} gameConfig={gameConfig} />
        </div>
      );
  }

  // EMBEDDED IFRAME
  const embeddedGame = games.find(g => g.id === activeGameId && g.type === 'EMBEDDED');
  if (embeddedGame) {
      return (
          <div className="h-[80vh] w-full glass-card rounded-[2rem] overflow-hidden border border-white/10 relative flex flex-col">
              <div className="p-4 bg-black/40 flex justify-between items-center border-b border-white/5">
                  <button onClick={() => setActiveGameId(null)} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors font-bold text-xs uppercase tracking-widest"><ArrowRight size={16} className="rtl:rotate-180"/> العودة</button>
                  <h3 className="text-white font-black">{embeddedGame.name}</h3>
              </div>
              <iframe src={embeddedGame.url} className="flex-1 w-full h-full border-none bg-black" title={embeddedGame.name} allow="autoplay; fullscreen"></iframe>
          </div>
      )
  }

  // INTERNAL: SPIN (Legacy Code Wrapped)
  return (
    <div className={`max-w-7xl mx-auto space-y-10 animate-in fade-in pb-32 relative ${shake ? 'animate-shake' : ''}`}>
      
      {/* Back Button for internal games */}
      <button onClick={() => setActiveGameId(null)} className="absolute top-0 left-0 z-50 p-3 bg-slate-800/50 text-white rounded-full hover:bg-slate-700 transition-all backdrop-blur-md border border-white/10"><ArrowRight className="rtl:rotate-180"/></button>

        <>
            {/* Floating Chips Layer */}
            <div className="fixed inset-0 pointer-events-none z-[300]">
                {floatingChips.map(chip => (
                    <div key={chip.id} className="absolute animate-chip-jump flex flex-col items-center gap-1" style={{ left: chip.x, top: chip.y }}>
                        <div className="w-12 h-12 rounded-full border-4 border-white/20 shadow-2xl flex items-center justify-center" style={{ backgroundColor: chip.color }}>
                            <Coins size={20} className="text-white" />
                        </div>
                        <span className="text-[10px] font-black text-white bg-black/80 px-3 py-1 rounded-full border border-white/10">{chip.text}</span>
                    </div>
                ))}
            </div>

            {/* Header with Emerald Glassmorphism */}
            <div className="flex flex-col md:flex-row gap-8 justify-between items-center bg-[#020617]/60 p-6 rounded-[2.5rem] border border-emerald-500/20 backdrop-blur-xl shadow-[0_0_40px_rgba(16,185,129,0.1)] relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px]"></div>
                
                <div className="flex items-center gap-5 relative z-10">
                    <div className="w-16 h-16 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-[1.5rem] flex items-center justify-center shadow-2xl shadow-emerald-500/40 transform -rotate-6 group">
                        <Trophy className="w-8 h-8 text-white group-hover:scale-110 transition-transform animate-pulse" />
                    </div>
                    <div className="text-right">
                        <h1 className="text-3xl font-black text-white tracking-tighter drop-shadow-md">Horizon <span className="text-emerald-400">Club Spin</span></h1>
                        <div className="flex items-center gap-2 mt-1">
                            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_10px_#34d399]"></span>
                            <p className="text-emerald-500/80 text-[10px] font-black uppercase tracking-widest">Football Edition 3x</p>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-4 relative z-10">
                    <div className="bg-black/60 px-6 py-3 rounded-2xl border border-emerald-500/30 flex flex-col items-end shadow-[inset_0_0_20px_rgba(16,185,129,0.1)]">
                        <span className="text-[9px] text-emerald-500 font-black uppercase tracking-widest leading-none mb-1">محفظتك (USD)</span>
                        <span className="text-xl font-mono font-black text-white tracking-tighter drop-shadow-md">$ {balance.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
                    </div>
                    <button onClick={() => setShowFairnessInfo(true)} className="p-4 bg-emerald-500/10 hover:bg-emerald-500 text-emerald-500 hover:text-white rounded-2xl border border-emerald-500/20 transition-all active:scale-90 shadow-lg"><ShieldCheck size={20}/></button>
                    <button onClick={() => setIsMuted(!isMuted)} className={`p-4 rounded-2xl transition-all border ${isMuted ? 'bg-rose-500/10 text-rose-500 border-rose-500/20' : 'bg-white/5 text-slate-400 border-white/5'}`}>
                        {isMuted ? <VolumeX size={20}/> : <Volume2 size={20}/>}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                
                {/* Wheel Area */}
                <div className="lg:col-span-7 flex flex-col items-center">
                    <div className="w-full glass-card rounded-[4rem] p-12 border border-emerald-500/20 relative bg-[#020617]/80 shadow-[0_0_100px_rgba(16,185,129,0.15)] overflow-hidden flex flex-col items-center group">
                        
                        {/* Atmospheric Glows */}
                        <div className={`absolute -top-40 -right-40 w-96 h-96 rounded-full blur-[120px] transition-all duration-[2000ms] ${gameState === 'SPINNING' ? 'bg-emerald-500/30 scale-125' : 'bg-emerald-600/10'}`}></div>
                        
                        {/* High-Tech Pointer */}
                        <div className="relative z-[50] mb-[-12px]">
                            <div className="w-12 h-14 bg-gradient-to-b from-emerald-100 to-emerald-400 shadow-[0_0_30px_#34d399] clip-polygon" style={{clipPath: 'polygon(0% 0%, 100% 0%, 50% 100%)'}}>
                                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-white border-2 border-emerald-500"></div>
                            </div>
                        </div>

                        {/* 3D Wheel Structure (8 Segments) */}
                        <div className="relative w-full max-w-[450px] aspect-square group perspective-1000">
                            <div className="absolute inset-[-20px] rounded-full border-[2px] border-emerald-500/30 opacity-70 shadow-[0_0_50px_rgba(16,185,129,0.4)]"></div>
                            
                            <div 
                                className="w-full h-full rounded-full border-[12px] border-[#020617] shadow-[0_0_100px_rgba(0,0,0,1),inset_0_0_60px_rgba(0,0,0,0.8)] overflow-hidden relative transition-transform duration-[5500ms] cubic-bezier(0.12, 0, 0.08, 1)" 
                                style={{ transform: `rotate(${wheelRotation}deg)`, background: wheelGradient }}
                            >
                                {CLUBS.map((club, i) => {
                                    const angle = i * (360 / 8);
                                    return (
                                        <div key={club.id} className="absolute inset-0 flex justify-center" style={{ transform: `rotate(${angle}deg)` }}>
                                            {/* Segment Decor */}
                                            <div className="absolute top-0 w-1 h-1/2 bg-black/10 origin-bottom transform translate-y-full"></div>
                                            
                                            {/* Team Display */}
                                            <div className="mt-6 flex flex-col items-center transform" style={{ transform: `rotate(${360/16}deg)` }}> {/* Rotate content slightly to center in slice */}
                                                <div className="w-16 h-16 rounded-full flex items-center justify-center text-4xl shadow-xl border-4 border-white/20" style={{backgroundColor: club.color, borderColor: club.secondaryColor}}>
                                                    <span className="drop-shadow-md">{club.icon}</span>
                                                </div>
                                                <span className={`text-[10px] font-black uppercase mt-1 px-2 py-0.5 rounded-full ${i % 2 === 0 ? 'text-black bg-white/80' : 'text-white bg-black/60'}`}>{club.shortName}</span>
                                            </div>
                                        </div>
                                    );
                                })}

                                {/* Central Hub */}
                                <div className="absolute inset-[30%] rounded-full bg-[#020617] shadow-[inset_0_0_80px_rgba(0,0,0,1),0_0_40px_rgba(16,185,129,0.2)] border-[8px] border-emerald-500/20 z-20 flex items-center justify-center overflow-hidden">
                                    <div className={`absolute inset-0 opacity-40 transition-all duration-[3000ms] ${gameState === 'SPINNING' ? 'bg-gradient-to-tr from-emerald-500/30 to-teal-500/30 rotate-180 scale-150' : ''}`}></div>

                                    <div className="text-center relative z-10">
                                        {gameState === 'WAITING' ? (
                                            <div className="animate-in zoom-in duration-500 flex flex-col items-center">
                                                <Timer size={20} className="text-emerald-400 mb-2 animate-pulse" />
                                                <p className={`text-6xl font-mono font-black ${countdown <= 3 ? 'text-amber-500 animate-heartbeat' : 'text-white'}`}>{Math.ceil(countdown)}</p>
                                            </div>
                                        ) : gameState === 'RESULT' ? (
                                            <div className="animate-pop-in text-center flex flex-col items-center">
                                                <span className="text-5xl drop-shadow-xl">{gameHistory[0]?.teamId && CLUBS.find(c => c.id === gameHistory[0].teamId)?.icon}</span>
                                                <p className={`text-xl font-black mt-2 text-white`}>
                                                    {gameHistory[0]?.teamId}
                                                </p>
                                                <div className={`mt-2 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest shadow-2xl border ${lastWin > 0 ? 'bg-emerald-500 text-black border-emerald-400 animate-glow' : 'bg-slate-800 text-slate-500 border-white/5'}`}>
                                                    {lastWin > 0 ? 'WINNER!' : 'FINISHED'}
                                                </div>
                                            </div>
                                        ) : (
                                            <div className="flex flex-col items-center gap-4">
                                                <Sparkles className="w-12 h-12 text-emerald-400 fill-current animate-spin" />
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Emerald Victory Overlay */}
                        {gameState === 'RESULT' && lastWin > 0 && (
                            <div className="absolute inset-0 z-[100] flex items-center justify-center p-8 bg-black/80 backdrop-blur-xl animate-in fade-in duration-500">
                                <div className="text-center relative max-w-lg w-full">
                                    <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-[120px] animate-pulse"></div>
                                    <Trophy className="w-32 h-32 text-emerald-400 mx-auto mb-8 animate-bounce drop-shadow-[0_0_30px_#34d399]" />
                                    <h2 className="text-white text-lg font-black uppercase tracking-[0.5em] mb-4 drop-shadow-md">CLUB WIN</h2>
                                    <div className="relative inline-block mb-10">
                                        <p className="text-7xl font-mono font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-emerald-200 tracking-tighter drop-shadow-[0_10px_30px_rgba(16,185,129,0.5)]">
                                            <span className="text-emerald-500">$</span>{lastWin.toLocaleString()}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* History */}
                    <div className="w-full mt-8 glass-card p-4 rounded-[2rem] border border-white/5 flex gap-4 overflow-x-auto scrollbar-hide justify-center">
                        {gameHistory.map((h, i) => {
                            const club = CLUBS.find(c => c.id === h.teamId);
                            return (
                                <div key={h.id} className="flex flex-col items-center gap-1 shrink-0">
                                    <div className="w-10 h-10 rounded-full border-2 border-white/10 flex items-center justify-center text-lg bg-slate-800" style={{borderColor: club?.color}}>
                                        {club?.icon}
                                    </div>
                                    <span className="text-[8px] font-black text-slate-500">{club?.shortName}</span>
                                </div>
                            )
                        })}
                    </div>
                </div>

                {/* Right Sidebar - Betting */}
                <div className="lg:col-span-5 space-y-8">
                    
                    {/* Stats */}
                    <div className="glass-card p-6 rounded-[2.5rem] border border-emerald-500/20 bg-gradient-to-br from-[#020617] to-[#064e3b]/20 flex justify-between items-center">
                        <div>
                            <p className="text-[10px] text-emerald-500/70 font-black uppercase tracking-[0.2em]">Session Profit</p>
                            <p className={`text-2xl font-mono font-black ${sessionStats.wins >= sessionStats.losses ? 'text-emerald-400' : 'text-slate-400'}`}>
                                {sessionStats.wins >= sessionStats.losses ? '+' : '-'}$ {(sessionStats.wins * 30).toLocaleString()}
                            </p>
                        </div>
                        <div className="text-right">
                            <p className="text-[10px] text-slate-500 font-black uppercase mb-1">Win Rate</p>
                            <p className="text-xl font-mono font-black text-white">{(sessionStats.wins / (sessionStats.wins+sessionStats.losses || 1) * 100).toFixed(0)}%</p>
                        </div>
                    </div>

                    {/* Betting Cards */}
                    <div className="glass-card rounded-[3rem] border border-white/10 bg-[#020617]/90 shadow-2xl overflow-hidden p-8 space-y-6">
                        <div className="flex items-center gap-3 mb-4">
                            <Shirt size={20} className="text-emerald-500"/>
                            <h4 className="text-white font-black text-sm uppercase tracking-widest">Select Your Team Pair</h4>
                        </div>

                        <div className="grid grid-cols-1 gap-4">
                            {(['SPANISH', 'ENGLISH', 'GERMAN', 'ITALIAN'] as BetGroup[]).map(group => {
                                const groupClubs = CLUBS.filter(c => c.group === group);
                                return (
                                    <button 
                                        key={group}
                                        onClick={(e) => placeBet(group, e)}
                                        disabled={gameState !== 'WAITING'}
                                        className={`w-full relative overflow-hidden rounded-[2rem] p-1 transition-all active:scale-[0.98] group/card ${activeBets.some(b => b.group === group) ? 'ring-2 ring-emerald-500' : ''}`}
                                    >
                                        <div className={`absolute inset-0 bg-gradient-to-r opacity-20 group-hover/card:opacity-30 transition-opacity ${getGroupColor(group)}`}></div>
                                        <div className="relative bg-[#0a0f1e]/90 backdrop-blur-md rounded-[1.8rem] p-4 flex items-center justify-between border border-white/5 h-24">
                                            <div className="flex items-center gap-3">
                                                {groupClubs.map((club, idx) => (
                                                    <div key={club.id} className={`w-12 h-12 rounded-full border-2 flex items-center justify-center text-xl bg-slate-800 shadow-lg ${idx > 0 ? '-ml-6' : 'z-10'}`} style={{borderColor: club.color}}>
                                                        {club.icon}
                                                    </div>
                                                ))}
                                                <div className="text-right mr-2">
                                                    <p className="text-white font-black text-xs uppercase">{getGroupLabel(group)}</p>
                                                    <p className="text-[9px] text-slate-400 font-bold">{groupClubs.map(c => c.shortName).join(' vs ')}</p>
                                                </div>
                                            </div>
                                            <div className="text-center">
                                                <span className="text-emerald-400 font-black text-lg">x3.00</span>
                                                <p className="text-[8px] text-slate-500 uppercase">Payout</p>
                                                {activeBets.filter(b => b.group === group).length > 0 && (
                                                    <div className="absolute top-2 left-2 bg-emerald-500 text-black text-[9px] font-black px-2 py-0.5 rounded-full">
                                                        ${activeBets.filter(b => b.group === group).reduce((s,b) => s+b.amount, 0)}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </button>
                                );
                            })}
                        </div>

                        {/* Bet Amount */}
                        <div className="pt-6 border-t border-white/5 space-y-4">
                            <div className="bg-[#0f172a] p-2 rounded-[2rem] border border-white/5 flex items-center gap-2">
                                <button onClick={() => setBetAmount((parseFloat(betAmount)/2).toString())} className="w-12 h-12 rounded-[1.5rem] bg-slate-800 text-slate-400 hover:text-white font-black text-xs">½</button>
                                <input type="number" value={betAmount} onChange={e => setBetAmount(e.target.value)} className="flex-1 bg-transparent text-center text-2xl font-black text-white outline-none" />
                                <button onClick={() => setBetAmount((parseFloat(betAmount)*2).toString())} className="w-12 h-12 rounded-[1.5rem] bg-slate-800 text-slate-400 hover:text-white font-black text-xs">2x</button>
                            </div>
                            <div className="grid grid-cols-4 gap-2">
                                {[10, 50, 100, 200].map(val => (
                                    <button key={val} onClick={() => setBetAmount(val.toString())} className={`py-3 rounded-xl text-[10px] font-black border ${betAmount === val.toString() ? 'bg-emerald-600 text-white border-emerald-500' : 'bg-white/5 text-slate-500 border-transparent hover:bg-white/10'}`}>
                                        ${val}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>

      {/* Verification Infrastructure Modal */}
      {showFairnessInfo && (
          <div className="fixed inset-0 z-[250] bg-black/98 backdrop-blur-3xl flex items-center justify-center p-8 animate-in fade-in duration-300">
              <div className="glass-card w-full max-w-2xl rounded-[4rem] p-12 md:p-16 border border-emerald-500/30 shadow-[0_0_150px_rgba(16,185,129,0.1)] relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-[120px]"></div>
                  <button onClick={() => setShowFairnessInfo(false)} className="absolute top-10 left-10 p-4 bg-white/5 hover:bg-rose-500 rounded-full text-slate-400 hover:text-white transition-all active:scale-90 shadow-2xl"><X size={24}/></button>
                  
                  <div className="flex items-center gap-6 mb-14">
                      <div className="p-5 bg-emerald-500/10 rounded-[2rem] border border-emerald-500/20 text-emerald-400 shadow-xl shadow-emerald-500/10">
                          <ShieldCheck size={40} />
                      </div>
                      <div className="text-right">
                          <h3 className="text-3xl font-black text-white">نظام التشفير العادل (PFX)</h3>
                          <p className="text-xs text-slate-500 font-bold mt-2 uppercase tracking-widest leading-loose">Algorithmic Integrity Verification Protocol</p>
                      </div>
                  </div>

                  <div className="space-y-10 relative z-10">
                      <div className="bg-slate-900/50 p-10 rounded-[3rem] border border-white/5 space-y-8 shadow-inner">
                          <p className="text-slate-400 text-base leading-relaxed font-medium">
                              يتم تحديد نتيجة كل جولة باستخدام خوارزمية SHA-256 قبل بدء الدوران. يتم تزويد كل جولة بـ (Salt) عشوائي لضمان عدم إمكانية التنبؤ بالنتيجة.
                          </p>
                      </div>
                  </div>

                  <button onClick={() => setShowFairnessInfo(false)} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-6 rounded-[2.5rem] font-black mt-14 transition-all shadow-2xl active:scale-[0.98] glossy-shine text-lg">PROCEED TO GAME</button>
              </div>
          </div>
      )}
    </div>
  );
};

export default GameCenter;
