

import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';

export type Language = 'ar' | 'en';

export interface Translations {
  [key: string]: {
    ar: string;
    en: string;
  };
}

export const translations: Translations = {
  // General
  'app_name': { ar: 'المحفظة', en: 'The Wallet' },
  'welcome': { ar: 'مرحباً بك', en: 'Welcome' },
  'balance': { ar: 'إجمالي الرصيد', en: 'Total Balance' },
  'logout': { ar: 'تسجيل الخروج', en: 'Logout' },
  'logout_confirmation': { ar: 'تأكيد الخروج', en: 'Confirm Logout' },
  'logout_message': { ar: 'هل أنت متأكد من رغبتك في تسجيل الخروج؟', en: 'Are you sure you want to log out?' },
  'menu': { ar: 'القائمة الرئيسية', en: 'Main Menu' },
  'loading': { ar: 'جاري المعالجة...', en: 'Processing...' },
  'success': { ar: 'تمت العملية بنجاح', en: 'Operation Successful' },
  'error': { ar: 'حدث خطأ في النظام', en: 'System Error' },
  'confirm': { ar: 'تأكيد العملية', en: 'Confirm' },
  'cancel': { ar: 'إلغاء', en: 'Cancel' },
  'save': { ar: 'حفظ التغييرات', en: 'Save Changes' },
  'edit': { ar: 'تعديل البيانات', en: 'Edit' },
  'close': { ar: 'إغلاق', en: 'Close' },
  'view_details': { ar: 'تفاصيل العملية', en: 'Transaction Details' },
  'date': { ar: 'تاريخ العملية', en: 'Date' },
  'status': { ar: 'حالة الطلب', en: 'Status' },
  
  // Navigation
  'nav_dashboard': { ar: 'الرئيسية', en: 'Home' },
  'nav_wallet': { ar: 'محافظي', en: 'My Wallets' }, 
  'nav_topup': { ar: 'إضافة رصيد', en: 'Deposit' },
  'nav_withdrawal': { ar: 'سحب أموال', en: 'Withdraw' },
  'nav_transfer': { ar: 'حوالات مالية', en: 'Transfers' },
  'nav_exchange': { ar: 'صرف عملات', en: 'Exchange' },
  'nav_ai': { ar: 'المستشار المالي', en: 'Financial Advisor' },
  'nav_admin': { ar: 'لوحة التحكم', en: 'Admin Panel' },
  'nav_users': { ar: 'إدارة الحسابات', en: 'User Accounts' },
  'nav_games': { ar: 'اكسب واربح', en: 'Play & Earn' },
  'nav_developer': { ar: 'بوابة المطورين', en: 'Developer API' },
  'nav_community': { ar: 'مجتمع العملاء', en: 'Community' },

  // Header & Roles
  'role_super_admin': { ar: 'المدير العام', en: 'Super Admin' },
  'role_admin': { ar: 'مسؤول مالي', en: 'Financial Admin' },
  'role_moderator': { ar: 'مشرف عمليات', en: 'Operations Mod' },
  'role_user': { ar: 'صاحب حساب', en: 'Account Holder' },

  // Wallet Specific
  'current_balance': { ar: 'الرصيد المتاح', en: 'Current Balance' },
  'available_balance': { ar: 'رصيد قابل للتصرف', en: 'Available Balance' },
  'total_wealth': { ar: 'صافي الثروة بالدولار', en: 'Total Net Worth (USD)' },
  'no_activity': { ar: 'لا توجد حركات مالية', en: 'No financial activity' },
  
  // Profile
  'profile_identity': { ar: 'الهوية الرقمية', en: 'Digital Identity' },
  'profile_personal_info': { ar: 'البيانات الشخصية', en: 'Personal Info' },
  'full_name': { ar: 'الاسم الكامل', en: 'Full Name' },
  'email': { ar: 'البريد الإلكتروني', en: 'Email' },
  'phone': { ar: 'رقم الهاتف', en: 'Phone' },
  'join_date': { ar: 'تاريخ الانضمام', en: 'Join Date' },
};

type LanguageContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, params?: Record<string, string | number>) => string;
  dir: 'rtl' | 'ltr';
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('horizon_language');
      return (saved as Language) === 'en' || (saved as Language) === 'ar' ? (saved as Language) : 'ar';
    } catch (e) {
      return 'ar';
    }
  });

  const t = (key: string, params?: Record<string, string | number>) => {
    let text = translations[key]?.[language] || key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(`{${k}}`, String(v));
      });
    }
    return text;
  };

  const dir = language === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = language;
    localStorage.setItem('horizon_language', language);
  }, [dir, language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, dir }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
