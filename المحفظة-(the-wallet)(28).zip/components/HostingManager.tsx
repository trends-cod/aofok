
import React, { useState } from 'react';
import { StoreSettings, HostingConfig, EnvVar } from '../types';
import { 
  Cloud, Rocket, RefreshCw, GitBranch, Github, 
  Terminal, ShieldCheck, Play, Eye, EyeOff, Plus, Trash2, 
  CheckCircle, AlertTriangle, Server, Clock, Activity, Zap, HardDrive, FileCode
} from 'lucide-react';

interface HostingManagerProps {
  settings: StoreSettings;
  onUpdateSettings: (settings: StoreSettings) => void;
}

const HostingManager: React.FC<HostingManagerProps> = ({ settings, onUpdateSettings }) => {
  const [config, setConfig] = useState<HostingConfig>(settings.hostingConfig || {
      provider: 'VERCEL',
      repoUrl: '',
      branch: 'main',
      autoDeploy: true,
      lastDeployStatus: 'IDLE',
      lastDeployTime: new Date().toISOString(),
      envVars: []
  });
  
  const [isDeploying, setIsDeploying] = useState(false);
  const [newEnvKey, setNewEnvKey] = useState('');
  const [newEnvValue, setNewEnvValue] = useState('');
  const [showSecret, setShowSecret] = useState<string | null>(null);

  const updateConfig = (newConfig: Partial<HostingConfig>) => {
      const updated = { ...config, ...newConfig };
      setConfig(updated);
      onUpdateSettings({ ...settings, hostingConfig: updated });
  };

  const handleTriggerDeploy = () => {
      setIsDeploying(true);
      updateConfig({ lastDeployStatus: 'BUILDING' });
      
      // Simulation of build process
      setTimeout(() => {
          setIsDeploying(false);
          updateConfig({ 
              lastDeployStatus: 'SUCCESS', 
              lastDeployTime: new Date().toISOString() 
          });
      }, 4000);
  };

  const addEnvVar = () => {
      if (!newEnvKey || !newEnvValue) return;
      const newVar: EnvVar = {
          key: newEnvKey.toUpperCase().replace(/\s/g, '_'),
          value: newEnvValue,
          isSecret: true
      };
      updateConfig({ envVars: [...config.envVars, newVar] });
      setNewEnvKey('');
      setNewEnvValue('');
  };

  const removeEnvVar = (key: string) => {
      updateConfig({ envVars: config.envVars.filter(e => e.key !== key) });
  };

  const getStatusColor = (status: string) => {
      switch(status) {
          case 'SUCCESS': return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
          case 'FAILED': return 'text-rose-500 bg-rose-500/10 border-rose-500/20';
          case 'BUILDING': return 'text-amber-500 bg-amber-500/10 border-amber-500/20 animate-pulse';
          default: return 'text-slate-500 bg-slate-500/10 border-slate-500/20';
      }
  };

  const renderProviderIcon = (p: string) => {
      switch(p) {
          case 'VERCEL': return <span className="text-3xl">▲</span>;
          case 'NETLIFY': return <span className="text-3xl text-cyan-400">💠</span>;
          case 'HOSTINGER': return <span className="text-3xl text-purple-500">H</span>;
          default: return <Server size={32}/>;
      }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      
      {/* Header & Status - Emerald Theme */}
      <div className="glass-card p-10 rounded-[3rem] border border-white/5 relative overflow-hidden bg-gradient-to-br from-[#020617] via-[#064e3b]/20 to-[#020617]">
          {/* Emerald Glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal-500/5 rounded-full blur-[80px] pointer-events-none"></div>
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 relative z-10">
              <div className="flex items-center gap-6">
                  {/* Icon Container */}
                  <div className="w-24 h-24 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-emerald-900/40 transform -rotate-3 border border-emerald-400/20">
                      <Rocket className="w-10 h-10 text-white drop-shadow-md" />
                  </div>
                  <div>
                      <h2 className="text-3xl font-black text-white tracking-tight">إعدادات النشر والاستضافة</h2>
                      <div className="flex items-center gap-3 mt-3">
                          <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase border flex items-center gap-2 backdrop-blur-md ${getStatusColor(config.lastDeployStatus)}`}>
                              <div className={`w-2 h-2 rounded-full shadow-[0_0_8px_currentColor] ${config.lastDeployStatus === 'BUILDING' ? 'bg-amber-500 animate-ping' : config.lastDeployStatus === 'SUCCESS' ? 'bg-emerald-500' : 'bg-slate-500'}`}></div>
                              {config.lastDeployStatus}
                          </span>
                          <span className="text-emerald-500/60 text-xs font-bold flex items-center gap-1 font-mono">
                              <Clock size={12} /> {new Date(config.lastDeployTime).toLocaleString()}
                          </span>
                      </div>
                  </div>
              </div>

              {config.provider !== 'HOSTINGER' && (
                  <button 
                    onClick={handleTriggerDeploy}
                    disabled={isDeploying}
                    className={`
                        px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest transition-all flex items-center gap-3 shadow-xl relative overflow-hidden group
                        ${isDeploying 
                            ? 'bg-amber-500/10 text-amber-500 cursor-not-allowed border border-amber-500/20' 
                            : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30 active:scale-95 border border-emerald-400/20'}
                    `}
                  >
                      {isDeploying && <div className="absolute inset-0 bg-white/5 animate-pulse"></div>}
                      {isDeploying ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5 fill-current" />}
                      {isDeploying ? 'جاري البناء والنشر...' : 'بدء عملية النشر'}
                  </button>
              )}
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-8">
              
              <div className="glass-card p-10 rounded-[2.5rem] border border-white/5 space-y-8 relative overflow-hidden">
                  <div className="flex items-center gap-4 border-b border-white/5 pb-6 mb-2">
                      <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-500"><Cloud size={24} /></div>
                      <div>
                          <h3 className="text-xl font-black text-white">بيانات المزود</h3>
                          <p className="text-xs text-slate-500 font-bold">Hosting Provider Details</p>
                      </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {['VERCEL', 'NETLIFY', 'HOSTINGER', 'CUSTOM'].map(p => (
                          <button 
                            key={p}
                            onClick={() => updateConfig({ provider: p as any })}
                            className={`
                                p-6 rounded-[2rem] border flex flex-col items-center gap-3 transition-all relative overflow-hidden
                                ${config.provider === p 
                                    ? 'bg-emerald-600/10 border-emerald-500 text-white shadow-[0_0_30px_rgba(16,185,129,0.15)]' 
                                    : 'bg-slate-900/30 border-white/5 text-slate-500 hover:text-slate-300 hover:bg-white/5'}
                            `}
                          >
                              {config.provider === p && <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/20 rounded-full blur-xl -mr-8 -mt-8"></div>}
                              {renderProviderIcon(p)}
                              <span className="text-[10px] font-black uppercase tracking-widest">{p}</span>
                          </button>
                      ))}
                  </div>

                  {config.provider === 'HOSTINGER' ? (
                      <div className="bg-purple-500/10 border border-purple-500/20 rounded-[2rem] p-8 space-y-4">
                          <div className="flex items-center gap-3 text-purple-400">
                              <HardDrive size={24} />
                              <h4 className="font-black text-sm">إعدادات Hostinger اليدوية</h4>
                          </div>
                          <p className="text-xs text-slate-300 font-medium leading-relaxed">
                              للنشر على Hostinger، يجب عليك بناء المشروع يدوياً ثم رفع محتويات مجلد <code className="bg-black/30 px-2 py-1 rounded text-purple-300">dist</code> إلى مجلد <code className="bg-black/30 px-2 py-1 rounded text-purple-300">public_html</code> في لوحة تحكم الاستضافة (hPanel).
                          </p>
                          <div className="flex flex-col gap-2 pt-4">
                              <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                                  <FileCode size={14} className="text-emerald-500" />
                                  <span>تم إضافة ملف <code>.htaccess</code> تلقائياً للمشروع.</span>
                              </div>
                              <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                                  <Terminal size={14} className="text-emerald-500" />
                                  <span>قم بتشغيل الأمر <code>npm run build</code> لإنشاء النسخة النهائية.</span>
                              </div>
                          </div>
                      </div>
                  ) : (
                      <div className="space-y-6">
                          <div className="space-y-2">
                              <label className="text-[10px] text-emerald-500 font-black uppercase tracking-widest px-2">رابط المستودع (Repo URL)</label>
                              <div className="relative group">
                                  <Github className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-600 w-5 h-5 group-focus-within:text-emerald-400 transition-colors" />
                                  <input 
                                    type="text" 
                                    value={config.repoUrl} 
                                    onChange={e => updateConfig({ repoUrl: e.target.value })}
                                    className="w-full bg-[#020617]/60 border border-white/10 rounded-2xl py-5 pr-14 pl-6 text-white font-mono text-xs outline-none focus:border-emerald-500/50 transition-all dir-ltr shadow-inner"
                                    placeholder="https://github.com/username/project"
                                  />
                              </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-6">
                              <div className="space-y-2">
                                  <label className="text-[10px] text-emerald-500 font-black uppercase tracking-widest px-2">الفرع (Branch)</label>
                                  <div className="relative group">
                                      <GitBranch className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-600 w-4 h-4 group-focus-within:text-emerald-400 transition-colors" />
                                      <input 
                                        type="text" 
                                        value={config.branch} 
                                        onChange={e => updateConfig({ branch: e.target.value })}
                                        className="w-full bg-[#020617]/60 border border-white/10 rounded-2xl py-5 pr-14 pl-6 text-white font-mono text-xs outline-none focus:border-emerald-500/50 transition-all dir-ltr shadow-inner"
                                        placeholder="main"
                                      />
                                  </div>
                              </div>
                              <div className="flex items-end pb-1">
                                  <button 
                                    onClick={() => updateConfig({ autoDeploy: !config.autoDeploy })}
                                    className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all border shadow-lg ${config.autoDeploy ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-slate-900/50 text-slate-500 border-white/5'}`}
                                  >
                                      {config.autoDeploy ? 'نشر تلقائي مفعل' : 'نشر يدوي فقط'}
                                  </button>
                              </div>
                          </div>
                      </div>
                  )}
              </div>

              <div className="glass-card p-10 rounded-[2.5rem] border border-white/5 space-y-8 bg-gradient-to-b from-[#0f172a]/50 to-transparent">
                  <div className="flex items-center justify-between border-b border-white/5 pb-6">
                      <div className="flex items-center gap-4">
                          <div className="p-3 bg-teal-500/10 rounded-xl text-teal-500"><Terminal size={24} /></div>
                          <div>
                              <h3 className="text-xl font-black text-white">متغيرات البيئة</h3>
                              <p className="text-xs text-slate-500 font-bold">Environment Variables</p>
                          </div>
                      </div>
                      <span className="bg-teal-500/10 text-teal-400 text-[10px] px-3 py-1 rounded-full font-black border border-teal-500/20">{config.envVars.length} Configured</span>
                  </div>

                  <div className="space-y-3 max-h-64 overflow-y-auto scrollbar-hide pr-2">
                      {config.envVars.map((env, idx) => (
                          <div key={idx} className="flex items-center gap-3 bg-[#020617]/40 p-4 rounded-2xl border border-white/5 group hover:border-emerald-500/30 transition-all hover:bg-[#020617]/60">
                              <div className="flex-1 font-mono text-[10px] text-emerald-400 font-bold truncate dir-ltr">{env.key}</div>
                              <div className="flex-1 font-mono text-[10px] text-slate-400 truncate dir-ltr bg-black/40 p-2 rounded-lg relative border border-white/5">
                                  {env.isSecret && showSecret !== env.key ? '••••••••••••••••' : env.value}
                                  {env.isSecret && (
                                      <button onClick={() => setShowSecret(showSecret === env.key ? null : env.key)} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-600 hover:text-emerald-400 transition-colors">
                                          {showSecret === env.key ? <EyeOff size={12}/> : <Eye size={12}/>}
                                      </button>
                                  )}
                              </div>
                              <button onClick={() => removeEnvVar(env.key)} className="p-2 text-slate-600 hover:text-rose-500 transition-colors bg-white/5 rounded-xl hover:bg-rose-500/10"><Trash2 size={16}/></button>
                          </div>
                      ))}
                  </div>

                  <div className="p-6 bg-slate-900/30 rounded-[2rem] border border-white/5 flex flex-col md:flex-row gap-4">
                      <input 
                        type="text" 
                        placeholder="KEY (e.g. API_KEY)" 
                        value={newEnvKey}
                        onChange={e => setNewEnvKey(e.target.value)}
                        className="flex-1 bg-[#020617] border border-white/10 rounded-2xl p-4 text-white font-mono text-xs outline-none focus:border-teal-500/50 dir-ltr shadow-inner"
                      />
                      <input 
                        type="text" 
                        placeholder="VALUE" 
                        value={newEnvValue}
                        onChange={e => setNewEnvValue(e.target.value)}
                        className="flex-1 bg-[#020617] border border-white/10 rounded-2xl p-4 text-white font-mono text-xs outline-none focus:border-teal-500/50 dir-ltr shadow-inner"
                      />
                      <button onClick={addEnvVar} className="p-4 bg-teal-600 hover:bg-teal-500 text-white rounded-2xl shadow-lg shadow-teal-900/20 active:scale-90 transition-all"><Plus size={20}/></button>
                  </div>
              </div>

          </div>

          {/* Sidebar Info */}
          <div className="space-y-8">
              <div className="glass-card p-8 rounded-[2.5rem] border border-emerald-500/20 bg-emerald-900/5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl"></div>
                  <div className="flex items-center gap-3 mb-6 relative z-10">
                      <Zap className="text-amber-400 fill-amber-400/20" />
                      <h4 className="text-white font-black text-sm">Deployment Tips</h4>
                  </div>
                  <ul className="space-y-4 text-[10px] text-slate-300 font-bold leading-relaxed relative z-10">
                      <li className="flex gap-2">
                          <span className="text-emerald-500">•</span>
                          <span>Ensure <code className="text-emerald-400 bg-emerald-500/10 px-1 rounded border border-emerald-500/20">VITE_SUPABASE_URL</code> is set for DB connection.</span>
                      </li>
                      <li className="flex gap-2">
                          <span className="text-emerald-500">•</span>
                          <span>Set Output Directory to <code className="text-white bg-white/10 px-1 rounded">dist</code>.</span>
                      </li>
                      <li className="flex gap-2">
                          <span className="text-emerald-500">•</span>
                          <span>For Hostinger, use the provided <code className="text-purple-400">.htaccess</code> file.</span>
                      </li>
                  </ul>
              </div>

              <div className="glass-card p-8 rounded-[2.5rem] border border-white/5">
                  <div className="flex items-center gap-3 mb-6">
                      <Activity className="text-blue-500" />
                      <h4 className="text-white font-black text-sm">Live Status Simulation</h4>
                  </div>
                  <div className="space-y-4">
                      {[
                          { label: 'Build Engine', status: 'Online', color: 'emerald' },
                          { label: 'Database', status: 'Connected', color: 'emerald' },
                          { label: 'CDN Cache', status: 'Purged', color: 'indigo' },
                          { label: 'Latency', status: '24ms', color: 'blue' }
                      ].map((s, i) => (
                          <div key={i} className="flex justify-between items-center pb-3 border-b border-white/5 last:border-0">
                              <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">{s.label}</span>
                              <span className={`text-[9px] font-black uppercase text-${s.color}-400 bg-${s.color}-500/10 px-2 py-0.5 rounded-full border border-${s.color}-500/20`}>{s.status}</span>
                          </div>
                      ))}
                  </div>
              </div>
          </div>

      </div>
    </div>
  );
};

export default HostingManager;
