
import { GameConfig, User, Transaction, CurrencyConfig, Category, Product, Banner, StoreSettings, ManualGateway, CustomPage, TransferTypeConfig, GameDefinition } from './types';
import { Send, Flag, Globe, History } from 'lucide-react';

export const APP_VERSION = '1.0.0';

export const MOCK_USERS: User[] = [
  {
    id: 'u_admin',
    userCode: 'ADM-001',
    name: 'المدير العام',
    email: 'super@admin.com',
    password: '123',
    role: 'super_admin',
    status: 'active',
    wallets: [
        { currency: 'USD', balance: 500000 },
        { currency: 'SAR', balance: 1000000 }
    ],
    joinDate: '2023-01-01T00:00:00.000Z',
    notifications: [],
    apiKeys: [],
    webhooks: [],
    devEvents: [],
    level: 50,
    xp: 99000
  },
  {
    id: 'u_user',
    userCode: 'USR-001',
    name: 'مستخدم تجريبي',
    email: 'user@gmail.com',
    password: '123',
    role: 'user',
    status: 'active',
    wallets: [
        { currency: 'USD', balance: 1000 }
    ],
    joinDate: '2024-01-01T00:00:00.000Z',
    notifications: [],
    apiKeys: [],
    webhooks: [],
    devEvents: [],
    level: 5,
    xp: 4200
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_CURRENCIES: CurrencyConfig[] = [
  { 
    code: 'USD', name: 'Dollar', symbol: '$', rateToUSD: 1, isActive: true, isBase: true, 
    buyMargin: 0, sellMargin: 0, depositFee: 0, withdrawalFee: 0, transferFee: 0, minTransaction: 5, maxTransaction: 10000 
  },
  { 
    code: 'EUR', name: 'Euro', symbol: '€', rateToUSD: 0.92, isActive: true, isBase: false, 
    buyMargin: 1, sellMargin: 1, depositFee: 0, withdrawalFee: 1, transferFee: 0.5, minTransaction: 5, maxTransaction: 10000 
  },
  { 
    code: 'SAR', name: 'Saudi Riyal', symbol: 'ر.س', rateToUSD: 3.75, isActive: true, isBase: false, 
    buyMargin: 0.5, sellMargin: 0.5, depositFee: 0, withdrawalFee: 0, transferFee: 0, minTransaction: 20, maxTransaction: 50000 
  },
  { 
    code: 'EGP', name: 'Egyptian Pound', symbol: 'ج.م', rateToUSD: 48.50, isActive: true, isBase: false, 
    buyMargin: 2, sellMargin: 2, depositFee: 0, withdrawalFee: 1, transferFee: 1, minTransaction: 100, maxTransaction: 100000 
  },
  { 
    code: 'TRY', name: 'Turkish Lira', symbol: '₺', rateToUSD: 32.20, isActive: true, isBase: false, 
    buyMargin: 1.5, sellMargin: 1.5, depositFee: 0, withdrawalFee: 1, transferFee: 0.5, minTransaction: 100, maxTransaction: 50000 
  },
  { 
    code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', rateToUSD: 3.67, isActive: true, isBase: false, 
    buyMargin: 0.5, sellMargin: 0.5, depositFee: 0, withdrawalFee: 0, transferFee: 0, minTransaction: 20, maxTransaction: 50000 
  },
  { 
    code: 'GBP', name: 'British Pound', symbol: '£', rateToUSD: 0.79, isActive: true, isBase: false, 
    buyMargin: 1, sellMargin: 1, depositFee: 0, withdrawalFee: 1, transferFee: 0.5, minTransaction: 5, maxTransaction: 10000 
  },
  { 
    code: 'KWD', name: 'Kuwaiti Dinar', symbol: 'د.ك', rateToUSD: 0.31, isActive: true, isBase: false, 
    buyMargin: 0.5, sellMargin: 0.5, depositFee: 0, withdrawalFee: 0, transferFee: 0, minTransaction: 2, maxTransaction: 5000 
  }
];

export const INITIAL_CATEGORIES: Category[] = [];
export const INITIAL_PRODUCTS: Product[] = [];
export const INITIAL_BANNERS: Banner[] = [];

export const INITIAL_MANUAL_GATEWAYS: ManualGateway[] = [
  {
    id: 'gw_bank_transfer',
    name: 'تحويل بنكي',
    image: 'https://cdn-icons-png.flaticon.com/512/2830/2830284.png',
    instructions: 'يرجى تحويل المبلغ المحدد إلى الحساب البنكي الموضح وإرفاق صورة الإيصال لضمان إضافة الرصيد.',
    isActive: true,
    order: 0,
    supportedCurrencies: ['USD', 'EUR', 'SAR', 'EGP', 'TRY', 'AED', 'GBP', 'KWD'],
    bankDetails: {
        bankName: 'البنك المركزي',
        accountHolder: 'مؤسسة أفق للحلول الرقمية',
        accountNumber: '1234567890123456',
        iban: 'SA0510000012345678901234',
        swiftCode: 'NCBKSA'
    }
  },
  {
    id: 'gw_usdt',
    name: 'USDT (TRC20)',
    image: 'https://cryptologos.cc/logos/tether-usdt-logo.png',
    instructions: 'Network: TRC20\nAddress: T9yD14Nj9j7xAB4dbGeiX9h8unkkhxuWwb\n\nيرجى إرسال المبلغ المحدد بالضبط وإرفاق رقم المعاملة (TXID) أو لقطة شاشة.',
    isActive: true,
    order: 1,
    supportedCurrencies: ['USD']
  },
  {
    id: 'gw_instapay',
    name: 'InstaPay',
    image: 'https://play-lh.googleusercontent.com/8Qn9jM9_55x799_6565656565656565656565656',
    instructions: 'Send to username: @horizon_wallet\nReference: UserCode',
    isActive: true,
    order: 2,
    supportedCurrencies: ['EGP']
  }
];

export const INITIAL_PAGES: CustomPage[] = [];

export const INITIAL_SETTINGS: StoreSettings = {
  siteName: 'Horizon Wallet',
  supportEmail: 'support@horizon.com',
  maintenanceMode: false,
  allowRegistrations: true,
  autoUpdateRates: true,
  transferFeePercentage: 1,
  manualTopUpFeePercentage: 0,
  withdrawalFeePercentage: 2,
  lowBalanceThreshold: 5,
  externalStores: [],
  hostingConfig: {
    provider: 'VERCEL',
    repoUrl: 'https://github.com/horizon/wallet',
    branch: 'main',
    autoDeploy: true,
    lastDeployStatus: 'IDLE',
    lastDeployTime: new Date().toISOString(),
    envVars: [
        { key: 'VITE_SUPABASE_URL', value: '', isSecret: false },
        { key: 'VITE_SUPABASE_ANON_KEY', value: '', isSecret: true },
        { key: 'API_KEY', value: '', isSecret: true }
    ]
  }
};

export const INITIAL_GAME_CONFIG: GameConfig = {
  isActive: true,
  houseEdge: 5,
  maxBet: 500,
  multipliers: {},
  soundEnabled: true,
  winnerPercentage: 70
};

export const INITIAL_GAMES: GameDefinition[] = [
  {
    id: 'AREND',
    name: 'ArenD Arena',
    description: 'ساحة المعركة الجماعية. الفائز يحصل على النصيب الأكبر!',
    imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600',
    type: 'INTERNAL',
    isActive: true,
    isHot: true,
    provider: 'Horizon Internal'
  },
  {
    id: 'SPIN',
    name: 'Club Spin',
    description: 'عجلة الحظ للأندية الرياضية. ضاعف رصيدك x3.',
    imageUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&q=80&w=600',
    type: 'INTERNAL',
    isActive: true,
    isHot: true,
    provider: 'Horizon Internal'
  }
];

export const INITIAL_TRANSFER_TYPES: TransferTypeConfig[] = [
    { id: 'INTERNAL', label: 'تحويل داخلي', icon: Send, description: 'تحويل رصيد لمستخدم آخر باستخدام كود المستخدم', isActive: true, order: 1, formType: 'INTERNAL' },
    { id: 'SYRIAN', label: 'حوالة سوريا', icon: Flag, description: 'تسليم ليرة سورية', isActive: true, order: 2, formType: 'SYRIAN' },
    { id: 'INTERNATIONAL', label: 'حوالة دولية', icon: Globe, description: 'ويسترن يونيون / موني جرام', isActive: true, order: 3, formType: 'INTERNATIONAL' },
    { id: 'HISTORY', label: 'سجل الحوالات', icon: History, description: 'تتبع الحالات والطلبات', isActive: true, order: 4, formType: 'INTERNAL' },
];
