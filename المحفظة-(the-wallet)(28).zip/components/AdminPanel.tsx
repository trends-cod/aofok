
import React, { useState, useMemo, useEffect } from 'react';
import { 
  User, ManualGateway, Transaction, TransactionStatus, Product, 
  Category, Banner, StoreSettings, AuditLog, CurrencyConfig, View, TransactionType, UserRole,
  CustomPage, GameConfig, TransferTypeConfig, WebHook, GameDefinition
} from '../types';
import { 
  LayoutDashboard, Users, ShoppingBag, Layers, Search, Plus, Package, Box,
  Edit3, Trash2, CheckCircle, XCircle, DollarSign,
  Activity, Save, X, Landmark, Wallet as WalletIcon, Shield, 
  ArrowLeft, Upload, Clock, History, ArrowRightLeft, CreditCard, Settings,
  Percent, Monitor, Type, ToggleLeft, ToggleRight, Film, Image as ImageIcon, Check, Receipt, Info, RefreshCw,
  ChevronRight, Eye, UserCog, Tag, ShoppingCart, Code, Key, Lock, Mail, Phone, Gamepad2, Trophy, Coins, Globe,
  Cloud, Rocket
} from 'lucide-react';
import FinancialSystem from './FinancialSystem';
import SettingsPanel from './SettingsPanel';
import FeesManager from './FeesManager';
import CurrencyGatewayManager from './CurrencyGatewayManager';
import DeveloperTools from './DeveloperTools';
import HostingManager from './HostingManager';

interface AdminPanelProps {
  currentUser: User;
  gateways: ManualGateway[];
  transactions: Transaction[];
  users: User[];
  products: Product[];
  categories: Category[];
  banners: Banner[];
  settings: StoreSettings;
  auditLogs: AuditLog[];
  currencies: CurrencyConfig[];
  pages?: CustomPage[];
  gameConfig?: GameConfig;
  games?: GameDefinition[];
  transferTypes: TransferTypeConfig[];
  onUpdateTransferType: (t: TransferTypeConfig) => void;
  onAddTransferType: (t: TransferTypeConfig) => void;
  onDeleteTransferType: (id: string) => void;
  onUpdateGateway: (gateway: ManualGateway) => void;
  onAddGateway: (gateway: ManualGateway) => void;
  onDeleteGateway: (id: string) => void;
  onUpdateTransactionStatus: (id: string, status: TransactionStatus, note?: string, adminProof?: string) => void;
  onUpdateUserRole: (id: string, role: UserRole) => void;
  onUpdateUserStatus: (id: string, status: 'active' | 'suspended') => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  onUpdateCategory: (category: Category) => void;
  onDeleteCategory: (id: string) => void;
  onUpdateBanner: (banner: Banner) => void;
  onDeleteBanner: (id: string) => void;
  onUpdateSettings: (settings: StoreSettings) => void;
  onUpdateGameConfig: (config: GameConfig) => void;
  onNavigate: (view: View) => void;
  onAddAuditLog: (action: string, details: string) => void;
  onAddCurrency: (currency: CurrencyConfig) => void;
  onUpdateCurrency: (currency: CurrencyConfig) => void;
  onDeleteCurrency: (code: string) => void;
  onAddPage?: (page: CustomPage) => void;
  onUpdatePage?: (page: CustomPage) => void;
  onDeletePage?: (id: string) => void;
  initialTab: string;
  onSyncExchangeRates: () => Promise<{ success: boolean; message: string }>;
  onAdminUpdateUser: (updatedUser: User) => void;
  onAdminRegisterUser: (newUser: User) => void;
  onBack: () => void;
  // Developer Tools Props
  onCreateApiKey: (name: string, permissions: string[]) => Promise<string>;
  onRevokeApiKey: (id: string) => void;
  onUpdateApiKeyPermissions: (id: string, permissions: string[]) => void;
  onAddWebhook: (webhook: Omit<WebHook, 'id' | 'createdAt' | 'secret'>) => void;
  onToggleWebhook: (id: string) => void;
  onDeleteWebhook: (id: string) => void;
  // Game Props
  onAddGame?: (game: GameDefinition) => void;
  onUpdateGame?: (game: GameDefinition) => void;
  onDeleteGame?: (id: string) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser, gateways, transactions, users, products, categories, 
  settings, currencies, pages = [], gameConfig, games = [], banners,
  transferTypes, onUpdateTransferType, onAddTransferType, onDeleteTransferType,
  onUpdateGateway, onAddGateway, onDeleteGateway,
  onUpdateTransactionStatus, onUpdateUserRole, onUpdateUserStatus,
  onUpdateProduct, onDeleteProduct,
  onUpdateCategory, onDeleteCategory, onUpdateBanner, onDeleteBanner,
  onUpdateSettings, onUpdateGameConfig, onNavigate, onAddAuditLog,
  onAddCurrency, onUpdateCurrency, onDeleteCurrency, 
  onAddPage, onUpdatePage, onDeletePage,
  initialTab, onSyncExchangeRates, onAdminUpdateUser, onAdminRegisterUser,
  onBack,
  onCreateApiKey, onRevokeApiKey, onUpdateApiKeyPermissions, onAddWebhook, onToggleWebhook, onDeleteWebhook,
  onAddGame, onUpdateGame, onDeleteGame
}) => {
  const [activeTab, setActiveTab] = useState(initialTab || 'DASHBOARD');
  const [storeSubTab, setStoreSubTab] = useState<'PRODUCTS' | 'CATEGORIES' | 'BANNERS'>('PRODUCTS');
  
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [adminProof, setAdminProof] = useState<string | null>(null);
  const [userSearch, setUserSearch] = useState('');
  const [selectedUserToManage, setSelectedUserToManage] = useState<User | null>(null);
  const [balanceAdjustAmount, setBalanceAdjustAmount] = useState('');
  
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [managingGatewayCurrency, setManagingGatewayCurrency] = useState<CurrencyConfig | null>(null);
  const [editingGame, setEditingGame] = useState<GameDefinition | null>(null);

  // User Management State
  const [manageUserTab, setManageUserTab] = useState<'PROFILE' | 'WALLET' | 'SECURITY'>('PROFILE');
  const [selectedWalletCurrency, setSelectedWalletCurrency] = useState('USD');
  const [editUserForm, setEditUserForm] = useState({ name: '', email: '', password: '', userCode: '', phone: '' });

  // Game Config State
  const [localGameConfig, setLocalGameConfig] = useState<GameConfig>(gameConfig || {
      isActive: true, houseEdge: 5, maxBet: 100, multipliers: {}, soundEnabled: true, winnerPercentage: 70
  });

  useEffect(() => {
      if (gameConfig) setLocalGameConfig(gameConfig);
  }, [gameConfig]);

  // Filters
  const [remittanceFilterType, setRemittanceFilterType] = useState<'ALL' | 'TRANSFER' | 'WITHDRAWAL' | 'EXCHANGE'>('ALL');
  const [remittanceFilterStatus, setRemittanceFilterStatus] = useState<TransactionStatus | 'ALL'>('PENDING');
  const [depositFilterStatus, setDepositFilterStatus] = useState<TransactionStatus | 'ALL'>('PENDING');
  const [purchaseFilterStatus, setPurchaseFilterStatus] = useState<TransactionStatus | 'ALL'>('PENDING');

  // Derive the active user from the users list to ensure we have the latest state (fix sync issue)
  const activeManagedUser = useMemo(() => {
      return selectedUserToManage ? users.find(u => u.id === selectedUserToManage.id) : null;
  }, [selectedUserToManage, users]);

  // Sync edit form when user is selected
  useEffect(() => {
      if (activeManagedUser) {
          setEditUserForm({
              name: activeManagedUser.name,
              email: activeManagedUser.email,
              password: activeManagedUser.password || '',
              userCode: activeManagedUser.userCode,
              phone: activeManagedUser.phone || ''
          });
      }
  }, [activeManagedUser]);

  const stats = useMemo(() => {
    const completed = transactions.filter(t => t.status === TransactionStatus.COMPLETED);
    const revenue = completed.reduce((acc, t) => acc + (t.type === TransactionType.DEPOSIT ? t.amount : 0), 0);
    return { revenue };
  }, [transactions]);

  const remittanceTransactions = useMemo(() => {
    return transactions.filter(tx => {
      const isRemittance = [TransactionType.TRANSFER, TransactionType.WITHDRAWAL, TransactionType.EXCHANGE].includes(tx.type);
      if (!isRemittance) return false;
      const matchesType = remittanceFilterType === 'ALL' || 
                         (remittanceFilterType === 'TRANSFER' && tx.type === TransactionType.TRANSFER) ||
                         (remittanceFilterType === 'WITHDRAWAL' && tx.type === TransactionType.WITHDRAWAL) ||
                         (remittanceFilterType === 'EXCHANGE' && tx.type === TransactionType.EXCHANGE);
      const matchesStatus = remittanceFilterStatus === 'ALL' || tx.status === remittanceFilterStatus;
      return matchesType && matchesStatus;
    });
  }, [transactions, remittanceFilterType, remittanceFilterStatus]);

  const depositTransactions = useMemo(() => {
    return transactions.filter(tx => {
      const isDeposit = tx.type === TransactionType.DEPOSIT;
      if (!isDeposit) return false;
      return depositFilterStatus === 'ALL' || tx.status === depositFilterStatus;
    });
  }, [transactions, depositFilterStatus]);

  const purchaseTransactions = useMemo(() => {
    return transactions.filter(tx => {
        const isPurchase = tx.type === TransactionType.PURCHASE;
        if (!isPurchase) return false;
        return purchaseFilterStatus === 'ALL' || tx.status === purchaseFilterStatus;
    });
  }, [transactions, purchaseFilterStatus]);

  const filteredUsers = useMemo(() => {
    if (!userSearch) return users;
    const lower = userSearch.toLowerCase();
    return users.filter(u => 
      u.name.toLowerCase().includes(lower) || 
      u.email.toLowerCase().includes(lower) || 
      u.userCode.toLowerCase().includes(lower)
    );
  }, [users, userSearch]);

  const getStatusBadge = (status: TransactionStatus) => {
    switch (status) {
      case TransactionStatus.COMPLETED:
        return <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 rounded-full text-[10px] font-black flex items-center gap-1.5 w-fit"><CheckCircle size={12} /> مكتمل</span>;
      case TransactionStatus.PENDING:
        return <span className="px-3 py-1 bg-amber-500/10 text-amber-500 rounded-full text-[10px] font-black flex items-center gap-1.5 w-fit animate-pulse"><Clock size={12} /> معلق</span>;
      case TransactionStatus.FAILED:
        return <span className="px-3 py-1 bg-rose-500/10 text-rose-500 rounded-full text-[10px] font-black flex items-center gap-1.5 w-fit"><XCircle size={12} /> مرفوض</span>;
      default:
        return <span className="px-3 py-1 bg-slate-500/10 text-slate-500 rounded-full text-[10px] font-black flex items-center gap-1.5 w-fit"><Activity size={12} /> {status}</span>;
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'banner_img' | 'banner_vid' | 'cat_img' | 'prod_img' | 'game_img') => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
        const result = reader.result as string;
        if (type === 'banner_img' && editingBanner) setEditingBanner({...editingBanner, imageUrl: result});
        if (type === 'banner_vid' && editingBanner) setEditingBanner({...editingBanner, videoUrl: result});
        if (type === 'cat_img' && editingCategory) setEditingCategory({...editingCategory, image: result});
        if (type === 'prod_img' && editingProduct) setEditingProduct({...editingProduct, images: [result]});
        if (type === 'game_img' && editingGame) setEditingGame({...editingGame, imageUrl: result});
    };
    reader.readAsDataURL(file);
  };

  // Crucial: Update balance using the active managed user from latest props
  const adjustUserBalance = (amount: number) => {
    if (!activeManagedUser) return;
    let updatedWallets = [...activeManagedUser.wallets];
    const walletIndex = updatedWallets.findIndex(w => w.currency === selectedWalletCurrency);
    if (walletIndex >= 0) {
        updatedWallets[walletIndex] = { 
            ...updatedWallets[walletIndex], 
            balance: Math.max(0, updatedWallets[walletIndex].balance + amount) 
        };
    } else {
        if (amount > 0) updatedWallets.push({ currency: selectedWalletCurrency, balance: amount });
    }
    const updatedUser = { ...activeManagedUser, wallets: updatedWallets };
    onAdminUpdateUser(updatedUser);
    setBalanceAdjustAmount('');
    onAddAuditLog('ADJUST_BALANCE', `Adjusted ${selectedWalletCurrency} balance of ${updatedUser.name} by ${amount}`);
  };

  const handleSaveUserProfile = () => {
      if (!activeManagedUser) return;
      onAdminUpdateUser({
          ...activeManagedUser,
          name: editUserForm.name,
          email: editUserForm.email,
          phone: editUserForm.phone,
          userCode: editUserForm.userCode,
          password: editUserForm.password
      });
      alert('تم تحديث بيانات المستخدم بنجاح');
  };

  const handleAdminProofUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setAdminProof(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const processTransactionDecision = (status: TransactionStatus) => {
    if (!selectedTx) return;
    onUpdateTransactionStatus(selectedTx.id, status, adminNote, adminProof || undefined);
    onAddAuditLog('TRANSACTION_DECISION', `Updated transaction ${selectedTx.id} to ${status}`);
    setSelectedTx(null);
    setAdminNote('');
    setAdminProof(null);
  };

  const toggleProductIdField = () => {
      if (!editingProduct) return;
      const hasId = editingProduct.inputFields.some(f => f.id === 'player_id');
      let newFields = [...editingProduct.inputFields];
      if (hasId) {
          newFields = newFields.filter(f => f.id !== 'player_id');
      } else {
          newFields.push({ id: 'player_id', label: 'رقم اللاعب / المعرف (ID)', type: 'text', required: true });
      }
      setEditingProduct({ ...editingProduct, inputFields: newFields });
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'HOSTING': return (
        <HostingManager 
          settings={settings}
          onUpdateSettings={onUpdateSettings}
        />
      );
      case 'DEVELOPERS': return (
        <DeveloperTools 
          user={currentUser}
          onCreateApiKey={onCreateApiKey}
          onRevokeApiKey={onRevokeApiKey}
          onUpdateApiKeyPermissions={onUpdateApiKeyPermissions}
          onAddWebhook={onAddWebhook}
          onToggleWebhook={onToggleWebhook}
          onDeleteWebhook={onDeleteWebhook}
        />
      );
      case 'GAME_MGMT': return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* ... Game Mgmt Content ... */}
            <div className="flex justify-between items-center px-4">
                <h3 className="text-2xl font-black text-white flex items-center gap-4">
                    <div className="p-3 bg-purple-500/10 rounded-2xl text-purple-500"><Gamepad2 size={24} /></div>
                    إعدادات الألعاب والمسابقات
                </h3>
            </div>
            
            <div className="glass-card p-10 rounded-[3rem] border border-white/5 space-y-8 relative overflow-hidden">
                 <div className="absolute top-0 left-0 w-full h-1 bg-purple-500"></div>
                 
                 <div className="flex items-center justify-between bg-purple-500/5 p-6 rounded-3xl border border-purple-500/20">
                     <div>
                         <h4 className="text-white font-black text-lg">حالة النظام</h4>
                         <p className="text-slate-400 text-xs">تفعيل أو إيقاف الألعاب لجميع المستخدمين</p>
                     </div>
                     <button 
                        onClick={() => setLocalGameConfig(prev => ({ ...prev, isActive: !prev.isActive }))}
                        className={`text-3xl transition-colors ${localGameConfig.isActive ? 'text-emerald-500' : 'text-slate-600'}`}
                     >
                        {localGameConfig.isActive ? <ToggleRight className="w-12 h-12" /> : <ToggleLeft className="w-12 h-12" />}
                     </button>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                     <div className="space-y-3">
                         <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">نسبة فوز المتصدر</label>
                         <div className="relative group">
                             <Trophy className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-500" />
                             <input 
                                type="number" 
                                value={localGameConfig.winnerPercentage}
                                onChange={e => setLocalGameConfig(prev => ({ ...prev, winnerPercentage: Number(e.target.value) }))}
                                className="w-full bg-slate-900 border border-white/10 rounded-2xl py-4 pr-12 pl-4 text-white font-bold outline-none focus:border-purple-500 transition-all text-center text-xl"
                             />
                             <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-black">%</span>
                         </div>
                         <p className="text-[9px] text-slate-500 px-2">النسبة التي يحصل عليها الفائز من الصافي</p>
                     </div>

                     <div className="space-y-3">
                         <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">عمولة المنصة (House Edge)</label>
                         <div className="relative group">
                             <Coins className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-500" />
                             <input 
                                type="number" 
                                value={localGameConfig.houseEdge}
                                onChange={e => setLocalGameConfig(prev => ({ ...prev, houseEdge: Number(e.target.value) }))}
                                className="w-full bg-slate-900 border border-white/10 rounded-2xl py-4 pr-12 pl-4 text-white font-bold outline-none focus:border-purple-500 transition-all text-center text-xl"
                             />
                             <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-black">%</span>
                         </div>
                         <p className="text-[9px] text-slate-500 px-2">النسبة المقتطعة من إجمالي الرهانات</p>
                     </div>

                     <div className="space-y-3">
                         <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الحد الأقصى للرهان</label>
                         <div className="relative group">
                             <DollarSign className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-500" />
                             <input 
                                type="number" 
                                value={localGameConfig.maxBet}
                                onChange={e => setLocalGameConfig(prev => ({ ...prev, maxBet: Number(e.target.value) }))}
                                className="w-full bg-slate-900 border border-white/10 rounded-2xl py-4 pr-12 pl-4 text-white font-bold outline-none focus:border-purple-500 transition-all text-center text-xl"
                             />
                         </div>
                         <p className="text-[9px] text-slate-500 px-2">أعلى قيمة يمكن للمستخدم المراهنة بها</p>
                     </div>
                 </div>

                 <button 
                    onClick={() => { onUpdateGameConfig(localGameConfig); alert('تم حفظ إعدادات الألعاب بنجاح'); }}
                    className="w-full bg-purple-600 hover:bg-purple-500 text-white py-5 rounded-2xl font-black text-lg shadow-xl shadow-purple-900/30 transition-all active:scale-95 flex items-center justify-center gap-3"
                 >
                    <Save size={20} /> حفظ الإعدادات العامة
                 </button>
            </div>
        </div>
      );
      case 'STORE_MGMT': return (
        <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6 px-4">
              <div className="text-right">
                  <h3 className="text-2xl font-black text-white flex items-center gap-4">
                    <div className="p-3 bg-emerald-500/10 rounded-2xl text-emerald-500"><ShoppingBag size={24} /></div>
                    إدارة محتوى المتجر
                  </h3>
                  <p className="text-slate-500 text-xs mt-1">إدارة المنتجات الرقمية، التصنيفات، والإعلانات</p>
              </div>
              <div className="flex bg-slate-900/50 p-1.5 rounded-2xl border border-white/5">
                {[
                  { id: 'PRODUCTS', label: 'المنتجات', icon: Package },
                  { id: 'CATEGORIES', label: 'الأقسام', icon: Layers },
                  { id: 'BANNERS', label: 'البنرات', icon: Monitor }
                ].map(t => (
                  <button 
                    key={t.id} 
                    onClick={() => setStoreSubTab(t.id as any)}
                    className={`px-6 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${storeSubTab === t.id ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
                  >
                    <t.icon size={14} /> {t.label}
                  </button>
                ))}
              </div>
          </div>
          
          {storeSubTab === 'BANNERS' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center px-4">
                    <p className="text-slate-500 text-xs font-bold">البنرات تظهر في واجهة المستخدم الرئيسية</p>
                    <button onClick={() => setEditingBanner({ id: `b_${Date.now()}`, title: '', imageUrl: '', isActive: true, order: banners.length + 1 })} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl font-black text-[10px] uppercase shadow-lg transition-all active:scale-95"><Plus size={14}/> إضافة إعلان جديد</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {banners.map(b => (
                        <div key={b.id} className="glass-card rounded-[2.5rem] border border-white/5 overflow-hidden group hover:border-white/20 transition-all flex flex-col h-full bg-[#030712]/40">
                            <div className="h-44 relative bg-black/40">
                                {b.videoUrl ? (
                                    <video src={b.videoUrl} autoPlay muted loop className="w-full h-full object-cover opacity-60" />
                                ) : (
                                    <img src={b.imageUrl} className="w-full h-full object-cover" />
                                )}
                                <div className="absolute top-4 right-4 flex gap-2">
                                    <button onClick={() => setEditingBanner(b)} className="p-2 bg-black/60 backdrop-blur-md rounded-xl text-white hover:bg-emerald-600 transition-all"><Edit3 size={14}/></button>
                                    <button onClick={() => onDeleteBanner(b.id)} className="p-2 bg-black/60 backdrop-blur-md rounded-xl text-white hover:bg-rose-600 transition-all"><Trash2 size={14}/></button>
                                </div>
                                {b.videoUrl && <div className="absolute bottom-4 left-4 p-2 bg-indigo-600 rounded-lg text-white shadow-lg"><Film size={12}/></div>}
                            </div>
                            <div className="p-6">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-white font-black text-sm truncate">{b.title}</h4>
                                    <span className="text-[10px] text-slate-600 font-mono font-black">Order: {b.order}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className={`w-2 h-2 rounded-full ${b.isActive ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-slate-700'}`}></span>
                                    <span className="text-[9px] text-slate-500 font-bold uppercase">{b.isActive ? 'Active' : 'Hidden'}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
              </div>
          )}
          {storeSubTab === 'CATEGORIES' && (
              <div className="space-y-6">
                  <div className="flex justify-between items-center px-4">
                      <p className="text-slate-500 text-xs font-bold">تصنيفات المنتجات (مثل: شدات، بطاقات هدايا)</p>
                      <button onClick={() => setEditingCategory({ id: `c_${Date.now()}`, name: '', isActive: true, order: categories.length + 1 })} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl font-black text-[10px] uppercase shadow-lg transition-all active:scale-95"><Plus size={14}/> إضافة قسم جديد</button>
                  </div>
                  <div className="glass-card rounded-[2.5rem] border border-white/5 overflow-hidden">
                      <table className="w-full text-right text-sm">
                          <thead className="bg-[#030712] text-slate-500 text-[10px] font-black uppercase tracking-widest border-b border-white/5">
                              <tr>
                                  <th className="p-6">القسم</th>
                                  <th className="p-6">الوصف</th>
                                  <th className="p-6">الترتيب</th>
                                  <th className="p-6">الحالة</th>
                                  <th className="p-6 text-center">إدارة</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                              {categories.map(c => (
                                  <tr key={c.id} className="hover:bg-white/[0.02] transition-all">
                                      <td className="p-6">
                                          <div className="flex items-center gap-4">
                                              <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-xl overflow-hidden border border-white/5">
                                                  {c.image ? <img src={c.image} className="w-full h-full object-cover" /> : c.icon || '📦'}
                                              </div>
                                              <div>
                                                  <p className="font-black text-white">{c.name}</p>
                                                  {c.parentCategoryId && (
                                                      <span className="text-[8px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded ml-1">فرعي</span>
                                                  )}
                                              </div>
                                          </div>
                                      </td>
                                      <td className="p-6 text-xs text-slate-500 font-bold max-w-xs truncate">{c.description || 'بدون وصف'}</td>
                                      <td className="p-6 font-mono font-black text-indigo-400">{c.order}</td>
                                      <td className="p-6">
                                          <span className={`px-2 py-1 rounded text-[8px] font-black uppercase ${c.isActive ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-800 text-slate-500'}`}>{c.isActive ? 'نشط' : 'معطل'}</span>
                                      </td>
                                      <td className="p-6 text-center">
                                          <div className="flex justify-center gap-2">
                                              <button onClick={() => setEditingCategory(c)} className="p-2 bg-white/5 hover:bg-emerald-600 text-slate-400 hover:text-white rounded-lg transition-all"><Edit3 size={14}/></button>
                                              <button onClick={() => onDeleteCategory(c.id)} className="p-2 bg-white/5 hover:bg-rose-600 text-slate-400 hover:text-white rounded-lg transition-all"><Trash2 size={14}/></button>
                                          </div>
                                      </td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </div>
          )}
          {storeSubTab === 'PRODUCTS' && (
              <div className="space-y-6">
                  <div className="flex justify-between items-center px-4">
                      <p className="text-slate-500 text-xs font-bold">إجمالي المنتجات المسجلة: {products.length}</p>
                      <button onClick={() => setEditingProduct({ id: `p_${Date.now()}`, name: '', price: 0, categoryId: categories[0]?.id || '', images: [], isActive: true, stock: 100, type: 'DIGITAL', deliveryType: 'MANUAL', inputFields: [], quantityForPrice: 1 })} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl font-black text-[10px] uppercase shadow-lg transition-all active:scale-95"><Plus size={14}/> إضافة منتج جديد</button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      {products.map(p => (
                          <div key={p.id} className="glass-card p-6 rounded-[2rem] border border-white/5 group hover:border-white/10 transition-all flex flex-col justify-between bg-[#030712]/40 relative overflow-hidden">
                              <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex gap-1">
                                <button onClick={() => setEditingProduct(p)} className="p-2 bg-black/80 rounded-lg text-white hover:bg-emerald-600 transition-all"><Edit3 size={12}/></button>
                                <button onClick={() => onDeleteProduct(p.id)} className="p-2 bg-black/80 rounded-lg text-white hover:bg-rose-600 transition-all"><Trash2 size={12}/></button>
                              </div>
                              <div className="mb-4">
                                  <div className="h-40 bg-black/20 rounded-2xl mb-4 flex items-center justify-center text-5xl border border-white/5 overflow-hidden">
                                      {p.images[0]?.startsWith('http') || p.images[0]?.startsWith('data:') ? <img src={p.images[0]} className="w-full h-full object-contain" /> : p.images[0] || '📦'}
                                  </div>
                                  <div className="flex justify-between items-start">
                                      <div>
                                        <h4 className="text-white font-black text-sm">{p.name}</h4>
                                        <span className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">{categories.find(c => c.id === p.categoryId)?.name}</span>
                                      </div>
                                      <div className="text-left">
                                        <p className="text-emerald-400 font-black text-sm">${p.price.toFixed(2)}</p>
                                        <p className="text-[8px] text-slate-500 font-mono font-bold">for {p.quantityForPrice || 1} units</p>
                                      </div>
                                  </div>
                              </div>
                              <div className="flex justify-between items-center pt-4 border-t border-white/5 mt-auto">
                                  <div className="flex items-center gap-1.5 text-[9px] font-black text-slate-500">
                                      <Box size={10} /> {p.stock > 0 ? `${p.stock} Qty` : 'Out of Stock'}
                                  </div>
                                  <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${p.isActive ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-800 text-slate-500'}`}>{p.isActive ? 'Active' : 'Hidden'}</span>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          )}
        </div>
      );
      case 'PURCHASE_MGMT': return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* ... Purchase Mgmt ... */}
            <div className="flex justify-between items-center px-4">
                <h3 className="text-2xl font-black text-white">طلبات المتجر (شراء)</h3>
                <select value={purchaseFilterStatus} onChange={(e) => setPurchaseFilterStatus(e.target.value as any)} className="bg-slate-900 border border-white/10 rounded-xl px-4 py-2.5 text-xs font-bold text-white outline-none focus:border-emerald-500">
                    <option value="ALL">الكل</option>
                    <option value="PENDING">طلبات جديدة (معلق)</option>
                    <option value="COMPLETED">تم التنفيذ</option>
                    <option value="FAILED">مرفوضة</option>
                </select>
            </div>
            
            <div className="glass-card rounded-[2.5rem] border border-white/5 overflow-hidden">
                <table className="w-full text-right text-sm">
                    <thead className="bg-[#030712] text-slate-500 text-[10px] font-black uppercase tracking-widest border-b border-white/5">
                        <tr>
                            <th className="p-6">المستخدم</th>
                            <th className="p-6">تفاصيل الطلب</th>
                            <th className="p-6">القيمة</th>
                            <th className="p-6">الحالة</th>
                            <th className="p-6 text-center">إجراء</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {purchaseTransactions.length === 0 ? (
                            <tr><td colSpan={5} className="p-12 text-center text-slate-500 font-bold">لا توجد طلبات شراء تطابق البحث</td></tr>
                        ) : purchaseTransactions.map(tx => (
                            <tr key={tx.id} className="hover:bg-white/[0.02] transition-all">
                                <td className="p-6">
                                    <p className="font-black text-white">{tx.userName}</p>
                                    <p className="text-[10px] text-slate-500 font-mono mt-1">{tx.userId}</p>
                                </td>
                                <td className="p-6">
                                    <div className="max-w-xs">
                                        <p className="text-white font-bold text-xs truncate" title={tx.description}>{tx.description.split('|')[0]}</p>
                                        <p className="text-[10px] text-slate-400 mt-1 truncate">{tx.description.split('|').slice(1).join(' | ')}</p>
                                    </div>
                                </td>
                                <td className="p-6 font-mono font-black text-emerald-400">{tx.amount} {tx.currency}</td>
                                <td className="p-6">{getStatusBadge(tx.status)}</td>
                                <td className="p-6 text-center">
                                    <button onClick={() => setSelectedTx(tx)} className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-[10px] font-black transition-all">معاينة</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
      );
      case 'REMITTANCES': return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* ... Remittance Mgmt ... */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 px-2">
                <div className="flex bg-slate-900/50 p-1.5 rounded-2xl border border-white/5">
                    {[
                        { id: 'ALL', label: 'الكل' },
                        { id: 'TRANSFER', label: 'تحويلات' },
                        { id: 'WITHDRAWAL', label: 'سحب' },
                        { id: 'EXCHANGE', label: 'صرف' }
                    ].map(type => (
                        <button key={type.id} onClick={() => setRemittanceFilterType(type.id as any)} className={`px-6 py-2.5 rounded-xl text-[10px] font-black transition-all ${remittanceFilterType === type.id ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}>
                            {type.label}
                        </button>
                    ))}
                </div>
                <select value={remittanceFilterStatus} onChange={(e) => setRemittanceFilterStatus(e.target.value as any)} className="bg-slate-900 border border-white/10 rounded-xl px-4 py-2.5 text-xs font-bold text-white outline-none focus:border-emerald-500">
                    <option value="ALL">كل الحالات</option>
                    <option value="PENDING">معلق</option>
                    <option value="COMPLETED">مكتمل</option>
                    <option value="FAILED">مرفوض</option>
                </select>
            </div>
            
            <div className="glass-card rounded-[2.5rem] border border-white/5 overflow-hidden">
                <table className="w-full text-right text-sm">
                    <thead className="bg-[#030712] text-slate-500 text-[10px] font-black uppercase tracking-widest border-b border-white/5">
                        <tr>
                            <th className="p-6">المستخدم</th>
                            <th className="p-6">نوع العملية</th>
                            <th className="p-6">المبلغ</th>
                            <th className="p-6">التفاصيل</th>
                            <th className="p-6">الحالة</th>
                            <th className="p-6 text-center">إجراء</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {remittanceTransactions.map(tx => (
                            <tr key={tx.id} className="hover:bg-white/[0.02] transition-all">
                                <td className="p-6">
                                    <p className="font-black text-white">{tx.userName}</p>
                                    <p className="text-[10px] text-slate-500 font-mono mt-1">{tx.userId}</p>
                                </td>
                                <td className="p-6">
                                    <span className="bg-white/5 px-2 py-1 rounded text-[9px] font-black uppercase">
                                        {tx.type === TransactionType.TRANSFER ? 'تحويل' : tx.type === TransactionType.WITHDRAWAL ? 'سحب' : 'صرف'}
                                    </span>
                                </td>
                                <td className="p-6 font-mono font-black text-emerald-400">{tx.amount.toLocaleString()} {tx.currency}</td>
                                <td className="p-6 text-xs text-slate-400 max-w-xs truncate" title={tx.description}>{tx.description}</td>
                                <td className="p-6">{getStatusBadge(tx.status)}</td>
                                <td className="p-6 text-center">
                                    <button onClick={() => setSelectedTx(tx)} className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-[10px] font-black transition-all">معاينة</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {remittanceTransactions.length === 0 && <div className="p-12 text-center text-slate-500 font-bold">لا توجد عمليات تطابق البحث</div>}
            </div>
        </div>
      );
      case 'DEPOSITS_MGMT': return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* ... Deposits ... */}
            <div className="flex justify-between items-center px-4">
                <h3 className="text-2xl font-black text-white">طلبات الإيداع</h3>
                <select value={depositFilterStatus} onChange={(e) => setDepositFilterStatus(e.target.value as any)} className="bg-slate-900 border border-white/10 rounded-xl px-4 py-2.5 text-xs font-bold text-white outline-none focus:border-emerald-500">
                    <option value="ALL">الكل</option>
                    <option value="PENDING">بانتظار المراجعة</option>
                    <option value="COMPLETED">تمت الموافقة</option>
                    <option value="FAILED">مرفوضة</option>
                </select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {depositTransactions.map(tx => (
                    <div key={tx.id} className="glass-card p-6 rounded-[2.5rem] border border-white/5 flex flex-col gap-4 relative overflow-hidden group hover:border-emerald-500/20 transition-all">
                        <div className="flex justify-between items-start">
                            <div>
                                <h4 className="text-white font-black">{tx.userName}</h4>
                                <p className="text-[10px] text-slate-500 font-mono mt-1">{tx.id}</p>
                            </div>
                            {getStatusBadge(tx.status)}
                        </div>
                        <div className="bg-black/20 p-4 rounded-2xl border border-white/5 flex justify-between items-center">
                            <span className="text-slate-400 text-xs font-bold">المبلغ المودع</span>
                            <span className="text-emerald-400 font-mono font-black text-xl">{tx.amount} {tx.currency}</span>
                        </div>
                        {tx.proofImage && (
                            <div className="h-32 bg-black/40 rounded-2xl overflow-hidden relative group/img cursor-pointer" onClick={() => setSelectedTx(tx)}>
                                <img src={tx.proofImage} className="w-full h-full object-cover opacity-80 group-hover/img:opacity-100 transition-opacity" />
                                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/img:opacity-100 transition-opacity bg-black/40">
                                    <Eye className="text-white" />
                                </div>
                            </div>
                        )}
                        <div className="flex gap-2 mt-auto">
                            <button onClick={() => setSelectedTx(tx)} className="w-full bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl text-xs font-black transition-all">مراجعة التفاصيل</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      );
      case 'USERS': return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="flex justify-between items-center px-4">
                <h3 className="text-2xl font-black text-white">إدارة المستخدمين</h3>
                <div className="relative">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4"/>
                    <input type="text" placeholder="بحث بالاسم أو الكود..." value={userSearch} onChange={e => setUserSearch(e.target.value)} className="bg-slate-900 border border-white/10 rounded-xl pr-10 pl-4 py-2.5 text-xs font-bold text-white outline-none focus:border-emerald-500 w-64" />
                </div>
            </div>
            <div className="glass-card rounded-[2.5rem] border border-white/5 overflow-hidden">
                <table className="w-full text-right text-sm">
                    <thead className="bg-[#030712] text-slate-500 text-[10px] font-black uppercase tracking-widest border-b border-white/5">
                        <tr>
                            <th className="p-6">المستخدم</th>
                            <th className="p-6">البريد الإلكتروني</th>
                            <th className="p-6">الدور</th>
                            <th className="p-6">الحالة</th>
                            <th className="p-6 text-center">إدارة</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {filteredUsers.map(u => (
                            <tr key={u.id} className="hover:bg-white/[0.02] transition-all">
                                <td className="p-6">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-black text-white">{u.name[0]}</div>
                                        <div>
                                            <p className="font-black text-white">{u.name}</p>
                                            <p className="text-[9px] text-slate-500 font-mono">{u.userCode}</p>
                                        </div>
                                    </div>
                                </td>
                                <td className="p-6 text-xs text-slate-400 font-mono">{u.email}</td>
                                <td className="p-6"><span className="bg-indigo-500/10 text-indigo-400 px-2 py-1 rounded text-[9px] font-black uppercase">{u.role}</span></td>
                                <td className="p-6">
                                    <span className={`px-2 py-1 rounded text-[8px] font-black uppercase ${u.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>{u.status}</span>
                                </td>
                                <td className="p-6 text-center">
                                    <button onClick={() => setSelectedUserToManage(u)} className="p-2 bg-white/5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all"><UserCog size={16}/></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
      );
      case 'FINANCE': return (
        <FinancialSystem 
            currencies={currencies} 
            gateways={gateways} 
            onUpdateCurrency={onUpdateCurrency} 
            onAddCurrency={onAddCurrency} 
            onDeleteCurrency={onDeleteCurrency} 
            onUpdateGateway={onUpdateGateway} 
            onAddGateway={onAddGateway} 
            onDeleteGateway={onDeleteGateway} 
            onManageGateways={setManagingGatewayCurrency} 
        />
      );
      case 'FEES': return (
        <FeesManager 
            settings={settings} 
            onUpdateSettings={onUpdateSettings} 
            currencies={currencies} 
            onUpdateCurrency={onUpdateCurrency} 
        />
      );
      case 'SETTINGS': return (
        <SettingsPanel settings={settings} onUpdateSettings={onUpdateSettings} />
      );
      default: return (
        <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* ... Dashboard Widgets ... */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                    { label: 'إجمالي الأرباح', value: `$${stats.revenue.toLocaleString()}`, icon: Landmark, color: 'emerald', tab: null },
                    { label: 'حوالات معلقة', value: transactions.filter(t => (t.type === TransactionType.TRANSFER || t.type === TransactionType.WITHDRAWAL || t.type === TransactionType.EXCHANGE) && t.status === TransactionStatus.PENDING).length, icon: ArrowRightLeft, color: 'rose', tab: 'REMITTANCES' },
                    { label: 'طلبات شراء', value: transactions.filter(t => t.type === TransactionType.PURCHASE && t.status === TransactionStatus.PENDING).length, icon: ShoppingCart, color: 'amber', tab: 'PURCHASE_MGMT' },
                    { label: 'إيداعات جديدة', value: transactions.filter(t => t.type === TransactionType.DEPOSIT && t.status === TransactionStatus.PENDING).length, icon: CreditCard, color: 'indigo', tab: 'DEPOSITS_MGMT' }
                ].map((item, i) => (
                    <div 
                        key={i} 
                        onClick={() => item.tab && setActiveTab(item.tab)}
                        className={`glass-card p-8 rounded-[2.5rem] border border-white/5 relative overflow-hidden group hover:border-white/20 transition-all duration-500 shadow-2xl hover:scale-[1.02] ${item.tab ? 'cursor-pointer active:scale-95' : ''}`}
                    >
                        <div className={`absolute top-0 right-0 w-32 h-32 bg-${item.color}-500/5 rounded-full blur-[60px]`}></div>
                        <div className="relative z-10">
                            <div className={`p-4 bg-${item.color}-500/10 rounded-2xl w-fit text-${item.color}-400 mb-6 group-hover:scale-110 transition-transform`}><item.icon size={24} /></div>
                            <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">{item.label}</p>
                            <p className="text-3xl font-black text-white font-mono">{item.value}</p>
                            
                            {item.tab && (
                                <div className="absolute left-6 bottom-6 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <ChevronRight size={16} className="text-slate-600" />
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
            <div className="glass-card rounded-[2.5rem] border border-white/5 overflow-hidden shadow-2xl">
                <div className="p-6 border-b border-white/5 bg-slate-900/50 flex justify-between items-center">
                    <h3 className="text-white font-black flex items-center gap-3"><Activity size={20} /> سجل العمليات الأخير</h3>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-right text-sm">
                        <tbody className="divide-y divide-white/5">
                            {transactions.slice(0, 10).map(tx => (
                                <tr key={tx.id} className="hover:bg-white/[0.02] transition-all">
                                    <td className="p-4 font-black text-white">{tx.userName}</td>
                                    <td className="p-4 text-slate-400">{tx.description.split('|')[0]}</td>
                                    <td className="p-4 font-mono font-black text-emerald-400">{tx.amount} {tx.currency}</td>
                                    <td className="p-4">{getStatusBadge(tx.status)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
      );
    }
  };

  return (
    <div className="flex h-screen bg-[#020617] text-white overflow-hidden font-sans selection:bg-emerald-500 selection:text-white" dir="rtl">
      {/* Sidebar */}
      <aside className="w-80 bg-[#0a0f1e] border-l border-white/5 flex flex-col shrink-0 relative z-[50] shadow-2xl">
        <div className="p-10 pb-12 flex items-center gap-4 border-b border-white/5 mb-8 justify-end text-right">
            <div><h2 className="text-xl font-black text-white tracking-tighter uppercase">مركز الإدارة</h2><p className="text-slate-600 text-[9px] font-black uppercase tracking-[0.3em]">Horizon Control V3</p></div>
            <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-lg transform rotate-3"><Shield className="w-6 h-6 text-white" /></div>
        </div>
        <nav className="flex-1 px-6 space-y-3 overflow-y-auto scrollbar-hide">
            {[
                { id: 'DASHBOARD', label: 'لوحة التحكم', icon: LayoutDashboard, desc: 'ملخص العمليات العامة' }, 
                { id: 'HOSTING', label: 'الاستضافة والنشر', icon: Cloud, desc: 'إعدادات الخوادم والـ Deploy' },
                { id: 'REMITTANCES', label: 'إدارة الحوالات', icon: ArrowRightLeft, desc: 'التحويلات والمسحوبات والصرف' }, 
                { id: 'DEPOSITS_MGMT', label: 'إدارة الإيداعات', icon: CreditCard, desc: 'قبول دفعات المستخدمين' }, 
                { id: 'PURCHASE_MGMT', label: 'طلبات المتجر', icon: ShoppingCart, desc: 'مراجعة طلبات الشراء' },
                { id: 'STORE_MGMT', label: 'إدارة المتجر', icon: ShoppingBag, desc: 'إدارة المحتوى والمنتجات' },
                { id: 'GAME_MGMT', label: 'إدارة الألعاب', icon: Gamepad2, desc: 'إعدادات المسابقات والجوائز' },
                { id: 'USERS', label: 'إدارة المستخدمين', icon: Users, desc: 'تحكم في الأرصدة والحسابات' }, 
                { id: 'FINANCE', label: 'النظام المالي', icon: DollarSign, desc: 'أسعار الصرف وبوابات الدفع' }, 
                { id: 'FEES', label: 'إدارة الرسوم', icon: Percent, desc: 'سياسات الرسوم والضرائب' },
                { id: 'DEVELOPERS', label: 'بوابة المطورين', icon: Code, desc: 'API & Webhooks' },
                { id: 'SETTINGS', label: 'إعدادات المنصة', icon: Settings, desc: 'تخصيص الهوية والخصائص' }
            ].map(item => (
                <button key={item.id} onClick={() => setActiveTab(item.id)} className={`w-full flex items-center gap-5 p-5 rounded-3xl transition-all duration-500 group relative overflow-hidden hover:scale-[1.02] ${activeTab === item.id ? 'bg-emerald-600 text-white shadow-2xl shadow-emerald-900/40' : 'text-slate-500 hover:bg-white/5 hover:text-white'}`}>
                    <div className={`p-3 rounded-2xl transition-all ${activeTab === item.id ? 'bg-white/20 text-white' : 'bg-slate-900 text-slate-600 group-hover:bg-slate-800 group-hover:text-emerald-400'}`}><item.icon size={20} /></div>
                    <div className="text-right flex-1"><span className="text-sm font-black uppercase tracking-widest block">{item.label}</span><span className={`text-[8px] font-bold mt-1 block opacity-60 ${activeTab === item.id ? 'text-white' : 'text-slate-600'}`}>{item.desc}</span></div>
                </button>
            ))}
        </nav>
        <div className="p-8 border-t border-white/5 bg-black/20"><button onClick={() => onNavigate(View.DASHBOARD)} className="w-full py-4.5 rounded-2xl bg-white/5 text-[10px] font-black uppercase tracking-[0.3em] hover:bg-rose-600 hover:text-white transition-all active:scale-95 border border-white/5">العودة للمتجر</button></div>
      </aside>
      
      <main className="flex-1 flex flex-col overflow-hidden bg-[#020617] relative">
          <header className="px-12 py-8 border-b border-white/5 flex justify-between items-center bg-[#0a0f1e]/40 backdrop-blur-3xl sticky top-0 z-[40]">
              <div className="flex items-center gap-6 text-right"><h1 className="text-2xl font-black text-white tracking-tight uppercase">{activeTab === 'STORE_MGMT' ? 'إدارة المتجر' : activeTab === 'DEVELOPERS' ? 'بوابة المطورين' : activeTab === 'HOSTING' ? 'إدارة الاستضافة' : activeTab}</h1><button onClick={onBack} className="p-3 bg-emerald-500/10 hover:bg-emerald-600 text-emerald-500 hover:text-white rounded-2xl border border-emerald-500/20 transition-all active:scale-90"><ArrowLeft size={20} className="rtl:rotate-180" /></button></div>
          </header>
          <div className="flex-1 overflow-y-auto p-12 scrollbar-hide">{renderTabContent()}</div>
      </main>

      {/* MANAGING GATEWAYS MODAL */}
      {managingGatewayCurrency && (
          <CurrencyGatewayManager 
              currency={managingGatewayCurrency}
              allGateways={gateways}
              onClose={() => setManagingGatewayCurrency(null)}
              onUpdateGateway={onUpdateGateway}
              onAddGateway={onAddGateway}
              onDeleteGateway={onDeleteGateway}
          />
      )}

      {/* EDIT GAME MODAL (kept for brevity, unchanged) */}
      {/* ... (Existing Game/Banner/Category/Product/User modals code remains unchanged) ... */}
      {editingGame && (
          <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="glass-card w-full max-w-xl rounded-[3.5rem] border border-white/10 shadow-2xl relative overflow-hidden">
                  <div className="p-8 border-b border-white/5 bg-slate-900/50 flex justify-between items-center">
                      <h3 className="text-2xl font-black text-white">{games.some(g => g.id === editingGame.id) ? 'تعديل بيانات اللعبة' : 'إضافة لعبة جديدة'}</h3>
                      <button onClick={() => setEditingGame(null)} className="p-2 bg-white/5 rounded-full hover:bg-rose-500 transition-colors"><X/></button>
                  </div>
                  <div className="p-10 space-y-6">
                      <div className="space-y-2">
                          <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">اسم اللعبة</label>
                          <input type="text" value={editingGame.name} onChange={e => setEditingGame({...editingGame, name: e.target.value})} className="w-full bg-[#030712] border border-white/10 rounded-2xl p-4 text-white font-bold outline-none focus:border-indigo-500 transition-all" />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                              <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">النوع</label>
                              <select value={editingGame.type} onChange={e => setEditingGame({...editingGame, type: e.target.value as any})} className="w-full bg-[#030712] border border-white/10 rounded-2xl p-4 text-white font-bold outline-none focus:border-indigo-500">
                                  <option value="EXTERNAL_LINK">رابط خارجي (External Link)</option>
                                  <option value="EMBEDDED">نافذة مدمجة (Iframe)</option>
                                  <option value="INTERNAL" disabled>لعبة داخلية (Internal)</option>
                              </select>
                          </div>
                          <div className="space-y-2">
                              <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الحالة</label>
                              <button onClick={() => setEditingGame({...editingGame, isActive: !editingGame.isActive})} className={`w-full p-4 rounded-2xl font-black text-xs uppercase transition-all ${editingGame.isActive ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-500'}`}>
                                  {editingGame.isActive ? 'نشطة' : 'معطلة'}
                              </button>
                          </div>
                      </div>

                      {editingGame.type !== 'INTERNAL' && (
                          <div className="space-y-2">
                              <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">رابط اللعبة URL</label>
                              <div className="relative">
                                  <Globe className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                                  <input type="text" value={editingGame.url || ''} onChange={e => setEditingGame({...editingGame, url: e.target.value})} placeholder="https://game-provider.com/play..." className="w-full bg-[#030712] border border-white/10 rounded-2xl p-4 pr-10 pl-4 text-white font-mono text-xs outline-none focus:border-indigo-500 dir-ltr" />
                              </div>
                          </div>
                      )}

                      <div className="space-y-4">
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">صورة اللعبة</label>
                        <label className="w-full h-32 border-2 border-dashed border-white/10 hover:border-indigo-500/50 rounded-2xl flex items-center justify-center cursor-pointer transition-all bg-black/20 group relative overflow-hidden">
                            {editingGame.imageUrl ? <img src={editingGame.imageUrl} className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" /> : <div className="flex flex-col items-center gap-2"><ImageIcon className="text-slate-600 mb-1" /><span className="text-[10px] text-slate-500">Upload Cover</span></div>}
                            <input type="file" accept="image/*" onChange={e => handleFileUpload(e, 'game_img')} className="hidden" />
                        </label>
                      </div>

                      <div className="flex gap-4 pt-4">
                          <button onClick={() => { if(onAddGame && onUpdateGame) { games.some(g => g.id === editingGame.id) ? onUpdateGame(editingGame) : onAddGame(editingGame); } setEditingGame(null); }} className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white py-4 rounded-2xl font-black shadow-xl transition-all active:scale-95">حفظ البيانات</button>
                          <button onClick={() => setEditingGame(null)} className="flex-1 bg-white/5 text-slate-400 py-4 rounded-2xl font-black transition-all">إلغاء</button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* BANNER EDIT MODAL */}
      {editingBanner && (
          <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="glass-card w-full max-w-2xl rounded-[3.5rem] border border-white/10 shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]">
                  {/* ... Banner form ... */}
                  <div className="p-8 border-b border-white/5 bg-slate-900/50 flex justify-between items-center">
                      <button onClick={() => setEditingBanner(null)} className="p-3 bg-white/5 hover:bg-rose-600 text-white rounded-full transition-all active:scale-90"><X/></button>
                      <div className="text-right">
                          <h3 className="text-2xl font-black text-white">{banners.some(b => b.id === editingBanner.id) ? 'تعديل إعلان' : 'إضافة إعلان جديد'}</h3>
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Banner & Video Ads Manager</p>
                      </div>
                  </div>
                  <div className="flex-1 overflow-y-auto p-10 scrollbar-hide space-y-8">
                      <div className="space-y-2">
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">عنوان الإعلان الرئيسي</label>
                        <input type="text" value={editingBanner.title} onChange={e => setEditingBanner({...editingBanner, title: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-bold outline-none focus:border-emerald-500 transition-all" />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">صورة البنر (ثابتة)</label>
                            <label className="w-full h-40 border-2 border-dashed border-white/10 hover:border-emerald-500/50 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all bg-black/20 group relative overflow-hidden">
                                {editingBanner.imageUrl ? <img src={editingBanner.imageUrl} className="absolute inset-0 w-full h-full object-cover opacity-50" /> : null}
                                <div className="relative z-10 flex flex-col items-center">
                                    <ImageIcon className="text-slate-600 mb-2" />
                                    <span className="text-[10px] text-slate-600 font-black uppercase">Change Image</span>
                                </div>
                                <input type="file" accept="image/*" onChange={e => handleFileUpload(e, 'banner_img')} className="hidden" />
                            </label>
                        </div>
                        <div className="space-y-4">
                            <label className="text-[10px] text-indigo-400 font-black uppercase tracking-widest px-2">إعلان فيديو (متحرك)</label>
                            <label className="w-full h-40 border-2 border-dashed border-white/10 hover:border-indigo-500/50 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all bg-black/20 group relative overflow-hidden">
                                {editingBanner.videoUrl ? <div className="absolute inset-0 w-full h-full bg-indigo-900/20 flex items-center justify-center"><Film className="text-indigo-400 w-10 h-10 animate-pulse" /></div> : null}
                                <div className="relative z-10 flex flex-col items-center">
                                    <Film className="text-slate-600 mb-2" />
                                    <span className="text-[10px] text-slate-600 font-black uppercase">{editingBanner.videoUrl ? 'Video Attached' : 'Upload Video'}</span>
                                </div>
                                <input type="file" accept="video/*" onChange={e => handleFileUpload(e, 'banner_vid')} className="hidden" />
                            </label>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">ترتيب العرض</label>
                            <input type="number" value={editingBanner.order} onChange={e => setEditingBanner({...editingBanner, order: parseInt(e.target.value) || 0})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-black outline-none focus:border-emerald-500" />
                        </div>
                        <div className="flex items-end pb-1">
                            <button onClick={() => setEditingBanner({...editingBanner, isActive: !editingBanner.isActive})} className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${editingBanner.isActive ? 'bg-emerald-600/10 text-emerald-500 border border-emerald-500/20' : 'bg-rose-600/10 text-rose-500 border border-rose-500/20'}`}>
                                {editingBanner.isActive ? 'الإعلان نشط' : 'الإعلان معطل'}
                            </button>
                        </div>
                      </div>
                  </div>
                  <div className="p-8 bg-slate-900/50 border-t border-white/5 flex gap-4">
                      <button onClick={() => { onUpdateBanner(editingBanner); setEditingBanner(null); }} className="flex-[2] py-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black text-sm transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2"><Save size={18}/> حفظ البيانات</button>
                      <button onClick={() => setEditingBanner(null)} className="flex-1 bg-white/5 py-5 rounded-2xl text-slate-400 font-black text-sm">إلغاء</button>
                  </div>
              </div>
          </div>
      )}

      {/* CATEGORY & PRODUCT EDIT MODALS (Truncated for brevity, kept structure) */}
      {editingCategory && (
          <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 animate-in fade-in">
               <div className="glass-card w-full max-w-xl rounded-[3.5rem] border border-white/10 shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]">
                  {/* ... Same as previously generated Category Modal ... */}
                  <div className="p-8 border-b border-white/5 bg-slate-900/50 flex justify-between items-center shrink-0">
                      <button onClick={() => setEditingCategory(null)} className="p-3 bg-white/5 hover:bg-rose-600 text-white rounded-full transition-all active:scale-90"><X/></button>
                      <div className="text-right">
                          <h3 className="text-2xl font-black text-white">{categories.some(c => c.id === editingCategory.id) ? 'تعديل القسم' : 'إضافة قسم جديد'}</h3>
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Category Management</p>
                      </div>
                  </div>
                  
                  <div className="p-10 space-y-6 overflow-y-auto scrollbar-hide flex-1">
                      {/* ... Category Form Fields ... */}
                      <div className="flex gap-4">
                          <div className="w-24 space-y-2">
                             <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">أيقونة</label>
                             <input 
                                type="text" 
                                value={editingCategory.icon || ''} 
                                onChange={e => setEditingCategory({...editingCategory, icon: e.target.value})} 
                                className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-center text-2xl outline-none focus:border-emerald-500 transition-all"
                                placeholder="🏷️"
                             />
                          </div>
                          <div className="flex-1 space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">اسم القسم</label>
                            <input type="text" value={editingCategory.name} onChange={e => setEditingCategory({...editingCategory, name: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-bold outline-none focus:border-emerald-500" placeholder="مثلاً: بطاقات ألعاب" />
                          </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الوصف (اختياري)</label>
                        <textarea 
                            value={editingCategory.description || ''} 
                            onChange={e => setEditingCategory({...editingCategory, description: e.target.value})} 
                            className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-medium h-24 resize-none outline-none focus:border-emerald-500"
                            placeholder="وصف مختصر يظهر للمستخدم..."
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">القسم الرئيسي (الأب)</label>
                            <select 
                                value={editingCategory.parentCategoryId || ''} 
                                onChange={e => setEditingCategory({...editingCategory, parentCategoryId: e.target.value || undefined})} 
                                className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-bold outline-none focus:border-emerald-500 cursor-pointer appearance-none"
                            >
                                <option value="">بدون (قسم رئيسي)</option>
                                {categories.filter(c => c.id !== editingCategory.id).map(c => (
                                    <option key={c.id} value={c.id}>{c.name}</option>
                                ))}
                            </select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الترتيب</label>
                            <input type="number" value={editingCategory.order} onChange={e => setEditingCategory({...editingCategory, order: parseInt(e.target.value) || 0})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-black outline-none focus:border-emerald-500" />
                        </div>
                      </div>

                      <div className="space-y-4 pt-4 border-t border-white/5">
                        <div className="flex justify-between items-center">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">صورة الغلاف (اختياري)</label>
                            {editingCategory.image && <button onClick={() => setEditingCategory({...editingCategory, image: undefined})} className="text-rose-500 text-[10px] font-bold hover:underline">إزالة الصورة</button>}
                        </div>
                        <label className="w-full h-32 border-2 border-dashed border-white/10 hover:border-emerald-500/50 rounded-2xl flex items-center justify-center cursor-pointer transition-all bg-black/20 group relative overflow-hidden">
                            {editingCategory.image ? <img src={editingCategory.image} className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" /> : <div className="flex flex-col items-center gap-2"><ImageIcon className="text-slate-600 mb-1" /><span className="text-[10px] text-slate-500">Click to upload</span></div>}
                            <input type="file" accept="image/*" onChange={e => handleFileUpload(e, 'cat_img')} className="hidden" />
                        </label>
                      </div>

                      <div className="flex items-center justify-between bg-slate-900 p-4 rounded-2xl border border-white/5">
                          <span className="text-slate-400 text-xs font-bold px-2">حالة القسم</span>
                          <button onClick={() => setEditingCategory({...editingCategory, isActive: !editingCategory.isActive})} className={`px-6 py-2 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${editingCategory.isActive ? 'bg-emerald-600 text-white shadow-lg' : 'bg-slate-800 text-slate-500'}`}>
                                {editingCategory.isActive ? 'نشط' : 'معطل'}
                          </button>
                      </div>
                  </div>
                  
                  <div className="p-8 bg-slate-900/50 border-t border-white/5 flex gap-4 shrink-0">
                      <button onClick={() => { onUpdateCategory(editingCategory); setEditingCategory(null); }} className="flex-[2] py-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black text-sm transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2"><Save size={18}/> حفظ البيانات</button>
                      <button onClick={() => setEditingCategory(null)} className="flex-1 bg-white/5 py-5 rounded-2xl text-slate-400 font-black text-sm">إلغاء</button>
                  </div>
               </div>
          </div>
      )}

      {editingProduct && (
          <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 animate-in fade-in">
               <div className="glass-card w-full max-w-2xl rounded-[3.5rem] border border-white/10 shadow-2xl relative overflow-hidden flex flex-col max-h-[95vh]">
                  {/* ... Same as previously generated Product Modal ... */}
                  <div className="p-8 border-b border-white/5 bg-slate-900/50 flex justify-between items-center">
                      <button onClick={() => setEditingProduct(null)} className="p-3 bg-white/5 hover:bg-rose-600 text-white rounded-full transition-all active:scale-90"><X/></button>
                      <div className="text-right">
                          <h3 className="text-2xl font-black text-white">{products.some(p => p.id === editingProduct.id) ? 'تعديل المنتج' : 'إضافة منتج جديد'}</h3>
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Product Details & Pricing</p>
                      </div>
                  </div>
                  <div className="flex-1 overflow-y-auto p-10 space-y-8 scrollbar-hide">
                      <div className="space-y-4">
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">صورة المنتج الرئيسية</label>
                        <label className="w-full h-40 border-2 border-dashed border-white/10 hover:border-emerald-500/50 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all bg-black/20 group relative overflow-hidden">
                            {editingProduct.images && editingProduct.images[0] ? <img src={editingProduct.images[0]} className="absolute inset-0 w-full h-full object-contain p-4" /> : null}
                            <div className="relative z-10 flex flex-col items-center bg-black/60 p-2 rounded-xl backdrop-blur-sm">
                                <ImageIcon className="text-slate-400 mb-1" size={20} />
                                <span className="text-[10px] text-white font-black uppercase">Upload Product Image</span>
                            </div>
                            <input type="file" accept="image/*" onChange={e => handleFileUpload(e, 'prod_img')} className="hidden" />
                        </label>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">اسم المنتج</label>
                            <input type="text" value={editingProduct.name} onChange={e => setEditingProduct({...editingProduct, name: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-bold outline-none focus:border-emerald-500" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">القسم</label>
                            <select value={editingProduct.categoryId} onChange={e => setEditingProduct({...editingProduct, categoryId: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-black outline-none focus:border-emerald-500 cursor-pointer">
                                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] text-emerald-400 font-black uppercase tracking-widest px-2">السعر (USD)</label>
                            <input type="number" value={editingProduct.price} onChange={e => setEditingProduct({...editingProduct, price: parseFloat(e.target.value) || 0})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-emerald-400 font-mono font-black outline-none focus:border-emerald-500" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الكمية مقابل السعر</label>
                            <input 
                                type="number" 
                                value={editingProduct.quantityForPrice || 1} 
                                onChange={e => setEditingProduct({...editingProduct, quantityForPrice: parseFloat(e.target.value) || 1})} 
                                className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-mono font-bold outline-none focus:border-emerald-500" 
                                placeholder="مثلاً: 1000 شدة"
                            />
                        </div>
                      </div>
                      
                      <div className="space-y-4 pt-4 border-t border-white/5">
                          <div className="flex justify-between items-center px-2">
                              <h4 className="text-white font-black text-sm">متطلبات الطلب من العميل</h4>
                          </div>
                          <button 
                            onClick={toggleProductIdField}
                            className={`w-full py-4 rounded-2xl flex items-center justify-between px-6 transition-all border ${editingProduct.inputFields.some(f => f.id === 'player_id') ? 'bg-indigo-600/10 border-indigo-500 text-white' : 'bg-slate-900 border-white/5 text-slate-500'}`}
                          >
                              <div className="flex items-center gap-3">
                                  <div className={`p-2 rounded-lg ${editingProduct.inputFields.some(f => f.id === 'player_id') ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-600'}`}><Type size={16}/></div>
                                  <div className="text-right">
                                      <p className="font-black text-xs">طلب معرف/آيدي اللاعب (ID)</p>
                                      <p className="text-[9px] opacity-70">سيظهر حقل إجباري للعميل لإدخال الرقم الخاص به</p>
                                  </div>
                              </div>
                              {editingProduct.inputFields.some(f => f.id === 'player_id') ? <ToggleRight size={24} className="text-indigo-500"/> : <ToggleLeft size={24}/>}
                          </button>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">سعر العرض (اختياري)</label>
                        <input type="number" value={editingProduct.offerPrice || ''} onChange={e => setEditingProduct({...editingProduct, offerPrice: parseFloat(e.target.value) || undefined})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-mono outline-none focus:border-emerald-500" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الوصف المختصر</label>
                        <textarea value={editingProduct.shortDescription || ''} onChange={e => setEditingProduct({...editingProduct, shortDescription: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white h-24 resize-none outline-none focus:border-emerald-500" />
                      </div>
                      <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">المخزون المتوفر</label>
                            <input type="number" value={editingProduct.stock} onChange={e => setEditingProduct({...editingProduct, stock: parseInt(e.target.value) || 0})} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-mono outline-none focus:border-emerald-500" />
                        </div>
                        <div className="flex items-end pb-1">
                            <button onClick={() => setEditingProduct({...editingProduct, isActive: !editingProduct.isActive})} className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${editingProduct.isActive ? 'bg-emerald-600/10 text-emerald-500 border border-emerald-500/20' : 'bg-rose-600/10 text-rose-500 border border-rose-500/20'}`}>
                                {editingProduct.isActive ? 'منتج متاح' : 'منتج مخفي'}
                            </button>
                        </div>
                      </div>
                  </div>
                  <div className="p-8 bg-slate-900/50 border-t border-white/5 flex gap-4">
                      <button onClick={() => { onUpdateProduct(editingProduct); setEditingProduct(null); }} className="flex-[2] py-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black text-sm transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2"><Save size={18}/> حفظ المنتج</button>
                      <button onClick={setEditingProduct.bind(null, null)} className="flex-1 bg-white/5 py-5 rounded-2xl text-slate-400 font-black text-sm">إلغاء</button>
                  </div>
               </div>
          </div>
      )}

      {selectedUserToManage && activeManagedUser && (
          <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="glass-card w-full max-w-2xl rounded-[3.5rem] border border-white/10 shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="p-8 border-b border-white/5 bg-slate-900/50 flex justify-between items-center">
                      <button onClick={() => setSelectedUserToManage(null)} className="p-3 bg-white/5 hover:bg-rose-600 text-white rounded-full transition-all active:scale-90"><X/></button>
                      <div className="text-right">
                          <h3 className="text-2xl font-black text-white">{activeManagedUser.name}</h3>
                          <p className="text-xs text-slate-500 font-mono">{activeManagedUser.userCode}</p>
                      </div>
                  </div>

                  <div className="flex bg-black/20 p-2 mx-8 mt-6 rounded-2xl border border-white/5 gap-2">
                      {[
                          { id: 'PROFILE', label: 'الملف الشخصي', icon: UserCog },
                          { id: 'WALLET', label: 'المحفظة والرصيد', icon: WalletIcon },
                          { id: 'SECURITY', label: 'الأمان والحالة', icon: Shield }
                      ].map(tab => (
                          <button 
                            key={tab.id}
                            onClick={() => setManageUserTab(tab.id as any)}
                            className={`flex-1 py-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${manageUserTab === tab.id ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
                          >
                              <tab.icon size={14} /> {tab.label}
                          </button>
                      ))}
                  </div>

                  <div className="flex-1 overflow-y-auto p-10 scrollbar-hide">
                      
                      {manageUserTab === 'PROFILE' && (
                          <div className="space-y-6">
                              <div className="grid grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                      <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">الاسم الكامل</label>
                                      <div className="relative">
                                          <UserCog className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" />
                                          <input type="text" value={editUserForm.name} onChange={e => setEditUserForm({...editUserForm, name: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-white font-bold outline-none focus:border-indigo-500" />
                                      </div>
                                  </div>
                                  <div className="space-y-2">
                                      <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">كود المستخدم</label>
                                      <div className="relative">
                                          <Tag className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" />
                                          <input type="text" value={editUserForm.userCode} onChange={e => setEditUserForm({...editUserForm, userCode: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-white font-bold outline-none focus:border-indigo-500 font-mono" />
                                      </div>
                                  </div>
                              </div>
                              <div className="space-y-2">
                                  <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">البريد الإلكتروني</label>
                                  <div className="relative">
                                      <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" />
                                      <input type="email" value={editUserForm.email} onChange={e => setEditUserForm({...editUserForm, email: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-white font-bold outline-none focus:border-indigo-500" />
                                  </div>
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                      <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">رقم الهاتف</label>
                                      <div className="relative">
                                          <Phone className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" />
                                          <input type="text" value={editUserForm.phone} onChange={e => setEditUserForm({...editUserForm, phone: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-white font-bold outline-none focus:border-indigo-500 dir-ltr text-right" />
                                      </div>
                                  </div>
                                  <div className="space-y-2">
                                      <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">كلمة المرور</label>
                                      <div className="relative">
                                          <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" />
                                          <input type="text" value={editUserForm.password} onChange={e => setEditUserForm({...editUserForm, password: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-white font-bold outline-none focus:border-indigo-500" placeholder="••••" />
                                      </div>
                                  </div>
                              </div>
                              <button onClick={handleSaveUserProfile} className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"><Save size={16}/> حفظ التغييرات</button>
                          </div>
                      )}

                      {manageUserTab === 'WALLET' && (
                          <div className="bg-black/20 p-8 rounded-3xl border border-white/5 space-y-6">
                              <div className="flex justify-between items-center mb-2">
                                  <h4 className="text-white font-black text-sm flex items-center gap-3">تعديل الأرصدة يدوياً <WalletIcon className="w-4 h-4 text-emerald-500" /></h4>
                                  <select 
                                    value={selectedWalletCurrency}
                                    onChange={(e) => setSelectedWalletCurrency(e.target.value)}
                                    className="bg-slate-900 border border-white/10 rounded-xl px-4 py-2 text-xs font-bold text-white outline-none focus:border-emerald-500 cursor-pointer"
                                  >
                                      {currencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                                  </select>
                              </div>
                              
                              <div className="flex items-center justify-between">
                                  <span className="text-3xl font-mono font-black text-emerald-400">
                                      {activeManagedUser.wallets.find(w => w.currency === selectedWalletCurrency)?.balance.toLocaleString() || '0'}
                                  </span>
                                  <p className="text-[10px] text-slate-500 font-black uppercase">الرصيد الحالي ({selectedWalletCurrency})</p>
                              </div>
                              
                              <div className="space-y-4">
                                  <input type="number" value={balanceAdjustAmount} onChange={e => setBalanceAdjustAmount(e.target.value)} placeholder="0.00" className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-white font-mono font-bold text-center outline-none focus:border-emerald-500" />
                                  <div className="grid grid-cols-2 gap-4">
                                      <button onClick={() => adjustUserBalance(parseFloat(balanceAdjustAmount))} disabled={!balanceAdjustAmount} className="bg-emerald-600 hover:bg-emerald-500 text-white py-4 rounded-xl font-black transition-all active:scale-95 disabled:opacity-50">إضافة رصيد</button>
                                      <button onClick={() => adjustUserBalance(-parseFloat(balanceAdjustAmount))} disabled={!balanceAdjustAmount} className="bg-rose-600 hover:bg-rose-500 text-white py-4 rounded-xl font-black transition-all active:scale-95 disabled:opacity-50">خصم رصيد</button>
                                  </div>
                              </div>
                          </div>
                      )}
                      
                      {manageUserTab === 'SECURITY' && (
                          <div className="space-y-6">
                              <div className="space-y-4">
                                  <h4 className="text-white font-black text-xs uppercase tracking-widest px-1">حالة الحساب</h4>
                                  <div className="grid grid-cols-2 gap-4">
                                      <button onClick={() => onUpdateUserStatus(activeManagedUser.id, 'active')} className={`py-4 rounded-2xl font-black text-xs transition-all flex items-center justify-center gap-2 ${activeManagedUser.status === 'active' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-slate-900 text-slate-500 border border-white/5'}`}>
                                          <CheckCircle size={16}/> نشط (Active)
                                      </button>
                                      <button onClick={() => onUpdateUserStatus(activeManagedUser.id, 'suspended')} className={`py-4 rounded-2xl font-black text-xs transition-all flex items-center justify-center gap-2 ${activeManagedUser.status === 'suspended' ? 'bg-rose-600 text-white shadow-lg' : 'bg-slate-900 text-slate-500 border border-white/5'}`}>
                                          <XCircle size={16}/> موقوف (Suspended)
                                      </button>
                                  </div>
                              </div>

                              <div className="h-[1px] bg-white/5"></div>

                              <div className="space-y-4">
                                  <h4 className="text-white font-black text-xs uppercase tracking-widest px-1">الصلاحيات (Role)</h4>
                                  <div className="grid grid-cols-3 gap-2">
                                      {(['user', 'moderator', 'admin'] as UserRole[]).map(role => (
                                          <button key={role} onClick={() => onUpdateUserRole(activeManagedUser.id, role)} className={`py-3 rounded-xl font-black text-[10px] uppercase transition-all ${activeManagedUser.role === role ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-600 border border-white/5'}`}>{role}</button>
                                      ))}
                                  </div>
                              </div>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {selectedTx && (
          <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="glass-card w-full max-w-2xl rounded-[3rem] p-10 border border-white/10 shadow-2xl relative overflow-hidden flex flex-col max-h-[95vh]">
                  <div className="flex justify-between items-center border-b border-white/5 pb-6 mb-6">
                      <button onClick={() => { setSelectedTx(null); setAdminProof(null); }} className="p-3 bg-white/5 hover:bg-white/10 rounded-full transition-colors text-white"><X size={20}/></button>
                      <div className="text-right">
                        <h3 className="text-2xl font-black text-white">{selectedTx.status === TransactionStatus.PENDING ? 'اتخاذ قرار مالي' : 'تفاصيل العملية'}</h3>
                        <p className="text-xs text-slate-500 font-bold mt-1 font-mono">Ref: {selectedTx.id}</p>
                      </div>
                  </div>
                  {/* ... Transaction Details ... */}
                  <div className="flex-1 overflow-y-auto scrollbar-hide space-y-8">
                      <div className="flex items-center justify-between bg-slate-900/50 p-6 rounded-[2rem] border border-white/5">
                          <div className="text-right">
                              <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">المبلغ المطلوب</p>
                              <p className="text-3xl font-black text-emerald-400 font-mono tracking-tighter dir-ltr">
                                  {selectedTx.amount.toLocaleString('en-US')} <span className="text-sm text-slate-400">{selectedTx.currency}</span>
                              </p>
                          </div>
                          <div className="text-right">
                              <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">نوع العملية</p>
                              <span className={`px-4 py-1 rounded-full font-black text-[10px] uppercase tracking-widest ${selectedTx.type === TransactionType.WITHDRAWAL ? 'bg-rose-500/20 text-rose-500' : selectedTx.type === TransactionType.EXCHANGE ? 'bg-blue-500/20 text-blue-500' : 'bg-indigo-500/20 text-indigo-500'}`}>
                                  {selectedTx.type}
                              </span>
                          </div>
                      </div>

                      <div className="bg-black/40 p-8 rounded-[2rem] border border-white/5 space-y-6">
                          <h4 className="text-white font-black text-sm flex items-center gap-3 justify-end border-b border-white/5 pb-4">
                              {selectedTx.type === TransactionType.EXCHANGE ? 'بيانات تبديل العملة' : 'بيانات المستفيد / الدفع'}
                              {selectedTx.type === TransactionType.EXCHANGE ? <RefreshCw size={14} className="text-blue-500"/> : <Info size={14} className="text-indigo-500"/>}
                          </h4>
                          <div className="space-y-4 text-right">
                              <div className="flex justify-between items-center bg-slate-900/30 p-4 rounded-xl">
                                  <span className="font-mono text-emerald-400 font-black text-sm">
                                      {selectedTx.description.split('|')[0].replace('تحويل إلى: ', '').replace('سحب عبر: ', '').replace('صرف إلى ', '').replace('تبديل إلى: ', '')}
                                  </span>
                                  <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">
                                      {selectedTx.type === TransactionType.EXCHANGE ? 'العملة الهدف' : 'المستلم / الطريقة'}
                                  </span>
                              </div>
                              <div className="bg-slate-900/30 p-6 rounded-xl border border-white/5">
                                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-2">ملاحظات / بيانات العملية</p>
                                  <p className="text-white font-bold leading-relaxed">{selectedTx.description.split('|').slice(1).join(' | ') || 'لا توجد تفاصيل إضافية.'}</p>
                              </div>
                          </div>
                      </div>

                      {selectedTx.proofImage && (
                        <div className="space-y-4">
                            <h4 className="text-white font-black text-sm px-2 flex items-center gap-2 justify-end">إثبات الدفع المرفق من العميل <ImageIcon size={14} className="text-emerald-500"/></h4>
                            <div className="bg-black/40 rounded-[2rem] border border-white/5 overflow-hidden p-4">
                               <img src={selectedTx.proofImage} className="w-full h-auto max-h-64 object-contain rounded-xl shadow-2xl" alt="Customer Proof" />
                            </div>
                        </div>
                      )}

                      {selectedTx.status === TransactionStatus.PENDING ? (
                        <div className="space-y-6 pt-6 border-t border-white/5 text-right">
                            <div className="space-y-2">
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">إرفاق إيصال التنفيذ (سيظهر للعميل كفاتورة)</label>
                                <label className="w-full h-24 border-2 border-dashed border-white/10 hover:border-indigo-500/50 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all bg-black/20 group">
                                    <input type="file" accept="image/*" onChange={handleAdminProofUpload} className="hidden" />
                                    {adminProof ? (
                                        <div className="flex items-center gap-3 text-emerald-400 font-bold text-xs"><Check size={16}/> تم اختيار إيصال التنفيذ</div>
                                    ) : (
                                        <div className="flex flex-col items-center gap-1 group-hover:scale-105 transition-transform"><Upload size={20} className="text-slate-600"/><span className="text-[10px] text-slate-600 font-black uppercase">Upload Execution Receipt</span></div>
                                    )}
                                </label>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">رسالة للعميل (اختياري)</label>
                                <textarea placeholder="مثلاً: تم تنفيذ طلب الصرف بنجاح وفقاً لسعر اللحظة..." value={adminNote} onChange={e => setAdminNote(e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-2xl p-4 text-white text-sm font-bold outline-none focus:border-indigo-500 h-24 resize-none text-right" />
                            </div>

                            <div className="flex gap-4">
                                <button onClick={() => processTransactionDecision(TransactionStatus.COMPLETED)} className="flex-1 py-5 rounded-2xl font-black text-sm bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-xl flex items-center justify-center gap-2"><CheckCircle size={18}/> تأكيد التنفيذ</button>
                                <button onClick={() => processTransactionDecision(TransactionStatus.FAILED)} className="flex-1 bg-rose-600 hover:bg-rose-500 text-white py-5 rounded-2xl font-black text-sm transition-all shadow-xl flex items-center justify-center gap-2"><XCircle size={18}/> رفض الطلب</button>
                            </div>
                        </div>
                      ) : (
                        <div className="space-y-6 pt-6 border-t border-white/5 text-right">
                           <div className="bg-black/30 p-6 rounded-2xl border border-white/5">
                              <h4 className="text-slate-500 font-black text-[10px] uppercase tracking-widest mb-2">قرار الإدارة المسبق</h4>
                              <p className="text-white font-bold">{selectedTx.adminNote || 'لا تووجد ملاحظات إدارية.'}</p>
                              {selectedTx.adminProofImage && (
                                <div className="mt-4 pt-4 border-t border-white/5 flex flex-col items-end">
                                    <p className="text-[10px] text-slate-600 font-black uppercase mb-3 flex items-center gap-2">إيصال التنفيذ الرسمي <Receipt size={12}/></p>
                                    <img src={selectedTx.adminProofImage} className="w-32 h-32 object-cover rounded-xl border border-white/10 shadow-2xl" />
                                </div>
                              )}
                           </div>
                        </div>
                      )}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default AdminPanel;
