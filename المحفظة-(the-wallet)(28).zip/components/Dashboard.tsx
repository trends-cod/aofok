
import React, { useState, useEffect, useMemo } from 'react';
import { User, Transaction, Banner, Category, Product, CurrencyConfig, View, PriceTier, TransactionStatus, TransactionType, ManualGateway } from '../types';
import { 
  Search, ShoppingCart, Wallet, Loader2, Sparkles, Filter, 
  X, Check, Minus, Plus, CheckCircle, Store, Zap, Layers, ChevronRight, Tags,
  ChevronLeft, ArrowLeftRight, Star, Info, Calculator, AlertCircle, ArrowUpRight,
  XCircle, Package, Clock, Truck, Edit3, CreditCard, Send, ShieldCheck
} from 'lucide-react';
import { useLanguage } from '../i18n';

interface DashboardProps {
  user: User;
  transactions: Transaction[];
  banners: Banner[];
  categories: Category[];
  products: Product[];
  currencies: CurrencyConfig[];
  gateways: ManualGateway[];
  onNavigate: (view: View) => void;
  onPurchase: (product: Product, quantity: number, inputs: Record<string, string>) => Promise<{success: boolean, message: string}>;
}

interface ConfettiPart {
  id: number;
  left: string;
  color: string;
  delay: string;
  duration: string;
}

const Dashboard: React.FC<DashboardProps> = ({ user, transactions, banners, categories, products, currencies, gateways, onNavigate, onPurchase }) => {
  const { t, language } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  
  const [buyingProduct, setBuyingProduct] = useState<Product | null>(null);
  const [purchaseQuantity, setPurchaseQuantity] = useState(1);
  const [purchaseInputs, setPurchaseInputs] = useState<Record<string, string>>({});
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [purchaseStatus, setPurchaseStatus] = useState<'idle' | 'pending' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [confetti, setConfetti] = useState<ConfettiPart[]>([]);

  const recentOrders = useMemo(() => {
      return transactions
        .filter(t => t.userId === user.id && t.type === TransactionType.PURCHASE)
        .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 3);
  }, [transactions, user.id]);

  const activeBanners = useMemo(() => banners.filter(b => b.isActive).sort((a,b) => a.order - b.order), [banners]);

  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const interval = setInterval(() => {
        setCurrentBannerIndex(prev => (prev + 1) % activeBanners.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [activeBanners.length]);

  const filteredProducts = useMemo(() => {
    let result = products.filter(p => p.isActive && !p.isHidden);
    if (selectedCategory !== 'all') result = result.filter(p => p.categoryId === selectedCategory);
    if (searchQuery) result = result.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
    return result;
  }, [products, selectedCategory, searchQuery]);

  const totalBalanceUSD = useMemo(() => {
    const usdWallet = user.wallets.find(w => w.currency === 'USD');
    return usdWallet?.balance || 0;
  }, [user.wallets]);

  const currentPriceInfo = useMemo(() => {
    if (!buyingProduct) return { unitPrice: 0, totalPrice: 0, basePrice: 0, baseQty: 1 };
    
    const basePrice = buyingProduct.offerPrice || buyingProduct.price;
    const baseQty = buyingProduct.quantityForPrice || 1;
    
    const totalPrice = (basePrice * purchaseQuantity) / baseQty;
    const unitPrice = basePrice / baseQty;
    
    return { unitPrice, totalPrice, basePrice, baseQty };
  }, [buyingProduct, purchaseQuantity]);

  const isBalanceLow = useMemo(() => {
      return totalBalanceUSD < currentPriceInfo.totalPrice;
  }, [totalBalanceUSD, currentPriceInfo.totalPrice]);

  const spawnConfetti = () => {
    const newConfetti = Array.from({ length: 40 }).map((_, i) => ({
        id: Date.now() + i,
        left: `${Math.random() * 100}%`,
        color: ['#10b981', '#f59e0b', '#3b82f6', '#ffffff'][Math.floor(Math.random() * 4)],
        delay: `${Math.random() * 0.5}s`,
        duration: `${2 + Math.random() * 2}s`
    }));
    setConfetti(newConfetti);
  };

  const handleConfirmPurchase = async () => {
    if (!buyingProduct || isPurchasing || isBalanceLow) return;
    
    setIsPurchasing(true);
    setErrorMessage(null);
    
    try {
        const res = await onPurchase(buyingProduct, purchaseQuantity, purchaseInputs);
        if (res.success) {
            setPurchaseStatus('success');
            spawnConfetti();
            setTimeout(() => {
                setPurchaseStatus('pending');
                setBuyingProduct(null);
            }, 1500);
        } else {
            setErrorMessage(res.message);
            setPurchaseStatus('error');
            setTimeout(() => setPurchaseStatus('idle'), 3000);
        }
    } catch (err) {
        setErrorMessage("خطأ في معالجة العملية.");
        setPurchaseStatus('error');
        setTimeout(() => setPurchaseStatus('idle'), 3000);
    } finally {
        setIsPurchasing(false);
    }
  };

  const renderProductImage = (imgSrc: string | undefined, sizeClass: string = "text-7xl") => {
    if (!imgSrc) return <span className={sizeClass}>📦</span>;
    if (imgSrc.startsWith('http') || imgSrc.startsWith('data:image')) {
      return <img src={imgSrc} className="max-w-full max-h-full object-contain" alt="Product" />;
    }
    return <span className={sizeClass}>{imgSrc}</span>;
  };

  return (
    <div className="space-y-10 pb-32 animate-in fade-in duration-700 relative">
      <div className="fixed inset-0 pointer-events-none z-[300]">
          {confetti.map(c => (
              <div key={c.id} className="absolute w-3 h-3 rounded-sm animate-confetti" style={{ left: c.left, backgroundColor: c.color, animationDelay: c.delay, animationDuration: c.duration, top: '-10px' }} />
          ))}
      </div>

      {purchaseStatus === 'pending' && (
        <div className="fixed inset-0 z-[500] bg-black/95 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-300">
            <div className="max-w-md w-full text-center glass-card p-12 rounded-[3rem] animate-in zoom-in border-emerald-500/20 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
                <div className="w-24 h-24 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6 relative z-10 border border-emerald-500/20 shadow-[0_0_40px_rgba(16,185,129,0.2)]">
                    <Clock size={48} className="text-emerald-500 animate-pulse" />
                </div>
                <h2 className="text-3xl font-black text-white mb-4 relative z-10">تم إرسال الطلب للمراجعة</h2>
                <div className="bg-emerald-500/5 p-4 rounded-2xl border border-emerald-500/10 mb-8 relative z-10">
                    <p className="text-slate-300 text-sm font-bold leading-relaxed">
                        الطلب قيد المعاينة من قبل المسؤول حالياً.
                        <br/>
                        <span className="text-emerald-500 text-xs mt-1 block">(سيتم القبول أو الرفض وإشعارك بالنتيجة)</span>
                    </p>
                </div>
                <button onClick={() => setPurchaseStatus('idle')} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-5 rounded-2xl font-black transition-all active:scale-95 shadow-xl relative z-10">متابعة حالة الطلب</button>
            </div>
        </div>
      )}

      <div className="flex flex-col lg:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-lg transform -rotate-3">
                  <Store className="w-8 h-8 text-white" />
              </div>
              <div>
                  <h1 className="text-3xl font-black text-white tracking-tight">تصفح المتجر</h1>
                  <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Digital Asset Marketplace</p>
              </div>
          </div>

          <div className="flex items-center gap-3">
              <div onClick={() => onNavigate(View.WALLET)} className="bg-[#0a0f1e] px-8 py-5 rounded-[2rem] border border-emerald-500/20 flex items-center gap-6 group hover:border-emerald-500/50 hover:bg-[#0c1428] transition-all cursor-pointer active:scale-95 shadow-2xl hover:scale-[1.02]">
                  <div className="w-16 h-16 bg-slate-900/80 rounded-2xl flex items-center justify-center text-emerald-500 border border-white/5 shadow-inner group-hover:scale-110 transition-transform duration-500"><Wallet size={32} /></div>
                  <div className="text-right">
                      <p className="text-[12px] text-slate-500 font-black uppercase tracking-[0.1em] mb-1.5">{t('current_balance')}</p>
                      <div className="flex items-baseline gap-2 dir-ltr">
                        <span className="text-3xl font-black text-emerald-400 font-mono tracking-tighter">{totalBalanceUSD.toLocaleString('en-US')}</span>
                        <span className="text-2xl font-black text-emerald-500">$</span>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      {/* Live Order Tracker Section */}
      {recentOrders.length > 0 && (
          <div className="animate-in slide-in-from-right-10 duration-1000">
             <div className="flex items-center gap-3 mb-5 px-4">
                <Truck size={18} className="text-indigo-400 animate-bounce" />
                <h3 className="text-white font-black text-sm uppercase tracking-widest">تتبع طلباتك الأخيرة</h3>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {recentOrders.map(order => (
                    <div key={order.id} className="glass-card p-6 rounded-[2rem] border border-white/5 relative overflow-hidden group hover:border-indigo-500/30 hover:scale-[1.03] transition-all duration-300">
                        <div className="flex justify-between items-start mb-4">
                            <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center text-indigo-400"><Package size={20}/></div>
                            <span className={`text-[8px] font-black uppercase px-3 py-1 rounded-full ${
                                order.status === TransactionStatus.COMPLETED ? 'bg-emerald-500/10 text-emerald-500' :
                                order.status === TransactionStatus.PENDING ? 'bg-amber-500/10 text-amber-500 animate-pulse' :
                                'bg-rose-500/10 text-rose-500'
                            }`}>{order.status}</span>
                        </div>
                        <p className="text-white font-black text-xs mb-1 truncate">{order.description.split('\n')[0].replace('شراء: ', '')}</p>
                        <p className="text-[9px] text-slate-500 font-mono tracking-tighter">Order Ref: {order.id.slice(-8)}</p>
                        
                        {/* Tracker Progress Bar */}
                        <div className="mt-4 flex gap-1 h-1">
                            <div className={`flex-1 rounded-full ${order.status !== TransactionStatus.FAILED ? 'bg-indigo-500 shadow-[0_0_5px_rgba(99,102,241,0.5)]' : 'bg-rose-500'}`}></div>
                            <div className={`flex-1 rounded-full ${order.status === TransactionStatus.COMPLETED ? 'bg-indigo-500 shadow-[0_0_5px_rgba(99,102,241,0.5)]' : 'bg-slate-800'}`}></div>
                            <div className={`flex-1 rounded-full ${order.status === TransactionStatus.COMPLETED ? 'bg-emerald-500 shadow-[0_0_5px_rgba(16,185,129,0.5)]' : 'bg-slate-800'}`}></div>
                        </div>
                    </div>
                ))}
             </div>
          </div>
      )}

      {activeBanners.length > 0 && (
          <div className="relative group overflow-hidden rounded-[3rem] border border-white/5 shadow-2xl h-[300px] md:h-[350px]">
              {activeBanners.map((banner, idx) => (
                  <div key={banner.id} className={`absolute inset-0 transition-all duration-1000 ease-in-out ${idx === currentBannerIndex ? 'opacity-100 scale-100' : 'opacity-0 scale-105 pointer-events-none'}`}>
                      <img src={banner.imageUrl} className="w-full h-full object-cover" alt={banner.title} />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-black/20"></div>
                      <div className="absolute bottom-0 left-0 right-0 p-10 md:p-14 flex flex-col items-start justify-end h-full">
                          <h2 className="text-3xl md:text-5xl font-black text-white drop-shadow-2xl max-w-2xl leading-tight">{banner.title}</h2>
                      </div>
                  </div>
              ))}
              <div className="absolute bottom-8 right-14 flex gap-2">
                  {activeBanners.map((_, idx) => (
                      <button key={idx} onClick={() => setCurrentBannerIndex(idx)} className={`h-2 rounded-full transition-all duration-500 ${idx === currentBannerIndex ? 'w-8 bg-emerald-500' : 'w-2 bg-white/20 hover:bg-white/40'}`} />
                  ))}
              </div>
          </div>
      )}

      <div className="sticky top-4 z-20 space-y-4">
          <div className="relative group">
              <Search className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-emerald-500 transition-colors w-6 h-6" />
              <input type="text" placeholder="ابحث عن شدات، بطاقات، أو خدمات..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full bg-[#0f172a]/80 backdrop-blur-xl border border-white/5 rounded-[2rem] py-6 pr-16 pl-8 text-lg text-white font-bold outline-none focus:border-emerald-500/50 shadow-2xl" />
          </div>
          
          {/* Categories Section Updated */}
          <div className="flex items-center gap-4 overflow-x-auto scrollbar-hide py-4 px-2">
              <button 
                  onClick={() => setSelectedCategory('all')} 
                  className={`
                      shrink-0 h-16 px-8 rounded-[2rem] text-sm font-black transition-all duration-300 flex items-center justify-center shadow-xl
                      ${selectedCategory === 'all' 
                          ? 'bg-emerald-600 text-white shadow-emerald-900/20 scale-105' 
                          : 'bg-[#0f172a] text-slate-400 border border-white/5 hover:bg-slate-800 hover:text-white hover:border-emerald-500/20'}
                  `}
              >
                  الكل
              </button>

              {categories.map(c => (
                  <button 
                      key={c.id} 
                      onClick={() => setSelectedCategory(c.id)} 
                      className={`
                          shrink-0 h-16 px-6 pr-8 pl-6 rounded-[2rem] text-sm font-black transition-all duration-300 flex items-center gap-4 shadow-xl group
                          ${selectedCategory === c.id 
                              ? 'bg-emerald-600 text-white shadow-emerald-900/20 scale-105 border-emerald-500' 
                              : 'bg-[#0f172a] text-slate-300 border border-white/5 hover:bg-slate-800 hover:border-emerald-500/20 hover:text-white'}
                      `}
                  >
                      <span className="text-2xl drop-shadow-md group-hover:scale-125 transition-transform duration-500">
                          {c.icon || '📦'}
                      </span>
                      <span className="tracking-wide">{c.name}</span>
                  </button>
              ))}
          </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredProducts.map(p => (
            <div key={p.id} className="glass-card rounded-[2.5rem] p-6 border border-white/5 group hover:border-emerald-500/40 hover:scale-[1.03] transition-all duration-500 flex flex-col relative overflow-hidden active:scale-[0.98]">
                <div className="h-44 bg-[#020617] rounded-[2rem] mb-6 flex items-center justify-center shadow-inner relative overflow-hidden border border-white/5">
                    {renderProductImage(p.images[0])}
                </div>
                <div className="px-2 flex-1">
                    <h4 className="font-black text-xl text-white group-hover:text-emerald-400 transition-colors line-clamp-1 mb-2">{p.name}</h4>
                    <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-6">{categories.find(c => c.id === p.categoryId)?.name}</p>
                </div>
                <div className="mt-auto pt-6 flex justify-between items-center border-t border-white/5 px-2">
                    <span className="text-2xl font-black text-white font-mono tracking-tighter">${p.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                    <button onClick={() => { setBuyingProduct(p); setPurchaseQuantity(p.minQuantity || 1); setPurchaseInputs({}); setPurchaseStatus('idle'); setErrorMessage(null); }} className="bg-emerald-600 hover:bg-emerald-500 text-white p-4 rounded-2xl transition-all shadow-lg active:scale-90 hover:scale-110"><ShoppingCart size={22} /></button>
                </div>
            </div>
        ))}
      </div>
      
      {buyingProduct && purchaseStatus !== 'pending' && (
          <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="glass-card w-full max-w-2xl rounded-[3.5rem] border border-white/10 shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="p-8 border-b border-white/5 bg-slate-900/50 flex justify-between items-center">
                      <button onClick={() => setBuyingProduct(null)} className="p-3 bg-white/5 hover:bg-rose-600 text-white rounded-full transition-all active:scale-90"><X/></button>
                      <div className="text-right">
                          <h3 className="text-2xl font-black text-white">{buyingProduct.name}</h3>
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">تأكيد تفاصيل الطلب</p>
                      </div>
                  </div>

                  <div className="flex-1 overflow-y-auto p-10 scrollbar-hide space-y-10">
                      <div className="flex flex-col md:flex-row gap-8 items-center">
                          <div className="w-48 h-48 bg-[#020617] rounded-[2rem] flex items-center justify-center border border-white/5 shrink-0">
                              {renderProductImage(buyingProduct.images[0], "text-5xl")}
                          </div>
                          <div className="flex-1 space-y-4">
                              <div className="bg-white/5 p-6 rounded-3xl border border-white/5">
                                  <p className="text-slate-500 text-[10px] font-black uppercase mb-1">السعر الإجمالي</p>
                                  <div className="flex items-baseline gap-2">
                                      <span className="text-4xl font-black text-emerald-400 font-mono tracking-tighter">${currentPriceInfo.totalPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                                      {buyingProduct.offerPrice && <span className="text-sm text-slate-600 line-through font-mono">${((buyingProduct.price * purchaseQuantity)/currentPriceInfo.baseQty).toFixed(2)}</span>}
                                  </div>
                              </div>
                              <div className="flex items-center justify-between bg-black/20 p-5 rounded-2xl border border-white/5">
                                  <button onClick={() => setPurchaseQuantity(Math.max(buyingProduct.minQuantity || 1, purchaseQuantity - (buyingProduct.stepAmount || 1)))} className="p-3 bg-slate-800 text-white rounded-xl hover:bg-rose-600 transition-all"><Minus size={18}/></button>
                                  <div className="text-center flex-1 mx-2">
                                      <input 
                                        type="number" 
                                        value={purchaseQuantity.toString()} 
                                        onChange={(e) => {
                                            const val = parseInt(e.target.value);
                                            setPurchaseQuantity(isNaN(val) ? 0 : val);
                                        }}
                                        onBlur={() => {
                                            if (purchaseQuantity < (buyingProduct.minQuantity || 1)) {
                                                setPurchaseQuantity(buyingProduct.minQuantity || 1);
                                            }
                                        }}
                                        className="w-full bg-transparent text-2xl font-black text-white font-mono text-center outline-none appearance-none p-0 border-none focus:ring-0"
                                      />
                                      <p className="text-[9px] text-slate-500 font-black uppercase">الكمية</p>
                                  </div>
                                  <button onClick={() => setPurchaseQuantity(purchaseQuantity + (buyingProduct.stepAmount || 1))} className="p-3 bg-slate-800 text-white rounded-xl hover:bg-emerald-600 transition-all"><Plus size={18}/></button>
                              </div>
                          </div>
                      </div>

                      {buyingProduct.inputFields && buyingProduct.inputFields.length > 0 && (
                          <div className="space-y-6">
                              <h4 className="text-white font-black text-sm flex items-center gap-3">بيانات التنفيذ <Edit3 size={16} className="text-emerald-500" /></h4>
                              <div className="grid grid-cols-1 gap-6">
                                  {buyingProduct.inputFields.map(field => (
                                      <div key={field.id} className="space-y-2">
                                          <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest px-2">{field.label} {field.required && <span className="text-rose-500">*</span>}</label>
                                          <input 
                                              type={field.type === 'number' ? 'number' : 'text'}
                                              placeholder={field.placeholder}
                                              value={purchaseInputs[field.id] || ''}
                                              onChange={(e) => setPurchaseInputs({...purchaseInputs, [field.id]: e.target.value})}
                                              className="w-full bg-slate-900 border border-white/10 rounded-2xl p-5 text-white font-bold outline-none focus:border-emerald-500 transition-all shadow-inner"
                                          />
                                      </div>
                                  ))}
                              </div>
                          </div>
                      )}
                  </div>

                  <div className="p-10 border-t border-white/5 bg-slate-900/50 flex flex-col gap-6">
                      {isBalanceLow ? (
                        <div className="bg-gradient-to-br from-amber-500/10 to-orange-600/10 p-6 rounded-[2rem] border border-amber-500/20 text-center relative overflow-hidden animate-in zoom-in duration-300">
                           {/* Decorative background */}
                           <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl"></div>

                           <div className="relative z-10">
                             <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-amber-500/30 shadow-lg shadow-amber-500/10">
                                <Wallet size={32} className="text-amber-500 animate-pulse" />
                             </div>
                             <h4 className="text-white font-black text-lg mb-2">رصيدك غير كافٍ حالياً</h4>
                             <p className="text-slate-400 text-xs font-bold mb-6 max-w-sm mx-auto leading-relaxed">
                                أنت قريب جداً! تحتاج إلى <span className="text-emerald-400 border-b border-emerald-500/50">${(currentPriceInfo.totalPrice - totalBalanceUSD).toFixed(2)}</span> إضافية فقط لإتمام العملية.
                                اشحن محفظتك الآن ولا تفوت الفرصة!
                             </p>

                             {/* Gateway Previews */}
                             <div className="flex justify-center gap-6 mb-8">
                                {gateways.filter(g => g.isActive).slice(0, 3).map(gw => (
                                   <div key={gw.id} className="text-center opacity-80 group cursor-pointer hover:opacity-100 transition-opacity" onClick={() => onNavigate(View.TOPUP)}>
                                      <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-white/10 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform shadow-lg">
                                         {gw.image.startsWith('http') || gw.image.startsWith('data:') ? (
                                            <img src={gw.image} className="w-6 h-6 object-contain" />
                                         ) : (
                                            <span className="text-xl">{gw.image}</span>
                                         )}
                                      </div>
                                      <span className="text-[9px] text-slate-500 font-black">{gw.name.split(' ')[0]}</span>
                                   </div>
                                ))}
                                <div className="text-center opacity-50 hover:opacity-100 transition-opacity cursor-pointer flex flex-col items-center justify-center" onClick={() => onNavigate(View.TOPUP)}>
                                    <div className="w-12 h-12 rounded-2xl bg-slate-800/50 border border-white/5 flex items-center justify-center mb-2 border-dashed">
                                        <Plus size={16} className="text-slate-400"/>
                                    </div>
                                    <span className="text-[9px] text-slate-500 font-black">المزيد</span>
                                </div>
                             </div>

                             <button
                                onClick={() => onNavigate(View.TOPUP)}
                                className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black py-4 rounded-2xl font-black text-sm transition-all shadow-xl shadow-amber-900/20 active:scale-95 flex items-center justify-center gap-2 group"
                             >
                                <Zap size={18} fill="currentColor" className="group-hover:animate-bounce"/> اشحن رصيدك فوراً
                             </button>
                           </div>
                        </div>
                      ) : (
                        <>
                          {errorMessage && <div className="bg-rose-500/10 p-4 rounded-2xl border border-rose-500/20 text-rose-500 text-center text-xs font-black flex items-center justify-center gap-3"><XCircle size={16}/> {errorMessage}</div>}
                          <button 
                              onClick={handleConfirmPurchase} 
                              disabled={isPurchasing}
                              className={`w-full py-6 rounded-2xl font-black text-xl transition-all shadow-xl flex items-center justify-center gap-4 ${isPurchasing ? 'bg-slate-800 text-slate-600 grayscale cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/20 active:scale-95'}`}
                          >
                              {isPurchasing ? <Loader2 className="w-8 h-8 animate-spin" /> : <><Send size={24} className={language === 'ar' ? 'rtl:rotate-180' : ''}/> إرسال الطلب الآن</>}
                          </button>
                        </>
                      )}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Dashboard;
