
import React, { createContext, useContext, useEffect, useState } from 'react';

type AccentColor = 'emerald' | 'blue' | 'rose' | 'violet' | 'amber' | 'cyan' | 'custom';
type ThemeMode = 'dark' | 'light';

interface ThemeContextType {
  accent: AccentColor;
  setAccent: (color: AccentColor) => void;
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  customPrimary?: string;
  setCustomPrimary: (hex: string) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// Tailwind Color Palettes (50-950)
const PALETTES: Record<Exclude<AccentColor, 'custom'>, Record<number, string>> = {
  emerald: {
    50: '#ecfdf5', 100: '#d1fae5', 200: '#a7f3d0', 300: '#6ee7b7', 400: '#34d399',
    500: '#10b981', 600: '#059669', 700: '#047857', 800: '#065f46', 900: '#064e3b', 950: '#022c22'
  },
  blue: {
    50: '#eff6ff', 100: '#dbeafe', 200: '#bfdbfe', 300: '#93c5fd', 400: '#60a5fa',
    500: '#3b82f6', 600: '#2563eb', 700: '#1d4ed8', 800: '#1e40af', 900: '#1e3a8a', 950: '#172554'
  },
  rose: {
    50: '#fff1f2', 100: '#ffe4e6', 200: '#fecdd3', 300: '#fda4af', 400: '#fb7185',
    500: '#f43f5e', 600: '#e11d48', 700: '#be123c', 800: '#9f1239', 900: '#881337', 950: '#4c0519'
  },
  violet: {
    50: '#f5f3ff', 100: '#ede9fe', 200: '#ddd6fe', 300: '#c4b5fd', 400: '#a78bfa',
    500: '#8b5cf6', 600: '#7c3aed', 700: '#6d28d9', 800: '#5b21b6', 900: '#4c1d95', 950: '#2e1065'
  },
  amber: {
    50: '#fffbeb', 100: '#fef3c7', 200: '#fde68a', 300: '#fcd34d', 400: '#fbbf24',
    500: '#f59e0b', 600: '#d97706', 700: '#b45309', 800: '#92400e', 900: '#78350f', 950: '#451a03'
  },
  cyan: {
    50: '#ecfeff', 100: '#cffafe', 200: '#a5f3fc', 300: '#67e8f9', 400: '#22d3ee',
    500: '#06b6d4', 600: '#0891b2', 700: '#0e7490', 800: '#155e75', 900: '#164e63', 950: '#083344'
  }
};

const MODE_VARS = {
  dark: {
    '--bg-main': '#030712',
    '--bg-card': 'rgba(15, 23, 42, 0.7)',
    '--bg-card-solid': '#0f172a',
    '--text-primary': '#f8fafc',
    '--text-secondary': '#94a3b8',
    '--border-light': 'rgba(255, 255, 255, 0.08)',
    '--glass-blur': '16px'
  },
  light: {
    '--bg-main': '#f1f5f9',
    '--bg-card': 'rgba(255, 255, 255, 0.8)',
    '--bg-card-solid': '#ffffff',
    '--text-primary': '#0f172a',
    '--text-secondary': '#475569',
    '--border-light': 'rgba(0, 0, 0, 0.05)',
    '--glass-blur': '12px'
  }
};

// Helper to generate a simple palette from a single hex
function generatePalette(hex: string) {
    return {
        50: hex + '10', 100: hex + '20', 200: hex + '30', 300: hex + '50', 400: hex + '80',
        500: hex, 600: hex + 'CC', 700: hex + 'AA', 800: hex + '88', 900: hex + '66', 950: hex + '44'
    };
}

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [accent, setAccent] = useState<AccentColor>(() => {
    return (localStorage.getItem('horizon_theme_accent') as AccentColor) || 'emerald';
  });

  const [mode, setMode] = useState<ThemeMode>(() => {
    return (localStorage.getItem('horizon_theme_mode') as ThemeMode) || 'dark';
  });

  const [customPrimary, setCustomPrimary] = useState<string>(() => {
    return localStorage.getItem('horizon_theme_custom_hex') || '#10b981';
  });

  useEffect(() => {
    const root = document.documentElement;
    
    // Update Accent Colors
    let colors;
    if (accent === 'custom' && customPrimary) {
        colors = generatePalette(customPrimary);
    } else {
        colors = PALETTES[accent as Exclude<AccentColor, 'custom'>];
    }

    Object.entries(colors).forEach(([shade, value]) => {
      root.style.setProperty(`--color-primary-${shade}`, value as string);
    });

    // Update Mode Variables
    const modeVars = MODE_VARS[mode];
    Object.entries(modeVars).forEach(([key, value]) => {
      root.style.setProperty(key, value as string);
    });

    localStorage.setItem('horizon_theme_accent', accent);
    localStorage.setItem('horizon_theme_mode', mode);
    localStorage.setItem('horizon_theme_custom_hex', customPrimary);
  }, [accent, mode, customPrimary]);

  return (
    <ThemeContext.Provider value={{ accent, setAccent, mode, setMode, customPrimary, setCustomPrimary }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within a ThemeProvider');
  return context;
};
