import React, { useState, useEffect, useMemo, useRef } from 'react';
import { User, TransactionType, TransactionStatus, View, GameConfig } from '../types';
/* Added comment above fix: Added Plus to imports to fix "Cannot find name 'Plus'" error */
import { 
  Swords, Timer, Users, Trophy, Coins, Zap, ShieldCheck, 
  TrendingUp, Star, Crown, AlertTriangle, Play, Loader2,
  Flame, Target, ArrowUp, BarChart3, Activity, Heart, Sparkles, Plus
} from 'lucide-react';

interface ArenDBet {
  userId: string;
  userName: string;
  avatar?: string;
  amount: number;
  timestamp: number;
  winProbability: number;
}

interface ArenDGameProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
  onAddTransaction: (tx: any) => void;
  onNavigate: (view: View) => void;
  gameConfig: GameConfig;
}

const ArenDGame: React.FC<ArenDGameProps> = ({ user, onUpdateUser, onAddTransaction, onNavigate, gameConfig }) => {
  const [gameState, setGameState] = useState<'LOBBY' | 'WAITING' | 'BATTLE' | 'RESULT'>('WAITING');
  const [countdown, setCountdown] = useState(20);
  const [betAmount, setBetAmount] = useState('10');
  const [currentBets, setCurrentBets] = useState<ArenDBet[]>([]);
  const [winner, setWinner] = useState<ArenDBet | null>(null);
  const [lastResults, setLastResults] = useState<{winnerName: string, amount: number}[]>([]);
  const [isJoining, setIsJoining] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentWallet = user.wallets.find(w => w.currency === 'USD');
  const balance = currentWallet?.balance || 0;

  const totalPot = useMemo(() => currentBets.reduce((acc, b) => acc + b.amount, 0), [currentBets]);

  // Simulation: Add random bots to make the game feel alive
  useEffect(() => {
    if (gameState === 'WAITING' && countdown > 5 && Math.random() > 0.8) {
      const bots = ["CryptoKing", "NightWolf", "EliteGamer", "Sniper_X", "Sultan_Gold"];
      const botName = bots[Math.floor(Math.random() * bots.length)];
      const botBet: ArenDBet = {
        userId: `bot_${Date.now()}`,
        userName: botName,
        amount: [10, 20, 50, 100][Math.floor(Math.random() * 4)],
        timestamp: Date.now(),
        winProbability: 0
      };
      if (!currentBets.some(b => b.userName === botName)) {
        setCurrentBets(prev => [...prev, botBet]);
      }
    }
  }, [countdown, gameState]);

  // Game Loop
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (gameState === 'WAITING') {
      if (countdown > 0) {
        timer = setTimeout(() => setCountdown(prev => +(prev - 0.1).toFixed(1)), 100);
      } else {
        startBattle();
      }
    } else if (gameState === 'RESULT') {
      timer = setTimeout(() => {
        setGameState('WAITING');
        setCountdown(20);
        setCurrentBets([]);
        setWinner(null);
      }, 6000);
    }
    return () => clearTimeout(timer);
  }, [gameState, countdown]);

  const startBattle = () => {
    if (currentBets.length === 0) {
      setCountdown(20);
      return;
    }
    setGameState('BATTLE');
    setTimeout(() => calculateWinner(), 4000);
  };

  const calculateWinner = () => {
    if (currentBets.length === 0) return;

    // Logic: Single player = loss
    if (currentBets.length === 1) {
      setWinner(null);
      setGameState('RESULT');
      return;
    }

    // Smart Probability: Calculate weighted chances
    const winnerIdx = Math.floor(Math.random() * currentBets.length);
    const winObj = currentBets[winnerIdx];
    
    // Payout Logic: 5% house, 70% winner, 30% losers
    const houseFee = totalPot * 0.05;
    const netPot = totalPot - houseFee;
    const winnerPrize = netPot * 0.70;
    const losersTotalPool = netPot * 0.30;

    setWinner(winObj);
    setGameState('RESULT');
    setLastResults(prev => [{winnerName: winObj.userName, amount: winnerPrize}, ...prev].slice(0, 5));

    // Update Current User if won or was a loser
    if (currentBets.some(b => b.userId === user.id)) {
      const isUserWinner = winObj.userId === user.id;
      let finalUpdateAmount = 0;
      
      if (isUserWinner) {
        finalUpdateAmount = winnerPrize;
        onAddTransaction({
           id: `arend_w_${Date.now()}`,
           type: 'AREND_WIN',
           amount: winnerPrize,
           currency: 'USD',
           description: 'فوز في حلبة اريند 🏆',
           status: 'COMPLETED',
           date: new Date().toISOString()
        });
      } else {
        // user lost, gets share of 30%
        const loserCount = currentBets.length - 1;
        finalUpdateAmount = losersTotalPool / loserCount;
        onAddTransaction({
           id: `arend_c_${Date.now()}`,
           type: 'AREND_COMPENSATION',
           amount: finalUpdateAmount,
           currency: 'USD',
           description: 'مكافأة ترضية اريند 🎁',
           status: 'COMPLETED',
           date: new Date().toISOString()
        });
      }

      const newXP = user.xp + 50;
      const newLevel = Math.floor(newXP / 1000) + 1;
      const updatedWallets = user.wallets.map(w => 
        w.currency === 'USD' ? { ...w, balance: w.balance + finalUpdateAmount } : w
      );
      onUpdateUser({ ...user, wallets: updatedWallets, xp: newXP, level: newLevel });
    }
  };

  const handleJoin = async () => {
    const amount = parseFloat(betAmount);
    if (amount > balance) return;
    setIsJoining(true);

    // Deduct bet immediately
    const updatedWallets = user.wallets.map(w => 
        w.currency === 'USD' ? { ...w, balance: w.balance - amount } : w
    );
    onUpdateUser({ ...user, wallets: updatedWallets });

    onAddTransaction({
        id: `arend_b_${Date.now()}`,
        type: 'AREND_BET',
        amount: amount,
        currency: 'USD',
        description: 'رهان في حلبة اريند ⚔️',
        status: 'COMPLETED',
        date: new Date().toISOString()
    });

    const myBet: ArenDBet = {
      userId: user.id,
      userName: user.name,
      avatar: user.avatar,
      amount,
      timestamp: Date.now(),
      winProbability: 0
    };

    setCurrentBets(prev => [...prev, myBet]);
    setIsJoining(false);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-1000">
      
      {/* Top HUD: Stats & Economy */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="glass-card p-6 rounded-[2rem] border-white/5 bg-[#120a24]/60 flex items-center gap-5 group hover:border-purple-500/30 transition-all">
              <div className="w-12 h-12 bg-purple-500/20 rounded-2xl flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform shadow-lg shadow-purple-500/10"><Crown size={24}/></div>
              <div>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-0.5">Arena Rank</p>
                  <h4 className="text-white font-black text-lg flex items-center gap-2">LVL {user.level} <span className="text-[10px] text-purple-400">Elite</span></h4>
              </div>
          </div>
          <div className="glass-card p-6 rounded-[2rem] border-white/5 bg-[#120a24]/60 flex items-center gap-5 group hover:border-emerald-500/30 transition-all">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-400"><TrendingUp size={24}/></div>
              <div>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-0.5">Win Probability</p>
                  <h4 className="text-emerald-400 font-mono font-black text-lg">{(user.winRate || 68)}%</h4>
              </div>
          </div>
          <div className="glass-card p-6 rounded-[2rem] border-white/5 bg-[#120a24]/60 md:col-span-2 flex justify-between items-center px-10 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-full bg-purple-600/5 blur-3xl group-hover:bg-purple-600/10 transition-all"></div>
              <div className="flex items-center gap-5 relative z-10">
                  <div className="w-14 h-14 bg-amber-500/20 rounded-2xl flex items-center justify-center text-amber-500 shadow-xl"><Zap size={28}/></div>
                  <div>
                      <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-0.5">Current Vault</p>
                      <h4 className="text-white font-black text-2xl font-mono tracking-tighter">${balance.toLocaleString()}</h4>
                  </div>
              </div>
              <button 
                onClick={() => onNavigate(View.TOPUP)}
                className="relative z-10 p-3 bg-purple-600 text-white rounded-xl shadow-lg shadow-purple-900/40 active:scale-90 transition-all"
              >
                <Plus size={20}/>
              </button>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Main Battle Zone */}
          <div className="lg:col-span-8 space-y-8">
              <div className="glass-card rounded-[4rem] p-12 md:p-20 border border-white/5 bg-gradient-to-br from-[#0a0514] to-[#020108] relative overflow-hidden flex flex-col items-center shadow-[0_50px_100px_rgba(0,0,0,0.8)]">
                  
                  {/* Visual Background FX */}
                  <div className={`absolute inset-0 opacity-20 transition-all duration-1000 ${gameState === 'BATTLE' ? 'bg-purple-600/20' : 'bg-transparent'}`}></div>
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-purple-500/5 rounded-full blur-[120px] pointer-events-none"></div>
                  
                  {gameState === 'WAITING' && (
                      <div className="text-center relative z-10 space-y-10 animate-in zoom-in duration-500">
                          <div className="relative inline-block">
                              <div className="w-44 h-44 rounded-full border-[12px] border-purple-500/10 flex items-center justify-center relative">
                                  <svg className="absolute inset-[-12px] w-[calc(100%+24px)] h-[calc(100%+24px)] transform -rotate-90">
                                      <circle cx="50%" cy="50%" r="48%" stroke="currentColor" strokeWidth="6" fill="transparent" className="text-purple-500" style={{strokeDasharray: '600', strokeDashoffset: `${600 * (1 - countdown/20)}`, transition: 'stroke-dashoffset 0.1s linear'}} />
                                  </svg>
                                  <div className="text-center">
                                      <p className="text-7xl font-mono font-black text-white">{Math.ceil(countdown)}</p>
                                      <p className="text-[10px] text-purple-400 font-black uppercase tracking-[0.3em] mt-1">Starting</p>
                                  </div>
                              </div>
                              <div className="absolute -top-4 -right-4 bg-amber-500 p-3 rounded-2xl text-black shadow-xl animate-bounce"><Timer size={24}/></div>
                          </div>

                          <div className="space-y-4">
                              <h2 className="text-3xl font-black text-white">بانتظار المقاتلين...</h2>
                              <p className="text-slate-500 font-bold max-w-sm mx-auto">راهن الآن للدخول في الحلبة. الفائز يأخذ النصيب الأكبر، والبقية يحصلون على تعويضات.</p>
                          </div>

                          <div className="flex gap-3 justify-center">
                              {currentBets.map((b, i) => (
                                  <div key={b.userId} className="w-12 h-12 rounded-2xl bg-slate-800 border-2 border-purple-500/30 overflow-hidden shadow-2xl animate-in fade-in slide-in-from-bottom-4" style={{animationDelay: `${i*0.1}s`}}>
                                      {b.avatar ? <img src={b.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-white font-black">{b.userName[0]}</div>}
                                  </div>
                              ))}
                              {[...Array(Math.max(0, 5 - currentBets.length))].map((_, i) => (
                                  <div key={i} className="w-12 h-12 rounded-2xl bg-slate-900/50 border border-dashed border-white/5 flex items-center justify-center text-slate-700"><Users size={16}/></div>
                              ))}
                          </div>
                      </div>
                  )}

                  {gameState === 'BATTLE' && (
                      <div className="text-center relative z-10 space-y-14 w-full animate-in fade-in">
                          <div className="flex justify-center items-center gap-12 md:gap-24">
                              <div className="flex flex-col items-center gap-6">
                                  <div className="w-32 h-32 rounded-[2.5rem] bg-slate-800 border-4 border-purple-500 shadow-[0_0_40px_rgba(168,85,247,0.3)] flex items-center justify-center overflow-hidden animate-pulse">
                                      <Swords size={64} className="text-purple-400" />
                                  </div>
                                  <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Randomizing Arena</span>
                              </div>
                          </div>
                          <div className="space-y-4">
                             <div className="h-2 w-full max-w-md mx-auto bg-slate-900 rounded-full overflow-hidden border border-white/5 shadow-inner">
                                 <div className="h-full bg-gradient-to-r from-purple-600 via-emerald-400 to-purple-600 w-full animate-shimmer"></div>
                             </div>
                             <p className="text-xl font-black text-white animate-pulse">جاري تحديد الفائز المحظوظ...</p>
                          </div>
                      </div>
                  )}

                  {gameState === 'RESULT' && (
                      <div className="text-center relative z-10 space-y-10 animate-in zoom-in duration-500">
                          {winner ? (
                             <>
                                <div className="relative inline-block">
                                    <div className="w-44 h-44 rounded-[3rem] bg-slate-800 border-4 border-emerald-500 shadow-[0_0_60px_rgba(16,185,129,0.4)] overflow-hidden">
                                        {winner.avatar ? <img src={winner.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-5xl font-black text-white">{winner.userName[0]}</div>}
                                    </div>
                                    <div className="absolute -top-6 -right-6 w-16 h-16 bg-amber-500 rounded-2xl flex items-center justify-center text-black shadow-2xl transform rotate-12"><Trophy size={32}/></div>
                                </div>
                                <div className="space-y-3">
                                    <h2 className="text-4xl font-black text-white">{winner.userName} هزم الحلبة!</h2>
                                    <div className="flex items-center justify-center gap-3">
                                        <div className="px-6 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                                            <span className="text-emerald-400 font-mono font-black text-2xl">+${(totalPot * 0.95 * 0.7).toFixed(2)}</span>
                                        </div>
                                        <span className="text-slate-500 font-bold uppercase text-[10px]">Net Prize</span>
                                    </div>
                                </div>
                                <div className="flex justify-center gap-2">
                                    {[...Array(5)].map((_, i) => <Star key={i} className="text-amber-500 fill-current w-5 h-5 animate-bounce" style={{animationDelay: `${i*0.1}s`}} />)}
                                </div>
                             </>
                          ) : (
                             <div className="flex flex-col items-center gap-6">
                                <div className="w-32 h-32 bg-rose-500/20 rounded-full flex items-center justify-center text-rose-500 border-4 border-rose-500/40 shadow-2xl shadow-rose-900/20"><AlertTriangle size={64}/></div>
                                <h2 className="text-3xl font-black text-white">لا يوجد فائز!</h2>
                                <p className="text-slate-500 font-bold max-w-sm">اللعب المنفرد غير مسموح. خسر اللاعب رهانه بالكامل لعدم وجود منافسين.</p>
                             </div>
                          )}
                      </div>
                  )}

              </div>

              {/* Live Bet Feed */}
              <div className="space-y-5">
                  <div className="flex justify-between items-center px-4">
                      <div className="flex items-center gap-3">
                          <Activity size={18} className="text-purple-500 animate-pulse" />
                          <h3 className="text-white font-black text-sm uppercase tracking-widest">Live Arena Feed</h3>
                      </div>
                      <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest bg-white/5 px-3 py-1 rounded-full">{currentBets.length} Active Warriors</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {currentBets.map(bet => (
                          <div key={bet.userId} className="glass-card p-5 rounded-[1.8rem] border border-white/5 bg-[#0a0514]/40 flex items-center justify-between group hover:border-purple-500/30 transition-all">
                              <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 rounded-2xl bg-slate-800 overflow-hidden relative border border-white/5">
                                      {bet.avatar ? <img src={bet.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-white font-black">{bet.userName[0]}</div>}
                                      <div className="absolute top-1 left-1 w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_5px_#10b981]"></div>
                                  </div>
                                  <div>
                                      <h4 className="text-white font-black text-sm">{bet.userName}</h4>
                                      <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">Warrior Class</p>
                                  </div>
                              </div>
                              <div className="text-left">
                                  <p className="text-purple-400 font-mono font-black text-lg">${bet.amount}</p>
                                  <div className="flex items-center justify-end gap-1 mt-0.5">
                                      <Flame size={10} className="text-amber-500" />
                                      <span className="text-[8px] text-slate-500 font-black uppercase">Staked</span>
                                  </div>
                              </div>
                          </div>
                      ))}
                      {currentBets.length === 0 && <div className="md:col-span-2 py-20 text-center opacity-30 text-xs font-black uppercase tracking-[0.4em]">Arena is quiet... join the battle!</div>}
                  </div>
              </div>
          </div>

          {/* Controls & Sidebar */}
          <div className="lg:col-span-4 space-y-8">
              
              {/* Betting Interface */}
              <div className="glass-card rounded-[3.5rem] border border-white/10 bg-[#0a0514]/80 shadow-[0_40px_80px_rgba(0,0,0,0.6)] overflow-hidden">
                  <div className="p-8 border-b border-white/5 flex justify-between items-center bg-white/[0.03]">
                      <div className="flex items-center gap-3">
                          <Target size={20} className="text-purple-500" />
                          <h4 className="text-white font-black text-xs uppercase tracking-widest">Wager Station</h4>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1 bg-purple-500/10 rounded-full border border-purple-500/20">
                          <Users size={14} className="text-purple-400" />
                          <span className="text-[10px] text-white font-mono font-black">{currentBets.length}</span>
                      </div>
                  </div>

                  <div className="p-8 space-y-8">
                      <div className="space-y-4">
                          <label className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] px-2 block">Stake Amount (USD)</label>
                          <div className="bg-[#020108] p-3 rounded-[2.5rem] border border-white/5 shadow-inner relative group focus-within:border-purple-500/30 transition-all">
                              <div className="flex items-center gap-4">
                                  <input 
                                      type="number" 
                                      value={betAmount} 
                                      onChange={e => setBetAmount(e.target.value)}
                                      className="flex-1 bg-transparent text-white text-4xl font-mono font-black text-center outline-none"
                                  />
                                  <div className="flex flex-col gap-1">
                                      <button onClick={() => setBetAmount((parseFloat(betAmount)*2).toString())} className="p-2 bg-white/5 hover:bg-white/10 rounded-lg text-slate-500 transition-all"><ArrowUp size={14}/></button>
                                      <button onClick={() => setBetAmount(Math.max(10, parseFloat(betAmount)/2).toString())} className="p-2 bg-white/5 hover:bg-white/10 rounded-lg text-slate-500 transition-all rotate-180"><ArrowUp size={14}/></button>
                                  </div>
                              </div>
                          </div>
                          <div className="grid grid-cols-4 gap-2">
                             {[10, 50, 100, 500].map(v => (
                                 <button key={v} onClick={() => setBetAmount(v.toString())} className={`py-3 rounded-xl text-[10px] font-black transition-all border ${betAmount === v.toString() ? 'bg-purple-600 border-purple-500 text-white' : 'bg-slate-900/50 border-white/5 text-slate-600 hover:text-white'}`}>+${v}</button>
                             ))}
                          </div>
                      </div>

                      <button 
                        onClick={handleJoin}
                        disabled={isJoining || gameState !== 'WAITING' || parseFloat(betAmount) > balance || currentBets.some(b => b.userId === user.id)}
                        className={`w-full py-7 rounded-[2rem] font-black text-xl transition-all shadow-2xl active:scale-[0.98] flex items-center justify-center gap-4 relative overflow-hidden group ${
                            isJoining || gameState !== 'WAITING' || parseFloat(betAmount) > balance || currentBets.some(b => b.userId === user.id)
                            ? 'bg-slate-800 text-slate-600 grayscale cursor-not-allowed border border-white/5 shadow-none'
                            : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-900/30'
                        }`}
                      >
                          {isJoining ? <Loader2 className="w-8 h-8 animate-spin" /> : currentBets.some(b => b.userId === user.id) ? 'Inside Arena' : <><Swords size={24}/> انضم للمعركة الآن</>}
                          {!isJoining && gameState === 'WAITING' && parseFloat(betAmount) <= balance && !currentBets.some(b => b.userId === user.id) && (
                              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-shimmer"></div>
                          )}
                      </button>
                      
                      <div className="bg-purple-500/5 p-4 rounded-2xl border border-purple-500/10 flex items-start gap-4">
                          <ShieldCheck size={18} className="text-purple-400 shrink-0 mt-0.5" />
                          <p className="text-[9px] text-slate-500 font-bold leading-relaxed">
                              نظام المنافسة العادل: يتم اقتطاع 5% كعمولة، 70% للفائز، و30% تُوزع كترضية للخاسرين لضمان عدم خروج أحد خالي الوفاض تماماً.
                          </p>
                      </div>
                  </div>
              </div>

              {/* Recent Hall of Fame */}
              <div className="glass-card p-8 rounded-[3rem] border border-white/5 bg-[#0a0514]/40 space-y-6">
                  <div className="flex items-center gap-3">
                      <div className="p-2 bg-amber-500/10 rounded-lg text-amber-500"><Crown size={16}/></div>
                      <h4 className="text-white font-black text-xs uppercase tracking-widest">Hall of Fame</h4>
                  </div>
                  <div className="space-y-3">
                      {lastResults.map((res, i) => (
                          <div key={i} className="flex justify-between items-center p-4 bg-white/[0.02] rounded-2xl border border-white/5 hover:bg-white/[0.05] transition-all">
                              <div className="flex items-center gap-3">
                                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_5px_#10b981]"></div>
                                  <span className="text-slate-300 font-black text-[11px]">{res.winnerName}</span>
                              </div>
                              <span className="text-emerald-400 font-mono font-black text-xs">+${res.amount.toFixed(2)}</span>
                          </div>
                      ))}
                      {lastResults.length === 0 && <div className="py-10 text-center opacity-20 text-[10px] font-black uppercase italic">Waiting for champions...</div>}
                  </div>
              </div>

              {/* Social/Community Widget */}
              <div className="bg-[#120a24] border border-purple-500/10 p-10 rounded-[3.5rem] relative overflow-hidden text-center">
                  <Sparkles className="w-12 h-12 text-purple-400 mx-auto mb-4 animate-pulse" />
                  <h5 className="text-white font-black text-sm uppercase tracking-widest mb-2">Arena Social</h5>
                  <p className="text-slate-500 text-[10px] font-bold leading-relaxed">تحدث مع بقية اللاعبين في الشات العام قبل بدء الجولة!</p>
              </div>

          </div>
      </div>
    </div>
  );
};

export default ArenDGame;
