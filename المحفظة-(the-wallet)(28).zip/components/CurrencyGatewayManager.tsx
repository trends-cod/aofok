
import React, { useState, useMemo } from 'react';
import { CurrencyConfig, ManualGateway } from '../types';
import { X, Plus, Edit2, Trash2, Save, Landmark, Package, Image, FileText, ArrowDown, ArrowUp, Link, Unlink, ToggleLeft, ToggleRight, Upload, Building2, User, Hash, Globe, Zap } from 'lucide-react';

interface CurrencyGatewayManagerProps {
  currency: CurrencyConfig;
  allGateways: ManualGateway[];
  onClose: () => void;
  onUpdateGateway: (gateway: ManualGateway) => void;
  onAddGateway: (gateway: ManualGateway) => void;
  onDeleteGateway: (id: string) => void;
}

const CurrencyGatewayManager: React.FC<CurrencyGatewayManagerProps> = ({
  currency,
  allGateways,
  onClose,
  onUpdateGateway,
  onAddGateway,
  onDeleteGateway
}) => {
  const [editingGateway, setEditingGateway] = useState<ManualGateway | null>(null);

  const sortedGateways = useMemo(() => {
    return [...allGateways].sort((a, b) => {
        const isALinked = a.supportedCurrencies?.includes(currency.code);
        const isBLinked = b.supportedCurrencies?.includes(currency.code);
        if (isALinked && !isBLinked) return -1;
        if (!isALinked && isBLinked) return 1;
        return (a.order || 0) - (b.order || 0);
    });
  }, [allGateways, currency.code]);

  const handleToggleLink = (gateway: ManualGateway) => {
    let supported = gateway.supportedCurrencies || [];
    if (supported.includes(currency.code)) {
        supported = supported.filter(c => c !== currency.code);
    } else {
        supported = [...supported, currency.code];
    }
    onUpdateGateway({ ...gateway, supportedCurrencies: supported });
  };

  const handleAddNew = () => {
    setEditingGateway({
      id: `gw_${Date.now()}`,
      name: '',
      image: '🏦',
      instructions: '',
      isActive: true,
      order: (allGateways.length + 1) * 10,
      supportedCurrencies: [currency.code]
    });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingGateway) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditingGateway({ ...editingGateway, image: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!editingGateway) return;
    const isNew = !allGateways.some(g => g.id === editingGateway.id);
    if (isNew) {
      onAddGateway(editingGateway);
    } else {
      onUpdateGateway(editingGateway);
    }
    setEditingGateway(null);
  };

  const toggleBankDetails = () => {
      if (!editingGateway) return;
      if (editingGateway.bankDetails) {
          const { bankDetails, ...rest } = editingGateway;
          setEditingGateway(rest);
      } else {
          setEditingGateway({
              ...editingGateway,
              bankDetails: {
                  bankName: '',
                  accountHolder: '',
                  accountNumber: '',
                  iban: '',
                  swiftCode: ''
              }
          });
      }
  };

  const updateBankDetail = (field: keyof NonNullable<ManualGateway['bankDetails']>, value: string) => {
      if (!editingGateway || !editingGateway.bankDetails) return;
      setEditingGateway({
          ...editingGateway,
          bankDetails: {
              ...editingGateway.bankDetails,
              [field]: value
          }
      });
  };

  const renderForm = () => {
    if (!editingGateway) return null;
    return (
        <div className="absolute inset-0 bg-[#020617]/95 backdrop-blur-sm p-8 flex flex-col animate-in fade-in duration-300 z-50">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black text-white">{editingGateway.id.startsWith('gw_') && !allGateways.some(g => g.id === editingGateway.id) ? 'إضافة بوابة جديدة للنظام' : 'تعديل بيانات البوابة'}</h3>
                <button onClick={() => setEditingGateway(null)} className="p-2 bg-white/5 rounded-full hover:bg-white/10 text-white"><X className="w-5 h-5" /></button>
            </div>
            
            <div className="flex-1 space-y-6 overflow-y-auto pr-2 scrollbar-hide">
                <div className="flex gap-4 items-start">
                    <div className="w-24 h-24 rounded-2xl bg-slate-900 border border-white/10 flex items-center justify-center text-4xl shrink-0 overflow-hidden relative group">
                        {editingGateway.image.startsWith('http') || editingGateway.image.startsWith('data:') ? (
                            <img src={editingGateway.image} className="w-full h-full object-contain p-2" />
                        ) : (
                            <span>{editingGateway.image}</span>
                        )}
                        <label className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                            <Upload className="w-6 h-6 text-white" />
                            <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                        </label>
                    </div>
                    <div className="flex-1 space-y-4">
                        <div>
                            <label className="text-[10px] text-slate-500 font-black uppercase mb-1 block">اسم البوابة</label>
                            <input
                                type="text"
                                placeholder="مثلاً: تحويل بنكي (دولي)"
                                value={editingGateway.name}
                                onChange={(e) => setEditingGateway({ ...editingGateway, name: e.target.value })}
                                className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-3 text-white font-bold focus:border-emerald-500 outline-none"
                            />
                        </div>
                        <div>
                            <label className="text-[10px] text-slate-500 font-black uppercase mb-1 block">الأيقونة أو الرابط</label>
                            <input
                                type="text"
                                placeholder="Emoji أو URL"
                                value={editingGateway.image}
                                onChange={(e) => setEditingGateway({ ...editingGateway, image: e.target.value })}
                                className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-3 text-white focus:border-emerald-500 outline-none font-mono text-xs"
                            />
                        </div>
                    </div>
                </div>

                <div>
                    <label className="text-[10px] text-slate-500 font-black uppercase mb-1 block">تعليمات الدفع</label>
                    <textarea
                        placeholder="أدخل التعليمات، كل سطر سيظهر كبند منفصل للعميل..."
                        value={editingGateway.instructions}
                        onChange={(e) => setEditingGateway({ ...editingGateway, instructions: e.target.value })}
                        className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 text-white h-40 resize-none focus:border-emerald-500 outline-none font-medium leading-relaxed"
                    />
                </div>

                {/* Structured Bank Details Toggle */}
                <div className="p-4 rounded-2xl border border-white/5 bg-slate-900/30">
                    <div className="flex justify-between items-center mb-4">
                        <label className="flex items-center gap-2 text-white font-bold text-sm cursor-pointer">
                            <Building2 size={16} className="text-blue-400" />
                            تفعيل وضع "تحويل بنكي"
                        </label>
                        <button 
                            onClick={toggleBankDetails}
                            className={`text-2xl transition-colors ${editingGateway.bankDetails ? 'text-emerald-500' : 'text-slate-600'}`}
                        >
                            {editingGateway.bankDetails ? <ToggleRight /> : <ToggleLeft />}
                        </button>
                    </div>
                    
                    {editingGateway.bankDetails && (
                        <div className="space-y-3 animate-in fade-in">
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="text-[9px] text-slate-500 uppercase mb-1 block">اسم البنك</label>
                                    <div className="relative">
                                        <Building2 size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600"/>
                                        <input type="text" value={editingGateway.bankDetails.bankName} onChange={e => updateBankDetail('bankName', e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-lg p-2 pr-8 text-xs text-white" placeholder="البنك الأهلي" />
                                    </div>
                                </div>
                                <div>
                                    <label className="text-[9px] text-slate-500 uppercase mb-1 block">اسم صاحب الحساب</label>
                                    <div className="relative">
                                        <User size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600"/>
                                        <input type="text" value={editingGateway.bankDetails.accountHolder} onChange={e => updateBankDetail('accountHolder', e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-lg p-2 pr-8 text-xs text-white" placeholder="شركة..." />
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label className="text-[9px] text-slate-500 uppercase mb-1 block">رقم الحساب</label>
                                <div className="relative">
                                    <Hash size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600"/>
                                    <input type="text" value={editingGateway.bankDetails.accountNumber} onChange={e => updateBankDetail('accountNumber', e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-lg p-2 pr-8 text-xs text-white font-mono" placeholder="123456..." />
                                </div>
                            </div>
                            <div>
                                <label className="text-[9px] text-slate-500 uppercase mb-1 block">IBAN</label>
                                <div className="relative">
                                    <Globe size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600"/>
                                    <input type="text" value={editingGateway.bankDetails.iban} onChange={e => updateBankDetail('iban', e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-lg p-2 pr-8 text-xs text-white font-mono" placeholder="SA..." />
                                </div>
                            </div>
                            <div>
                                <label className="text-[9px] text-slate-500 uppercase mb-1 block">Swift/BIC (اختياري)</label>
                                <div className="relative">
                                    <Zap size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600"/>
                                    <input type="text" value={editingGateway.bankDetails.swiftCode || ''} onChange={e => updateBankDetail('swiftCode', e.target.value)} className="w-full bg-slate-950 border border-white/10 rounded-lg p-2 pr-8 text-xs text-white font-mono" placeholder="ABCD..." />
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-[10px] text-slate-500 font-black uppercase mb-1 block">ترتيب العرض</label>
                        <input
                            type="number"
                            value={editingGateway.order}
                            onChange={(e) => setEditingGateway({ ...editingGateway, order: parseInt(e.target.value) || 0 })}
                            className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-3 text-white focus:border-emerald-500 outline-none"
                        />
                    </div>
                    <div className="flex items-center gap-3 pt-6">
                        <input 
                            type="checkbox" 
                            checked={editingGateway.isActive} 
                            onChange={e => setEditingGateway({...editingGateway, isActive: e.target.checked})}
                            className="w-6 h-6 rounded bg-slate-800 border-slate-600 text-emerald-600 focus:ring-emerald-500"
                        />
                        <span className="text-sm font-bold text-white">بوابة نشطة</span>
                    </div>
                </div>
            </div>

            <div className="mt-6 flex gap-4 pt-6 border-t border-white/5">
                <button onClick={() => setEditingGateway(null)} className="flex-1 bg-white/5 hover:bg-white/10 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all">إلغاء</button>
                <button onClick={handleSave} className="flex-[2] bg-emerald-600 hover:bg-emerald-500 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all">
                    <Save className="w-5 h-5" /> حفظ بيانات البوابة
                </button>
            </div>
        </div>
    );
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-lg flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="glass-card w-full max-w-2xl max-h-[85vh] rounded-[3rem] border border-white/10 flex flex-col shadow-2xl relative overflow-hidden">
        <div className="p-8 border-b border-white/5 flex justify-between items-center bg-slate-900/50">
          <div>
            <h2 className="text-xl font-black text-white">إدارة بوابات الدفع</h2>
            <p className="text-slate-400 font-bold text-xs mt-1">تحديد البوابات المتاحة لعملة <span className="text-amber-400">{currency.name} ({currency.code})</span></p>
          </div>
          <button onClick={onClose} className="p-2 bg-white/5 rounded-full hover:bg-white/10 text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-3 bg-[#0f172a]/30 scrollbar-hide">
          {sortedGateways.length === 0 && (
              <div className="text-center py-10 opacity-50">
                  <Landmark className="w-12 h-12 mx-auto mb-2" />
                  <p>لا توجد بوابات دفع معرفة في النظام.</p>
              </div>
          )}
          {sortedGateways.map(gw => {
            const isLinked = gw.supportedCurrencies?.includes(currency.code);
            return (
              <div 
                key={gw.id} 
                className={`rounded-2xl p-4 flex items-center gap-4 border transition-all duration-300 ${isLinked ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-slate-900/50 border-white/5 hover:border-white/10 opacity-70 hover:opacity-100'}`}
              >
                <div className={`p-3 rounded-xl text-2xl flex items-center justify-center w-14 h-14 shrink-0 ${isLinked ? 'bg-emerald-500/10' : 'bg-slate-800'}`}>
                    {gw.image.startsWith('http') || gw.image.startsWith('data:') ? <img src={gw.image} className="w-full h-full object-contain"/> : gw.image}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                      <p className={`font-bold truncate ${isLinked ? 'text-white' : 'text-slate-400'}`}>{gw.name}</p>
                      {isLinked && <span className="text-[9px] bg-emerald-500 text-black px-2 py-0.5 rounded-full font-black">نشط</span>}
                  </div>
                  <p className="text-[10px] text-slate-500 truncate">{gw.instructions.substring(0, 50)}...</p>
                  {gw.bankDetails && <p className="text-[9px] text-blue-400 font-bold mt-1">🏦 تحويل بنكي</p>}
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => handleToggleLink(gw)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-black transition-all border ${isLinked ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500' : 'bg-slate-800 hover:bg-slate-700 text-slate-400 border-white/5'}`}
                  >
                    {isLinked ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                    {isLinked ? 'مفعل' : 'تعطيل'}
                  </button>

                  <div className="w-[1px] h-6 bg-white/10 mx-1"></div>

                  <button onClick={() => setEditingGateway(gw)} className="p-2 text-slate-500 hover:text-blue-400 transition-colors bg-white/5 rounded-lg hover:bg-blue-500/10" title="تعديل بيانات البوابة">
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => onDeleteGateway(gw.id)} className="p-2 text-slate-500 hover:text-rose-400 transition-colors bg-white/5 rounded-lg hover:bg-rose-500/10" title="حذف البوابة نهائياً">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-6 border-t border-white/5 bg-slate-900/50">
          <button onClick={handleAddNew} className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 hover:border-slate-600 transition-all py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 active:scale-95">
            <Plus className="w-5 h-5" /> إنشاء بوابة دفع جديدة (Global)
          </button>
        </div>

        {renderForm()}
      </div>
    </div>
  );
};

export default CurrencyGatewayManager;
