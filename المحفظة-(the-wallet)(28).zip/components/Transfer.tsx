
import React, { useState, useMemo, useEffect } from 'react';
import { User, Currency, CurrencyConfig, Transaction, TransactionStatus, TransferTypeConfig, View } from '../types';
import { 
  Send, Copy, Phone, User as UserIcon, MapPin, CheckCircle, Loader2, 
  Globe, Flag, Wallet, Info, AlertCircle, Check,
  History, Search, ShieldCheck, Zap, X, FileText, QrCode, FileDown, Sparkles
} from 'lucide-react';

interface TransferProps {
  user: User;
  onTransfer: (amount: number, currency: Currency, recipient: string, note: string) => Promise<boolean>;
  transferFeePercentage: number;
  currencies: CurrencyConfig[];
  transactions: Transaction[];
  transferTypes: TransferTypeConfig[];
  onNavigate: (view: View, params?: any) => void;
  allUsers?: User[];
}

const Transfer: React.FC<TransferProps> = ({ user, onTransfer, transferFeePercentage, currencies, transactions, transferTypes: initialTransferTypes, onNavigate, allUsers = [] }) => {
  const [activeTab, setActiveTab] = useState('INTERNAL');
  const [status, setStatus] = useState<'IDLE' | 'PROCESSING' | 'SUCCESS' | 'ERROR'>('IDLE');
  const [selectedProof, setSelectedProof] = useState<string | null>(null);
  
  // Search logic
  const [searchCode, setSearchCode] = useState('');
  const [foundUser, setFoundUser] = useState<User | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [showQRModal, setShowQRModal] = useState<User | null>(null);

  // General Form State
  const [beneficiaryName, setBeneficiaryName] = useState('');
  const [beneficiaryPhone, setBeneficiaryPhone] = useState('');
  const [destination, setDestination] = useState('');
  const [sendCurrency, setSendCurrency] = useState<string>(currencies[0]?.code || 'USD');
  const [sendAmount, setSendAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Reset errors when tab changes
  useEffect(() => {
    setErrors({});
    setBeneficiaryName('');
    setBeneficiaryPhone('');
    setDestination('');
    setSendAmount('');
    setNotes('');
    setSearchCode('');
    setFoundUser(null);
  }, [activeTab]);

  // Clear specific error on input change
  const clearError = (field: string) => {
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleSearchUser = () => {
    if (!searchCode.trim()) return;
    setIsSearching(true);
    setTimeout(() => {
        const result = allUsers.find(u => u.userCode.toUpperCase() === searchCode.toUpperCase());
        setFoundUser(result || null);
        if (result) {
            setBeneficiaryName(result.name);
            setDestination(result.userCode);
            setBeneficiaryPhone(result.phone || '');
            clearError('beneficiaryName');
            clearError('destination');
        }
        setIsSearching(false);
    }, 600);
  };

  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [pendingTransferData, setPendingTransferData] = useState<{
      amount: number;
      fee: number;
      total: number;
      currency: string;
      recipient: string;
      destination: string;
      note: string;
  } | null>(null);

  const [lastTransfer, setLastTransfer] = useState<{
    amount: string;
    currency: string;
    recipient: string;
    type: string;
  } | null>(null);

  const userTransfers = useMemo(() => {
    return transactions
      .filter(tx => tx.userId === user.id)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transactions, user.id]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    const amountNum = parseFloat(sendAmount);

    if (!sendAmount) {
        newErrors.amount = 'يرجى إدخال مبلغ التحويل';
    } else if (isNaN(amountNum) || amountNum <= 0) {
        newErrors.amount = 'يرجى إدخال مبلغ صحيح أكبر من صفر';
    } else {
        const wallet = user.wallets.find(w => w.currency === sendCurrency);
        const fee = amountNum * (transferFeePercentage / 100);
        const total = amountNum + fee;
        if (!wallet || wallet.balance < total) {
            newErrors.amount = `رصيدك غير كافٍ لهذه العملية (المطلوب: ${total.toLocaleString()} ${sendCurrency})`;
        }
    }

    if (!beneficiaryName.trim()) {
        newErrors.beneficiaryName = 'اسم المستفيد مطلوب';
    } else if (beneficiaryName.trim().length < 3) {
        newErrors.beneficiaryName = 'الاسم قصير جداً';
    }

    if (!destination.trim()) {
        newErrors.destination = activeTab === 'INTERNAL' ? 'كود المستخدم مطلوب' : 'الوجهة/المدينة مطلوبة';
    }

    if (!beneficiaryPhone.trim()) {
        newErrors.beneficiaryPhone = 'رقم الهاتف مطلوب';
    } else if (!/^[+]?[\d\s-]{8,}$/.test(beneficiaryPhone)) {
        newErrors.beneficiaryPhone = 'صيغة رقم الهاتف غير صحيحة';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
        let finalAmount = Number(sendAmount);
        const fee = finalAmount * (transferFeePercentage / 100);
        const total = finalAmount + fee;

        setPendingTransferData({
            amount: finalAmount, 
            fee, 
            total, 
            currency: sendCurrency, 
            recipient: beneficiaryName, 
            destination: destination,
            note: notes
        });
        setShowConfirmModal(true);
    }
  };

  const handleFinalConfirm = async () => {
    if (!pendingTransferData) return;
    setShowConfirmModal(false);
    setStatus('PROCESSING');
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    const success = await onTransfer(pendingTransferData.amount, pendingTransferData.currency, pendingTransferData.recipient, pendingTransferData.note);
    if (success) {
        setLastTransfer({ amount: pendingTransferData.amount.toString(), currency: pendingTransferData.currency, recipient: pendingTransferData.recipient, type: transferTypes.find(t => t.id === activeTab)?.label || '' });
        setStatus('SUCCESS');
        // Reset form
        setBeneficiaryName(''); setSendAmount(''); setBeneficiaryPhone(''); setNotes(''); setDestination(''); setFoundUser(null); setSearchCode('');
    } else {
        setStatus('ERROR');
    }
  };

  const transferTypes = initialTransferTypes.length > 0 ? initialTransferTypes : [
    { id: 'INTERNAL', label: 'تحويل داخلي', icon: Send, description: 'تحويل رصيد لمستخدم آخر باستخدام كود المستخدم', isActive: true, order: 1, formType: 'INTERNAL' as const },
    { id: 'SYRIAN', label: 'حوالة سوريا', icon: Flag, description: 'تسليم ليرة سورية', isActive: true, order: 2, formType: 'SYRIAN' as const },
    { id: 'INTERNATIONAL', label: 'حوالة دولية', icon: Globe, description: 'ويسترن يونيون / موني جرام', isActive: true, order: 3, formType: 'INTERNATIONAL' as const },
    { id: 'HISTORY', label: 'سجل الحوالات', icon: History, description: 'تتبع الحالات والطلبات', isActive: true, order: 4, formType: 'INTERNAL' as const },
  ];

  if (status === 'SUCCESS' && lastTransfer) {
    return (
     <div className="max-w-2xl mx-auto text-center p-12 glass-card rounded-[3.5rem] animate-in zoom-in duration-500 border-emerald-500/20 shadow-2xl mt-10">
        <div className="w-24 h-24 bg-emerald-500/10 rounded-full flex items-center justify-center mb-8 mx-auto border border-emerald-500/20">
            <CheckCircle className="w-12 h-12 text-emerald-500" />
        </div>
        <h2 className="text-3xl font-black text-white mb-2">تم الإرسال بنجاح</h2>
        <p className="text-slate-400 mb-8">تم إرسال {lastTransfer.amount} {lastTransfer.currency} إلى {lastTransfer.recipient}</p>
        <button onClick={() => {setStatus('IDLE'); setActiveTab('HISTORY');}} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-5 rounded-2xl font-black transition-all active:scale-95 shadow-xl">مشاهدة السجل</button>
     </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-8 h-full pb-20">
        
        {/* Sidebar Navigation */}
        <div className="lg:w-80 flex flex-col gap-5 shrink-0">
            {transferTypes.map(type => {
                const Icon = typeof type.icon === 'string' ? Send : type.icon;
                return (
                    <button
                        key={type.id}
                        onClick={() => { setActiveTab(type.id); setStatus('IDLE'); setFoundUser(null); }}
                        className={`w-full flex items-center justify-between p-6 rounded-[2.5rem] transition-all duration-500 border ${
                            activeTab === type.id 
                            ? 'bg-emerald-500/10 border-emerald-500/50 shadow-[0_0_30px_rgba(16,185,129,0.1)]' 
                            : 'bg-[#0f172a]/40 border-white/5 hover:border-white/10 hover:bg-[#0f172a]/60'
                        }`}
                    >
                        <div className="flex flex-col text-right">
                            <h3 className={`font-black text-lg ${activeTab === type.id ? 'text-white' : 'text-slate-400'}`}>{type.label}</h3>
                            <p className={`text-[11px] font-bold mt-1 ${activeTab === type.id ? 'text-emerald-400' : 'text-slate-600'}`}>{type.description}</p>
                        </div>
                        <div className={`p-4 rounded-2xl transition-all duration-500 ${activeTab === type.id ? 'bg-emerald-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]' : 'bg-slate-800/50 text-slate-500'}`}>
                            <Icon size={24} />
                        </div>
                    </button>
                );
            })}
        </div>

        {/* Main Content Area */}
        <div className="flex-1 glass-card rounded-[3.5rem] overflow-hidden flex flex-col relative shadow-2xl border-white/5">
            
            {activeTab === 'HISTORY' ? (
                <div className="flex flex-col h-full animate-in fade-in duration-500">
                    <div className="p-10 border-b border-white/5 bg-slate-900/50 flex justify-between items-center">
                        <h3 className="text-2xl font-black text-white">سجل العمليات</h3>
                        <History className="w-8 h-8 text-slate-500" />
                    </div>
                    <div className="flex-1 overflow-y-auto p-8 space-y-4 scrollbar-hide">
                        {userTransfers.map(tx => (
                            <div key={tx.id} className="bg-[#0f172a]/60 p-6 rounded-[2rem] border border-white/5 flex flex-col gap-4 hover:bg-slate-900 transition-all">
                                <div className="flex justify-between items-center">
                                    <div className="text-right">
                                        <p className="text-white font-black">{tx.description.split('|')[0]}</p>
                                        <p className="text-[10px] text-slate-500 mt-1">{new Date(tx.date).toLocaleString()}</p>
                                    </div>
                                    <div className="text-left">
                                        <p className={`text-xl font-mono font-black ${tx.status === TransactionStatus.COMPLETED ? 'text-emerald-400' : 'text-slate-300'}`}>{tx.amount} {tx.currency}</p>
                                        <span className={`text-[8px] uppercase font-black px-2 py-0.5 rounded ${tx.status === TransactionStatus.COMPLETED ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-800 text-slate-500'}`}>{tx.status}</span>
                                    </div>
                                </div>
                                {tx.status === TransactionStatus.COMPLETED && tx.adminProofImage && (
                                    <div className="pt-4 border-t border-white/5 flex justify-end">
                                        <button 
                                            onClick={() => setSelectedProof(tx.adminProofImage || null)}
                                            className="px-5 py-2 bg-emerald-600/10 hover:bg-emerald-600 text-emerald-400 hover:text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all"
                                        >
                                            <FileDown size={14} /> عرض فاتورة التنفيذ
                                        </button>
                                    </div>
                                )}
                            </div>
                        ))}
                        {userTransfers.length === 0 && <div className="text-center py-20 text-slate-500 font-bold">لا يوجد سجل عمليات بعد</div>}
                    </div>
                </div>
            ) : (
                <>
                {/* Form Header */}
                <div className="p-10 border-b border-white/5 bg-slate-900/50 flex flex-col md:flex-row justify-between items-center gap-6">
                    <div>
                        <h3 className="text-3xl font-black text-white">{transferTypes.find(t => t.id === activeTab)?.label}</h3>
                        <p className="text-[11px] font-black text-slate-500 uppercase tracking-widest mt-2 flex items-center gap-2">
                           <ShieldCheck size={14} className="text-emerald-500"/> يرجى التأكد من بيانات المستلم بدقة عالية
                        </p>
                    </div>
                    
                    {/* User Search for Internal Transfers */}
                    {activeTab === 'INTERNAL' && (
                        <div className="w-full md:w-80 space-y-3">
                            <div className="relative group">
                                <input 
                                    type="text" 
                                    placeholder="ابحث عن مستخدم بالكود..." 
                                    value={searchCode}
                                    onChange={(e) => setSearchCode(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSearchUser()}
                                    className="w-full bg-slate-950 border border-white/10 rounded-2xl py-4 pr-12 pl-4 text-xs font-bold text-white focus:border-emerald-500 outline-none transition-all shadow-inner"
                                />
                                <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-emerald-500 w-4 h-4 transition-colors" />
                                <button onClick={handleSearchUser} className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-emerald-600/10 hover:bg-emerald-600 text-emerald-500 hover:text-white rounded-xl transition-all">
                                    {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                                </button>
                            </div>
                            
                            {/* Found User UI */}
                            {foundUser && (
                                <div 
                                    onClick={() => setShowQRModal(foundUser)}
                                    className="glass-card p-3 rounded-2xl border border-emerald-500/30 flex items-center gap-3 cursor-pointer hover:bg-emerald-500/10 transition-all animate-in slide-in-from-top-2 duration-300 group"
                                >
                                    <div className="w-10 h-10 rounded-xl bg-slate-800 border border-white/5 overflow-hidden group-hover:scale-105 transition-transform">
                                        {foundUser.avatar ? <img src={foundUser.avatar} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center text-white font-black">{foundUser.name[0]}</div>}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-white font-black text-[11px] truncate">{foundUser.name}</p>
                                        <p className="text-[9px] text-emerald-500 font-mono font-black">{foundUser.userCode}</p>
                                    </div>
                                    <div className="p-2 bg-white/5 rounded-lg text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-all shadow-lg">
                                        <QrCode size={14} />
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <div className="p-10 flex-1 overflow-y-auto scrollbar-hide space-y-10">
                    {/* Amount Calculator UI */}
                    <div className={`bg-[#020617]/40 p-10 rounded-[3rem] border transition-colors shadow-inner space-y-8 relative overflow-hidden ${errors.amount ? 'border-rose-500/50' : 'border-white/5'}`}>
                        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl"></div>
                        <div className="flex items-center gap-3 text-emerald-500 relative z-10">
                            <Zap size={18} className="animate-pulse" />
                            <label className="text-[11px] font-black uppercase tracking-widest">مبلغ التحويل والعملة</label>
                        </div>
                        <div className="flex flex-col md:flex-row gap-6 relative z-10">
                            <div className="flex-1 relative">
                                <input 
                                    type="number" 
                                    value={sendAmount} 
                                    onChange={e => { setSendAmount(e.target.value); clearError('amount'); }}
                                    className="w-full bg-[#030712] border border-white/10 rounded-[1.8rem] p-6 text-6xl font-black text-white outline-none focus:border-emerald-500/50 text-right dir-ltr"
                                    placeholder="0.00"
                                />
                                <span className="absolute left-8 top-1/2 -translate-y-1/2 text-slate-700 font-black text-xs uppercase tracking-widest pointer-events-none">Amount</span>
                            </div>
                            <div className="md:w-48">
                                <select 
                                    value={sendCurrency}
                                    onChange={e => setSendCurrency(e.target.value)}
                                    className="w-full h-full bg-slate-900 border border-white/10 rounded-[1.8rem] p-4 text-2xl font-black text-white outline-none text-center cursor-pointer shadow-2xl appearance-none hover:border-emerald-500/30 transition-colors"
                                >
                                    {currencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                                </select>
                            </div>
                        </div>
                        {errors.amount && (
                            <div className="flex items-center gap-2 text-rose-500 text-xs font-bold animate-in slide-in-from-top-1">
                                <AlertCircle size={14}/> {errors.amount}
                            </div>
                        )}
                    </div>

                    {/* Recipient Fields */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">اسم المستفيد الكامل</label>
                            <div className="relative group">
                                <input 
                                    type="text" 
                                    value={beneficiaryName} 
                                    onChange={e => { setBeneficiaryName(e.target.value); clearError('beneficiaryName'); }}
                                    className={`w-full bg-slate-900/60 border rounded-2xl p-5 text-white font-bold outline-none transition-all shadow-inner ${errors.beneficiaryName ? 'border-rose-500 focus:border-rose-600' : 'border-white/10 focus:border-emerald-500/50'}`}
                                    placeholder="الاسم كما في الهوية" 
                                />
                                <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-emerald-500 w-4 h-4 transition-colors"/>
                            </div>
                            {errors.beneficiaryName && <p className="text-rose-500 text-[10px] font-bold px-4">{errors.beneficiaryName}</p>}
                        </div>
                        <div className="space-y-4">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">{activeTab === 'INTERNAL' ? 'كود المستخدم (User ID)' : 'الوجهة / المدينة'}</label>
                            <div className="relative group">
                                <input 
                                    type="text" 
                                    value={destination} 
                                    onChange={e => { setDestination(e.target.value); clearError('destination'); }}
                                    className={`w-full bg-slate-900/60 border rounded-2xl p-5 text-white font-bold outline-none transition-all shadow-inner ${errors.destination ? 'border-rose-500 focus:border-rose-600' : 'border-white/10 focus:border-emerald-500/50'}`}
                                    placeholder={activeTab === 'INTERNAL' ? 'BNK-XXXX' : 'المدينة أو الدولة'} 
                                />
                                <MapPin className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-emerald-500 w-4 h-4 transition-colors"/>
                            </div>
                            {errors.destination && <p className="text-rose-500 text-[10px] font-bold px-4">{errors.destination}</p>}
                        </div>
                        <div className="space-y-4">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">رقم الهاتف</label>
                            <div className="relative group">
                                <input 
                                    type="text" 
                                    value={beneficiaryPhone} 
                                    onChange={e => { setBeneficiaryPhone(e.target.value); clearError('beneficiaryPhone'); }}
                                    className={`w-full bg-slate-900/60 border rounded-2xl p-5 text-white font-bold outline-none transition-all shadow-inner text-left dir-ltr ${errors.beneficiaryPhone ? 'border-rose-500 focus:border-rose-600' : 'border-white/10 focus:border-emerald-500/50'}`}
                                    placeholder="+000 000 000" 
                                />
                                <Phone className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-emerald-500 w-4 h-4 transition-colors"/>
                            </div>
                            {errors.beneficiaryPhone && <p className="text-rose-500 text-[10px] font-bold px-4">{errors.beneficiaryPhone}</p>}
                        </div>
                        <div className="space-y-4">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">ملاحظات (اختياري)</label>
                            <div className="relative group">
                                <input 
                                    type="text" 
                                    value={notes} 
                                    onChange={e => setNotes(e.target.value)} 
                                    className="w-full bg-slate-900/60 border border-white/10 rounded-2xl p-5 text-white font-bold outline-none focus:border-emerald-500/50 shadow-inner" 
                                    placeholder="غرض الحوالة..." 
                                />
                                <FileText className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-emerald-500 w-4 h-4 transition-colors"/>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="p-10 bg-slate-900/40 border-t border-white/5 flex flex-col md:flex-row items-center gap-8">
                    <div className="flex-1 flex items-center gap-5 text-slate-500 bg-black/20 p-5 rounded-2xl border border-white/5 shadow-inner">
                        <div className="p-3 bg-white/5 rounded-xl"><Info size={20} className="text-emerald-500" /></div>
                        <p className="text-[11px] font-black leading-relaxed">
                           برجاء التأكد من صحة البيانات. <span className="text-emerald-400">الحوالات المنفذة نهائية</span> ولا يمكن استردادها بعد التنفيذ. سيتم احتساب رسوم بقيمة {transferFeePercentage}% آلياً.
                        </p>
                    </div>
                    <button 
                        onClick={handleSubmit}
                        className="w-full md:w-auto md:px-14 bg-emerald-600 hover:bg-emerald-500 text-white text-xl font-black py-7 rounded-[1.8rem] shadow-2xl shadow-emerald-900/30 flex items-center justify-center gap-4 transition-all active:scale-95 group relative overflow-hidden"
                    >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-shimmer"></div>
                        <span>مراجعة وإرسال</span>
                        <Send size={24} className="rtl:rotate-180 group-hover:-translate-y-1 group-hover:translate-x-1 transition-transform" />
                    </button>
                </div>
                </>
            )}
        </div>

        {/* Emerald Glass QR Modal (Digital Identity) */}
        {showQRModal && (
            <div className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-2xl flex items-center justify-center p-8 animate-in fade-in duration-500">
                <div className="glass-card w-full max-w-lg rounded-[4rem] border border-emerald-500/30 shadow-[0_0_100px_rgba(16,185,129,0.2)] p-12 text-center relative overflow-hidden flex flex-col items-center">
                    {/* Emerald Ambient Background */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px]"></div>
                    <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px]"></div>
                    
                    <button onClick={() => setShowQRModal(null)} className="absolute top-8 left-8 p-4 bg-white/5 hover:bg-rose-500 rounded-full text-slate-400 hover:text-white transition-all active:scale-90 shadow-2xl">
                        <X size={24} />
                    </button>

                    <div className="relative mb-10">
                        <div className="w-28 h-28 rounded-[2.5rem] bg-slate-900 border-4 border-emerald-500/20 overflow-hidden shadow-2xl shadow-emerald-500/10">
                            {showQRModal.avatar ? <img src={showQRModal.avatar} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center text-3xl font-black text-white">{showQRModal.name[0]}</div>}
                        </div>
                        <div className="absolute -bottom-2 -right-2 bg-emerald-500 p-2 rounded-xl text-black shadow-lg">
                            <ShieldCheck size={16} />
                        </div>
                    </div>

                    <div className="mb-10">
                        <h3 className="text-3xl font-black text-white drop-shadow-md">{showQRModal.name}</h3>
                        <p className="text-emerald-500 font-black text-sm uppercase tracking-[0.3em] mt-2">Verified Identity</p>
                    </div>

                    {/* QR Code with Gem Border */}
                    <div className="p-2 bg-emerald-500/5 rounded-[3rem] border border-emerald-500/20 shadow-inner group transition-all duration-700 hover:scale-105">
                        <div className="bg-white p-8 rounded-[2.5rem] shadow-[0_0_50px_rgba(16,185,129,0.3)] border-8 border-[#020617]">
                            <img 
                                src={`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${showQRModal.userCode}&color=020617&bgcolor=ffffff`} 
                                alt="QR ID" 
                                className="w-48 h-48 md:w-56 md:h-56"
                            />
                        </div>
                    </div>

                    <div className="mt-12 bg-slate-900/50 px-10 py-5 rounded-[2rem] border border-white/5 shadow-inner">
                        <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">User Identification Code</p>
                        <p className="text-2xl font-mono font-black text-white tracking-widest">{showQRModal.userCode}</p>
                    </div>

                    <button 
                        onClick={() => {
                            navigator.clipboard.writeText(showQRModal.userCode);
                            alert('تم نسخ الكود بنجاح!');
                        }}
                        className="mt-10 flex items-center gap-3 text-emerald-400 font-black text-xs uppercase tracking-widest hover:text-white transition-colors"
                    >
                        <Copy size={16} /> انقر لنسخ كود التعريف
                    </button>
                </div>
            </div>
        )}

        {/* Lightbox for Implementation Proof */}
        {selectedProof && (
            <div className="fixed inset-0 z-[300] bg-black/98 flex flex-col animate-in fade-in zoom-in duration-300">
                <div className="flex justify-between items-center p-8 bg-black/50 backdrop-blur-md border-b border-white/10">
                    <button onClick={() => setSelectedProof(null)} className="p-4 bg-white/5 rounded-full text-white hover:bg-rose-600 transition-colors shadow-2xl">
                        <X size={28} />
                    </button>
                    <div className="text-right">
                        <h4 className="text-white font-black text-xl">إيصال التنفيذ الرسمي</h4>
                        <p className="text-emerald-400 text-[10px] font-black uppercase tracking-widest mt-1">Official Proof of Transfer</p>
                    </div>
                </div>
                <div className="flex-1 flex items-center justify-center p-6 md:p-12 overflow-hidden">
                    <img 
                      src={selectedProof} 
                      alt="Admin Receipt" 
                      className="max-w-full max-h-full object-contain shadow-[0_0_100px_rgba(0,0,0,0.8)] border border-white/10 rounded-xl" 
                    />
                </div>
            </div>
        )}

        {/* Confirmation Modal */}
        {showConfirmModal && pendingTransferData && (
            <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6">
                <div className="glass-card w-full max-w-lg rounded-[3rem] p-12 border border-white/10 shadow-2xl text-center relative overflow-hidden animate-in zoom-in duration-300">
                    <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500"></div>
                    <ShieldCheck className="w-16 h-16 text-emerald-500 mx-auto mb-6" />
                    <h3 className="text-2xl font-black text-white mb-6">تأكيد عملية التحويل</h3>
                    
                    <div className="bg-[#030712] p-8 rounded-3xl border border-white/5 space-y-4 mb-8 text-right">
                        <div className="flex justify-between border-b border-white/5 pb-2">
                            <span className="text-slate-500 font-bold text-xs">المستفيد</span>
                            <span className="text-white font-black text-sm">{pendingTransferData.recipient}</span>
                        </div>
                        <div className="flex justify-between border-b border-white/5 pb-2">
                            <span className="text-slate-500 font-bold text-xs">الوجهة</span>
                            <span className="text-white font-black text-sm">{pendingTransferData.destination}</span>
                        </div>
                        <div className="flex justify-between border-b border-white/5 pb-2">
                            <span className="text-slate-500 font-bold text-xs">المبلغ المرسل</span>
                            <span className="text-white font-black font-mono">{pendingTransferData.amount} {pendingTransferData.currency}</span>
                        </div>
                        <div className="flex justify-between border-b border-white/5 pb-2">
                            <span className="text-slate-500 font-bold text-xs">الرسوم ({transferFeePercentage}%)</span>
                            <span className="text-rose-400 font-black font-mono">{pendingTransferData.fee.toFixed(2)} {pendingTransferData.currency}</span>
                        </div>
                        <div className="flex justify-between pt-2">
                            <span className="text-slate-500 font-bold">الإجمالي المخصوم</span>
                            <span className="text-emerald-400 font-black text-xl font-mono">{pendingTransferData.total.toLocaleString()} {pendingTransferData.currency}</span>
                        </div>
                    </div>

                    <div className="flex gap-4">
                        <button onClick={() => setShowConfirmModal(false)} className="flex-1 py-5 rounded-2xl bg-white/5 text-slate-300 font-black hover:bg-white/10 transition-colors">تراجع</button>
                        <button onClick={handleFinalConfirm} className="flex-[2] py-5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-xl transition-all active:scale-95">تأكيد الإرسال</button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default Transfer;
